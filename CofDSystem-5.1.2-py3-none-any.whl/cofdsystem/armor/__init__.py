import cofdsystem.haxe_build as haxe_build

IArmor = haxe_build.pw_tales_cofdsystem_armor_IArmor
Armor = haxe_build.pw_tales_cofdsystem_armor_Armor
