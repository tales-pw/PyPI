import cofdsystem.haxe_build as haxe_build

IWeapon = haxe_build.pw_tales_cofdsystem_weapon_IWeapon
Weapon = haxe_build.pw_tales_cofdsystem_weapon_Weapon
