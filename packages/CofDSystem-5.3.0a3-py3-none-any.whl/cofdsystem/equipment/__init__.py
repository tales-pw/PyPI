import cofdsystem.haxe_build as haxe_build

Equipment = haxe_build.pw_tales_cofdsystem_equipment_Equipment
