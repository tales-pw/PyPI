import cofdsystem.haxe_build as haxe_build

TimeUtils = haxe_build.pw_tales_cofdsystem_time_TimeUtils
