import cofdsystem.haxe_build as haxe_build

EnumNamed = haxe_build.pw_tales_cofdsystem_utils_EnumNamed
Utility = haxe_build.pw_tales_cofdsystem_utils_Utility
