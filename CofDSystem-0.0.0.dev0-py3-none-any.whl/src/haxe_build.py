import sys

import math as python_lib_Math
import math as Math
import inspect as python_lib_Inspect
import functools as python_lib_Functools
import re as python_lib_Re
import sys as python_lib_Sys
import json as python_lib_Json
import random as python_lib_Random
import socket as python_lib_Socket
import ssl as python_lib_Ssl
import traceback as python_lib_Traceback
from datetime import datetime as python_lib_datetime_Datetime
from datetime import timezone as python_lib_datetime_Timezone
from io import StringIO as python_lib_io_StringIO
from socket import socket as python_lib_socket_Socket
from ssl import Purpose as python_lib_ssl_Purpose
import urllib.parse as python_lib_urllib_Parse


class _hx_AnonObject:
    _hx_disable_getattr = False
    def __init__(self, fields):
        self.__dict__ = fields
    def __repr__(self):
        return repr(self.__dict__)
    def __contains__(self, item):
        return item in self.__dict__
    def __getitem__(self, item):
        return self.__dict__[item]
    def __getattr__(self, name):
        if (self._hx_disable_getattr):
            raise AttributeError('field does not exist')
        else:
            return None
    def _hx_hasattr(self,field):
        self._hx_disable_getattr = True
        try:
            getattr(self, field)
            self._hx_disable_getattr = False
            return True
        except AttributeError:
            self._hx_disable_getattr = False
            return False



_hx_classes = {}


class Enum:
    _hx_class_name = "Enum"
    _hx_is_interface = "False"
    __slots__ = ("tag", "index", "params")
    _hx_fields = ["tag", "index", "params"]
    _hx_methods = ["__str__"]

    def __init__(self,tag,index,params):
        self.tag = tag
        self.index = index
        self.params = params

    def __str__(self):
        if (self.params is None):
            return self.tag
        else:
            return self.tag + '(' + (', '.join(str(v) for v in self.params)) + ')'

Enum._hx_class = Enum
_hx_classes["Enum"] = Enum


class Class: pass


class CompileTime:
    _hx_class_name = "CompileTime"
    _hx_is_interface = "False"
    __slots__ = ()
CompileTime._hx_class = CompileTime
_hx_classes["CompileTime"] = CompileTime


class CompileTimeClassList:
    _hx_class_name = "CompileTimeClassList"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["__meta__", "lists", "get", "getTyped", "initialise"]

    @staticmethod
    def get(id):
        if (CompileTimeClassList.lists is None):
            CompileTimeClassList.initialise()
        return CompileTimeClassList.lists.h.get(id,None)

    @staticmethod
    def getTyped(id,_hx_type):
        return CompileTimeClassList.get(id)

    @staticmethod
    def initialise():
        CompileTimeClassList.lists = haxe_ds_StringMap()
        m = haxe_rtti_Meta.getType(CompileTimeClassList)
        if (Reflect.field(m,"classLists") is not None):
            _g = 0
            _g1 = Reflect.field(m,"classLists")
            while (_g < len(_g1)):
                def _hx_local_1():
                    nonlocal _g
                    _hx_local_0 = _g
                    _g = (_g + 1)
                    return _hx_local_0
                item = python_internal_ArrayImpl._get(_g1, _hx_local_1())
                array = item
                listID = (array[0] if 0 < len(array) else None)
                _hx_list = haxe_ds_List()
                _g2 = 0
                _g3 = (array[1] if 1 < len(array) else None).split(",")
                while (_g2 < len(_g3)):
                    def _hx_local_3():
                        nonlocal _g2
                        _hx_local_2 = _g2
                        _g2 = (_g2 + 1)
                        return _hx_local_2
                    typeName = python_internal_ArrayImpl._get(_g3, _hx_local_3())
                    _hx_type = Type.resolveClass(typeName)
                    if (_hx_type is not None):
                        _hx_list.push(_hx_type)
                CompileTimeClassList.lists.h[listID] = _hx_list
CompileTimeClassList._hx_class = CompileTimeClassList
_hx_classes["CompileTimeClassList"] = CompileTimeClassList


class Date:
    _hx_class_name = "Date"
    _hx_is_interface = "False"
    __slots__ = ("date", "dateUTC")
    _hx_fields = ["date", "dateUTC"]
    _hx_methods = ["toString"]
    _hx_statics = ["makeLocal"]

    def __init__(self,year,month,day,hour,_hx_min,sec):
        self.dateUTC = None
        if (year < python_lib_datetime_Datetime.min.year):
            year = python_lib_datetime_Datetime.min.year
        if (day == 0):
            day = 1
        self.date = Date.makeLocal(python_lib_datetime_Datetime(year,(month + 1),day,hour,_hx_min,sec,0))
        self.dateUTC = self.date.astimezone(python_lib_datetime_Timezone.utc)

    def toString(self):
        return self.date.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def makeLocal(date):
        try:
            return date.astimezone()
        except BaseException as _g:
            None
            return date.replace(**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'tzinfo': python_lib_datetime_Datetime.now(python_lib_datetime_Timezone.utc).astimezone().tzinfo})))

Date._hx_class = Date
_hx_classes["Date"] = Date


class EReg:
    _hx_class_name = "EReg"
    _hx_is_interface = "False"
    __slots__ = ("pattern", "matchObj", "_hx_global")
    _hx_fields = ["pattern", "matchObj", "global"]
    _hx_methods = ["split", "replace"]

    def __init__(self,r,opt):
        self.matchObj = None
        self._hx_global = False
        options = 0
        _g = 0
        _g1 = len(opt)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            c = (-1 if ((i >= len(opt))) else ord(opt[i]))
            if (c == 109):
                options = (options | python_lib_Re.M)
            if (c == 105):
                options = (options | python_lib_Re.I)
            if (c == 115):
                options = (options | python_lib_Re.S)
            if (c == 117):
                options = (options | python_lib_Re.U)
            if (c == 103):
                self._hx_global = True
        self.pattern = python_lib_Re.compile(r,options)

    def split(self,s):
        if self._hx_global:
            ret = []
            lastEnd = 0
            x = python_HaxeIterator(python_lib_Re.finditer(self.pattern,s))
            while x.hasNext():
                x1 = x.next()
                x2 = HxString.substring(s,lastEnd,x1.start())
                ret.append(x2)
                lastEnd = x1.end()
            x = HxString.substr(s,lastEnd,None)
            ret.append(x)
            return ret
        else:
            self.matchObj = python_lib_Re.search(self.pattern,s)
            if (self.matchObj is None):
                return [s]
            else:
                return [HxString.substring(s,0,self.matchObj.start()), HxString.substr(s,self.matchObj.end(),None)]

    def replace(self,s,by):
        _this = by.split("$$")
        by = "_hx_#repl#__".join([python_Boot.toString1(x1,'') for x1 in _this])
        def _hx_local_0(x):
            res = by
            g = x.groups()
            _g = 0
            _g1 = len(g)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                gs = g[i]
                if (gs is None):
                    continue
                delimiter = ("$" + HxOverrides.stringOrNull(str((i + 1))))
                _this = (list(res) if ((delimiter == "")) else res.split(delimiter))
                res = gs.join([python_Boot.toString1(x1,'') for x1 in _this])
            _this = res.split("_hx_#repl#__")
            res = "$".join([python_Boot.toString1(x1,'') for x1 in _this])
            return res
        replace = _hx_local_0
        return python_lib_Re.sub(self.pattern,replace,s,(0 if (self._hx_global) else 1))

EReg._hx_class = EReg
_hx_classes["EReg"] = EReg


class Lambda:
    _hx_class_name = "Lambda"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["exists", "fold"]

    @staticmethod
    def exists(it,f):
        x = HxOverrides.iterator(it)
        while x.hasNext():
            if f(x.next()):
                return True
        return False

    @staticmethod
    def fold(it,f,first):
        x = HxOverrides.iterator(it)
        while x.hasNext():
            first = f(x.next(),first)
        return first
Lambda._hx_class = Lambda
_hx_classes["Lambda"] = Lambda


class Reflect:
    _hx_class_name = "Reflect"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["field", "getProperty", "isFunction", "compareMethods"]

    @staticmethod
    def field(o,field):
        return python_Boot.field(o,field)

    @staticmethod
    def getProperty(o,field):
        if (o is None):
            return None
        if (field in python_Boot.keywords):
            field = ("_hx_" + field)
        elif ((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95))):
            field = ("_hx_" + field)
        if isinstance(o,_hx_AnonObject):
            return Reflect.field(o,field)
        tmp = Reflect.field(o,("get_" + ("null" if field is None else field)))
        if ((tmp is not None) and callable(tmp)):
            return tmp()
        else:
            return Reflect.field(o,field)

    @staticmethod
    def isFunction(f):
        if (not ((python_lib_Inspect.isfunction(f) or python_lib_Inspect.ismethod(f)))):
            return python_Boot.hasField(f,"func_code")
        else:
            return True

    @staticmethod
    def compareMethods(f1,f2):
        if HxOverrides.eq(f1,f2):
            return True
        if (isinstance(f1,python_internal_MethodClosure) and isinstance(f2,python_internal_MethodClosure)):
            m1 = f1
            m2 = f2
            if HxOverrides.eq(m1.obj,m2.obj):
                return (m1.func == m2.func)
            else:
                return False
        if ((not Reflect.isFunction(f1)) or (not Reflect.isFunction(f2))):
            return False
        return False
Reflect._hx_class = Reflect
_hx_classes["Reflect"] = Reflect


class Std:
    _hx_class_name = "Std"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["downcast", "is", "isOfType", "string", "parseInt"]

    @staticmethod
    def downcast(value,c):
        try:
            tmp = None
            if (not isinstance(value,c)):
                if c._hx_is_interface:
                    cls = c
                    loop = None
                    def _hx_local_1(intf):
                        f = (intf._hx_interfaces if (hasattr(intf,"_hx_interfaces")) else [])
                        if (f is not None):
                            _g = 0
                            while (_g < len(f)):
                                i = (f[_g] if _g >= 0 and _g < len(f) else None)
                                _g = (_g + 1)
                                if (i == cls):
                                    return True
                                elif loop(i):
                                    return True
                            return False
                        else:
                            return False
                    loop = _hx_local_1
                    currentClass = value.__class__
                    result = False
                    while (currentClass is not None):
                        if loop(currentClass):
                            result = True
                            break
                        currentClass = python_Boot.getSuperClass(currentClass)
                    tmp = result
                else:
                    tmp = False
            else:
                tmp = True
            if tmp:
                return value
            else:
                return None
        except BaseException as _g:
            None
            return None

    @staticmethod
    def _hx_is(v,t):
        return Std.isOfType(v,t)

    @staticmethod
    def isOfType(v,t):
        if ((v is None) and ((t is None))):
            return False
        if (t is None):
            return False
        if ((type(t) == type) and (t == Dynamic)):
            return (v is not None)
        isBool = isinstance(v,bool)
        if (((type(t) == type) and (t == Bool)) and isBool):
            return True
        if ((((not isBool) and (not ((type(t) == type) and (t == Bool)))) and ((type(t) == type) and (t == Int))) and isinstance(v,int)):
            return True
        vIsFloat = isinstance(v,float)
        tmp = None
        tmp1 = None
        if (((not isBool) and vIsFloat) and ((type(t) == type) and (t == Int))):
            f = v
            tmp1 = (((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))
        else:
            tmp1 = False
        if tmp1:
            tmp1 = None
            try:
                tmp1 = int(v)
            except BaseException as _g:
                None
                tmp1 = None
            tmp = (v == tmp1)
        else:
            tmp = False
        if ((tmp and ((v <= 2147483647))) and ((v >= -2147483648))):
            return True
        if (((not isBool) and ((type(t) == type) and (t == Float))) and isinstance(v,(float, int))):
            return True
        if ((type(t) == type) and (t == str)):
            return isinstance(v,str)
        isEnumType = ((type(t) == type) and (t == Enum))
        if ((isEnumType and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_constructs")):
            return True
        if isEnumType:
            return False
        isClassType = ((type(t) == type) and (t == Class))
        if ((((isClassType and (not isinstance(v,Enum))) and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_class_name")) and (not hasattr(v,"_hx_constructs"))):
            return True
        if isClassType:
            return False
        tmp = None
        try:
            tmp = isinstance(v,t)
        except BaseException as _g:
            None
            tmp = False
        if tmp:
            return True
        if python_lib_Inspect.isclass(t):
            cls = t
            loop = None
            def _hx_local_1(intf):
                f = (intf._hx_interfaces if (hasattr(intf,"_hx_interfaces")) else [])
                if (f is not None):
                    _g = 0
                    while (_g < len(f)):
                        i = (f[_g] if _g >= 0 and _g < len(f) else None)
                        _g = (_g + 1)
                        if (i == cls):
                            return True
                        else:
                            l = loop(i)
                            if l:
                                return True
                    return False
                else:
                    return False
            loop = _hx_local_1
            currentClass = v.__class__
            result = False
            while (currentClass is not None):
                if loop(currentClass):
                    result = True
                    break
                currentClass = python_Boot.getSuperClass(currentClass)
            return result
        else:
            return False

    @staticmethod
    def string(s):
        return python_Boot.toString1(s,"")

    @staticmethod
    def parseInt(x):
        if (x is None):
            return None
        try:
            return int(x)
        except BaseException as _g:
            None
            base = 10
            _hx_len = len(x)
            foundCount = 0
            sign = 0
            firstDigitIndex = 0
            lastDigitIndex = -1
            previous = 0
            _g = 0
            while (_g < _hx_len):
                i = _g
                _g = (_g + 1)
                c = (-1 if ((i >= len(x))) else ord(x[i]))
                if (((c > 8) and ((c < 14))) or ((c == 32))):
                    if (foundCount > 0):
                        return None
                    continue
                else:
                    c1 = c
                    if (c1 == 43):
                        if (foundCount == 0):
                            sign = 1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 45):
                        if (foundCount == 0):
                            sign = -1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 48):
                        if (not (((foundCount == 0) or (((foundCount == 1) and ((sign != 0))))))):
                            if (not (((48 <= c) and ((c <= 57))))):
                                if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                    break
                    elif ((c1 == 120) or ((c1 == 88))):
                        if ((previous == 48) and ((((foundCount == 1) and ((sign == 0))) or (((foundCount == 2) and ((sign != 0))))))):
                            base = 16
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (not (((48 <= c) and ((c <= 57))))):
                        if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                            break
                if (((foundCount == 0) and ((sign == 0))) or (((foundCount == 1) and ((sign != 0))))):
                    firstDigitIndex = i
                foundCount = (foundCount + 1)
                lastDigitIndex = i
                previous = c
            if (firstDigitIndex <= lastDigitIndex):
                digits = HxString.substring(x,firstDigitIndex,(lastDigitIndex + 1))
                try:
                    return (((-1 if ((sign == -1)) else 1)) * int(digits,base))
                except BaseException as _g:
                    return None
            return None
Std._hx_class = Std
_hx_classes["Std"] = Std


class Float: pass


class Int: pass


class Bool: pass


class Dynamic: pass


class StringBuf:
    _hx_class_name = "StringBuf"
    _hx_is_interface = "False"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["get_length"]

    def __init__(self):
        self.b = python_lib_io_StringIO()

    def get_length(self):
        pos = self.b.tell()
        self.b.seek(0,2)
        _hx_len = self.b.tell()
        self.b.seek(pos,0)
        return _hx_len

StringBuf._hx_class = StringBuf
_hx_classes["StringBuf"] = StringBuf


class StringTools:
    _hx_class_name = "StringTools"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["isSpace", "ltrim", "rtrim", "trim", "lpad", "replace"]

    @staticmethod
    def isSpace(s,pos):
        if (((len(s) == 0) or ((pos < 0))) or ((pos >= len(s)))):
            return False
        c = HxString.charCodeAt(s,pos)
        if (not (((c > 8) and ((c < 14))))):
            return (c == 32)
        else:
            return True

    @staticmethod
    def ltrim(s):
        l = len(s)
        r = 0
        while ((r < l) and StringTools.isSpace(s,r)):
            r = (r + 1)
        if (r > 0):
            return HxString.substr(s,r,(l - r))
        else:
            return s

    @staticmethod
    def rtrim(s):
        l = len(s)
        r = 0
        while ((r < l) and StringTools.isSpace(s,((l - r) - 1))):
            r = (r + 1)
        if (r > 0):
            return HxString.substr(s,0,(l - r))
        else:
            return s

    @staticmethod
    def trim(s):
        return StringTools.ltrim(StringTools.rtrim(s))

    @staticmethod
    def lpad(s,c,l):
        if (len(c) <= 0):
            return s
        buf = StringBuf()
        l = (l - len(s))
        while (buf.get_length() < l):
            s1 = Std.string(c)
            buf.b.write(s1)
        s1 = Std.string(s)
        buf.b.write(s1)
        return buf.b.getvalue()

    @staticmethod
    def replace(s,sub,by):
        _this = (list(s) if ((sub == "")) else s.split(sub))
        return by.join([python_Boot.toString1(x1,'') for x1 in _this])
StringTools._hx_class = StringTools
_hx_classes["StringTools"] = StringTools

class ValueType(Enum):
    __slots__ = ()
    _hx_class_name = "ValueType"
    _hx_constructs = ["TNull", "TInt", "TFloat", "TBool", "TObject", "TFunction", "TClass", "TEnum", "TUnknown"]

    @staticmethod
    def TClass(c):
        return ValueType("TClass", 6, (c,))

    @staticmethod
    def TEnum(e):
        return ValueType("TEnum", 7, (e,))
ValueType.TNull = ValueType("TNull", 0, ())
ValueType.TInt = ValueType("TInt", 1, ())
ValueType.TFloat = ValueType("TFloat", 2, ())
ValueType.TBool = ValueType("TBool", 3, ())
ValueType.TObject = ValueType("TObject", 4, ())
ValueType.TFunction = ValueType("TFunction", 5, ())
ValueType.TUnknown = ValueType("TUnknown", 8, ())
ValueType._hx_class = ValueType
_hx_classes["ValueType"] = ValueType


class Type:
    _hx_class_name = "Type"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["getClass", "getSuperClass", "getClassName", "resolveClass", "typeof"]

    @staticmethod
    def getClass(o):
        if (o is None):
            return None
        o1 = o
        if ((o1 is not None) and ((HxOverrides.eq(o1,str) or python_lib_Inspect.isclass(o1)))):
            return None
        if isinstance(o,_hx_AnonObject):
            return None
        if hasattr(o,"_hx_class"):
            return o._hx_class
        if hasattr(o,"__class__"):
            return o.__class__
        else:
            return None

    @staticmethod
    def getSuperClass(c):
        return python_Boot.getSuperClass(c)

    @staticmethod
    def getClassName(c):
        if hasattr(c,"_hx_class_name"):
            return c._hx_class_name
        else:
            if (c == list):
                return "Array"
            if (c == Math):
                return "Math"
            if (c == str):
                return "String"
            try:
                return c.__name__
            except BaseException as _g:
                None
                return None

    @staticmethod
    def resolveClass(name):
        if (name == "Array"):
            return list
        if (name == "Math"):
            return Math
        if (name == "String"):
            return str
        cl = _hx_classes.get(name,None)
        tmp = None
        if (cl is not None):
            o = cl
            tmp = (not (((o is not None) and ((HxOverrides.eq(o,str) or python_lib_Inspect.isclass(o))))))
        else:
            tmp = True
        if tmp:
            return None
        return cl

    @staticmethod
    def typeof(v):
        if (v is None):
            return ValueType.TNull
        elif isinstance(v,bool):
            return ValueType.TBool
        elif isinstance(v,int):
            return ValueType.TInt
        elif isinstance(v,float):
            return ValueType.TFloat
        elif isinstance(v,str):
            return ValueType.TClass(str)
        elif isinstance(v,list):
            return ValueType.TClass(list)
        elif (isinstance(v,_hx_AnonObject) or python_lib_Inspect.isclass(v)):
            return ValueType.TObject
        elif isinstance(v,Enum):
            return ValueType.TEnum(v.__class__)
        elif (isinstance(v,type) or hasattr(v,"_hx_class")):
            return ValueType.TClass(v.__class__)
        elif callable(v):
            return ValueType.TFunction
        else:
            return ValueType.TUnknown
Type._hx_class = Type
_hx_classes["Type"] = Type

class haxe_StackItem(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.StackItem"
    _hx_constructs = ["CFunction", "Module", "FilePos", "Method", "LocalFunction"]

    @staticmethod
    def Module(m):
        return haxe_StackItem("Module", 1, (m,))

    @staticmethod
    def FilePos(s,file,line,column = None):
        return haxe_StackItem("FilePos", 2, (s,file,line,column))

    @staticmethod
    def Method(classname,method):
        return haxe_StackItem("Method", 3, (classname,method))

    @staticmethod
    def LocalFunction(v = None):
        return haxe_StackItem("LocalFunction", 4, (v,))
haxe_StackItem.CFunction = haxe_StackItem("CFunction", 0, ())
haxe_StackItem._hx_class = haxe_StackItem
_hx_classes["haxe.StackItem"] = haxe_StackItem


class haxe__CallStack_CallStack_Impl_:
    _hx_class_name = "haxe._CallStack.CallStack_Impl_"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["callStack", "exceptionStack", "toString", "subtract", "equalItems", "itemToString"]

    @staticmethod
    def callStack():
        infos = python_lib_Traceback.extract_stack()
        if (len(infos) != 0):
            infos.pop()
        infos.reverse()
        return haxe_NativeStackTrace.toHaxe(infos)

    @staticmethod
    def exceptionStack(fullStack = None):
        if (fullStack is None):
            fullStack = False
        eStack = haxe_NativeStackTrace.toHaxe(haxe_NativeStackTrace.exceptionStack())
        return (eStack if fullStack else haxe__CallStack_CallStack_Impl_.subtract(eStack,haxe__CallStack_CallStack_Impl_.callStack()))

    @staticmethod
    def toString(stack):
        b = StringBuf()
        _g = 0
        _g1 = stack
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            s = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            b.b.write("\nCalled from ")
            haxe__CallStack_CallStack_Impl_.itemToString(b,s)
        return b.b.getvalue()

    @staticmethod
    def subtract(this1,stack):
        startIndex = -1
        i = -1
        while True:
            i = (i + 1)
            tmp = i
            if (not ((tmp < len(this1)))):
                break
            _g = 0
            _g1 = len(stack)
            while (_g < _g1):
                j = _g
                _g = (_g + 1)
                if haxe__CallStack_CallStack_Impl_.equalItems((this1[i] if i >= 0 and i < len(this1) else None),python_internal_ArrayImpl._get(stack, j)):
                    if (startIndex < 0):
                        startIndex = i
                    i = (i + 1)
                    if (i >= len(this1)):
                        break
                else:
                    startIndex = -1
            if (startIndex >= 0):
                break
        if (startIndex >= 0):
            return this1[0:startIndex]
        else:
            return this1

    @staticmethod
    def equalItems(item1,item2):
        if (item1 is None):
            if (item2 is None):
                return True
            else:
                return False
        else:
            tmp = item1.index
            if (tmp == 0):
                if (item2 is None):
                    return False
                elif (item2.index == 0):
                    return True
                else:
                    return False
            elif (tmp == 1):
                if (item2 is None):
                    return False
                elif (item2.index == 1):
                    return (item1.params[0] == item2.params[0])
                else:
                    return False
            elif (tmp == 2):
                if (item2 is None):
                    return False
                elif (item2.index == 2):
                    if (((item1.params[1] == item2.params[1]) and ((item1.params[2] == item2.params[2]))) and ((item1.params[3] == item2.params[3]))):
                        return haxe__CallStack_CallStack_Impl_.equalItems(item1.params[0],item2.params[0])
                    else:
                        return False
                else:
                    return False
            elif (tmp == 3):
                if (item2 is None):
                    return False
                elif (item2.index == 3):
                    if (item1.params[0] == item2.params[0]):
                        return (item1.params[1] == item2.params[1])
                    else:
                        return False
                else:
                    return False
            elif (tmp == 4):
                if (item2 is None):
                    return False
                elif (item2.index == 4):
                    return (item1.params[0] == item2.params[0])
                else:
                    return False
            else:
                pass

    @staticmethod
    def itemToString(b,s):
        tmp = s.index
        if (tmp == 0):
            b.b.write("a C function")
        elif (tmp == 1):
            b.b.write("module ")
            s1 = Std.string(s.params[0])
            b.b.write(s1)
        elif (tmp == 2):
            _g = s.params[0]
            _g1 = s.params[3]
            if (_g is not None):
                haxe__CallStack_CallStack_Impl_.itemToString(b,_g)
                b.b.write(" (")
            s1 = Std.string(s.params[1])
            b.b.write(s1)
            b.b.write(" line ")
            s1 = Std.string(s.params[2])
            b.b.write(s1)
            if (_g1 is not None):
                b.b.write(" column ")
                s1 = Std.string(_g1)
                b.b.write(s1)
            if (_g is not None):
                b.b.write(")")
        elif (tmp == 3):
            _g = s.params[0]
            s1 = Std.string(("<unknown>" if ((_g is None)) else _g))
            b.b.write(s1)
            b.b.write(".")
            s1 = Std.string(s.params[1])
            b.b.write(s1)
        elif (tmp == 4):
            b.b.write("local function #")
            s1 = Std.string(s.params[0])
            b.b.write(s1)
        else:
            pass
haxe__CallStack_CallStack_Impl_._hx_class = haxe__CallStack_CallStack_Impl_
_hx_classes["haxe._CallStack.CallStack_Impl_"] = haxe__CallStack_CallStack_Impl_


class haxe_IMap:
    _hx_class_name = "haxe.IMap"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["get", "keys", "keyValueIterator", "toString"]
haxe_IMap._hx_class = haxe_IMap
_hx_classes["haxe.IMap"] = haxe_IMap


class haxe_Exception(Exception):
    _hx_class_name = "haxe.Exception"
    _hx_is_interface = "False"
    __slots__ = ("_hx___nativeStack", "_hx___skipStack", "_hx___nativeException", "_hx___previousException")
    _hx_fields = ["__nativeStack", "__skipStack", "__nativeException", "__previousException"]
    _hx_methods = ["unwrap", "toString", "get_message", "get_native"]
    _hx_statics = ["caught", "thrown"]
    _hx_interfaces = []
    _hx_super = Exception


    def __init__(self,message,previous = None,native = None):
        self._hx___previousException = None
        self._hx___nativeException = None
        self._hx___nativeStack = None
        self._hx___skipStack = 0
        super().__init__(message)
        self._hx___previousException = previous
        if ((native is not None) and Std.isOfType(native,BaseException)):
            self._hx___nativeException = native
            self._hx___nativeStack = haxe_NativeStackTrace.exceptionStack()
        else:
            self._hx___nativeException = self
            infos = python_lib_Traceback.extract_stack()
            if (len(infos) != 0):
                infos.pop()
            infos.reverse()
            self._hx___nativeStack = infos

    def unwrap(self):
        return self._hx___nativeException

    def toString(self):
        return self.get_message()

    def get_message(self):
        return str(self)

    def get_native(self):
        return self._hx___nativeException

    @staticmethod
    def caught(value):
        if Std.isOfType(value,haxe_Exception):
            return value
        elif Std.isOfType(value,BaseException):
            return haxe_Exception(str(value),None,value)
        else:
            return haxe_ValueException(value,None,value)

    @staticmethod
    def thrown(value):
        if Std.isOfType(value,haxe_Exception):
            return value.get_native()
        elif Std.isOfType(value,BaseException):
            return value
        else:
            e = haxe_ValueException(value)
            e._hx___skipStack = (e._hx___skipStack + 1)
            return e

haxe_Exception._hx_class = haxe_Exception
_hx_classes["haxe.Exception"] = haxe_Exception


class haxe_NativeStackTrace:
    _hx_class_name = "haxe.NativeStackTrace"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["saveStack", "exceptionStack", "toHaxe"]

    @staticmethod
    def saveStack(exception):
        pass

    @staticmethod
    def exceptionStack():
        exc = python_lib_Sys.exc_info()
        if (exc[2] is not None):
            infos = python_lib_Traceback.extract_tb(exc[2])
            infos.reverse()
            return infos
        else:
            return []

    @staticmethod
    def toHaxe(native,skip = None):
        if (skip is None):
            skip = 0
        stack = []
        _g = 0
        _g1 = len(native)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            if (skip > i):
                continue
            elem = (native[i] if i >= 0 and i < len(native) else None)
            x = haxe_StackItem.FilePos(haxe_StackItem.Method(None,elem[2]),elem[0],elem[1])
            stack.append(x)
        return stack
haxe_NativeStackTrace._hx_class = haxe_NativeStackTrace
_hx_classes["haxe.NativeStackTrace"] = haxe_NativeStackTrace


class haxe_ValueException(haxe_Exception):
    _hx_class_name = "haxe.ValueException"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["unwrap"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,value,previous = None,native = None):
        self.value = None
        super().__init__(Std.string(value),previous,native)
        self.value = value

    def unwrap(self):
        return self.value

haxe_ValueException._hx_class = haxe_ValueException
_hx_classes["haxe.ValueException"] = haxe_ValueException


class haxe_ds_List:
    _hx_class_name = "haxe.ds.List"
    _hx_is_interface = "False"
    __slots__ = ("h", "q", "length")
    _hx_fields = ["h", "q", "length"]
    _hx_methods = ["push"]

    def __init__(self):
        self.q = None
        self.h = None
        self.length = 0

    def push(self,item):
        x = haxe_ds__List_ListNode(item,self.h)
        self.h = x
        if (self.q is None):
            self.q = x
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.length
        _hx_local_0.length = (_hx_local_1 + 1)
        _hx_local_1

haxe_ds_List._hx_class = haxe_ds_List
_hx_classes["haxe.ds.List"] = haxe_ds_List


class haxe_ds__List_ListNode:
    _hx_class_name = "haxe.ds._List.ListNode"
    _hx_is_interface = "False"
    __slots__ = ("item", "next")
    _hx_fields = ["item", "next"]

    def __init__(self,item,next):
        self.item = item
        self.next = next

haxe_ds__List_ListNode._hx_class = haxe_ds__List_ListNode
_hx_classes["haxe.ds._List.ListNode"] = haxe_ds__List_ListNode


class haxe_ds_ObjectMap:
    _hx_class_name = "haxe.ds.ObjectMap"
    _hx_is_interface = "False"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "get", "remove", "keys", "keyValueIterator", "toString"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def set(self,key,value):
        self.h[key] = value

    def get(self,key):
        return self.h.get(key,None)

    def remove(self,key):
        r = (key in self.h)
        if r:
            del self.h[key]
        return r

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    def keyValueIterator(self):
        return haxe_iterators_MapKeyValueIterator(self)

    def toString(self):
        s_b = python_lib_io_StringIO()
        s_b.write("{")
        it = self.keys()
        while it.hasNext():
            i = it.next()
            s_b.write(Std.string(Std.string(i)))
            s_b.write(" => ")
            s_b.write(Std.string(Std.string(self.h.get(i,None))))
            if it.hasNext():
                s_b.write(", ")
        s_b.write("}")
        return s_b.getvalue()

haxe_ds_ObjectMap._hx_class = haxe_ds_ObjectMap
_hx_classes["haxe.ds.ObjectMap"] = haxe_ds_ObjectMap


class haxe_ds_StringMap:
    _hx_class_name = "haxe.ds.StringMap"
    _hx_is_interface = "False"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["get", "remove", "keys", "iterator", "keyValueIterator", "toString"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def get(self,key):
        return self.h.get(key,None)

    def remove(self,key):
        has = (key in self.h)
        if has:
            del self.h[key]
        return has

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    def iterator(self):
        return python_HaxeIterator(iter(self.h.values()))

    def keyValueIterator(self):
        return haxe_iterators_MapKeyValueIterator(self)

    def toString(self):
        s_b = python_lib_io_StringIO()
        s_b.write("{")
        it = self.keys()
        while it.hasNext():
            i = it.next()
            s_b.write(Std.string(i))
            s_b.write(" => ")
            s_b.write(Std.string(Std.string(self.h.get(i,None))))
            if it.hasNext():
                s_b.write(", ")
        s_b.write("}")
        return s_b.getvalue()

haxe_ds_StringMap._hx_class = haxe_ds_StringMap
_hx_classes["haxe.ds.StringMap"] = haxe_ds_StringMap


class haxe_exceptions_PosException(haxe_Exception):
    _hx_class_name = "haxe.exceptions.PosException"
    _hx_is_interface = "False"
    __slots__ = ("posInfos",)
    _hx_fields = ["posInfos"]
    _hx_methods = ["toString"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,message,previous = None,pos = None):
        self.posInfos = None
        super().__init__(message,previous)
        if (pos is None):
            self.posInfos = _hx_AnonObject({'fileName': "(unknown)", 'lineNumber': 0, 'className': "(unknown)", 'methodName': "(unknown)"})
        else:
            self.posInfos = pos

    def toString(self):
        return ((((((((("" + HxOverrides.stringOrNull(super().toString())) + " in ") + HxOverrides.stringOrNull(self.posInfos.className)) + ".") + HxOverrides.stringOrNull(self.posInfos.methodName)) + " at ") + HxOverrides.stringOrNull(self.posInfos.fileName)) + ":") + Std.string(self.posInfos.lineNumber))

haxe_exceptions_PosException._hx_class = haxe_exceptions_PosException
_hx_classes["haxe.exceptions.PosException"] = haxe_exceptions_PosException


class haxe_exceptions_NotImplementedException(haxe_exceptions_PosException):
    _hx_class_name = "haxe.exceptions.NotImplementedException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_exceptions_PosException


    def __init__(self,message = None,previous = None,pos = None):
        if (message is None):
            message = "Not implemented"
        super().__init__(message,previous,pos)
haxe_exceptions_NotImplementedException._hx_class = haxe_exceptions_NotImplementedException
_hx_classes["haxe.exceptions.NotImplementedException"] = haxe_exceptions_NotImplementedException


class haxe_format_JsonPrinter:
    _hx_class_name = "haxe.format.JsonPrinter"
    _hx_is_interface = "False"
    __slots__ = ("buf", "replacer", "indent", "pretty", "nind")
    _hx_fields = ["buf", "replacer", "indent", "pretty", "nind"]
    _hx_methods = ["write", "classString", "fieldsString", "quote"]
    _hx_statics = ["print"]

    def __init__(self,replacer,space):
        self.replacer = replacer
        self.indent = space
        self.pretty = (space is not None)
        self.nind = 0
        self.buf = StringBuf()

    def write(self,k,v):
        if (self.replacer is not None):
            v = self.replacer(k,v)
        _g = Type.typeof(v)
        tmp = _g.index
        if (tmp == 0):
            self.buf.b.write("null")
        elif (tmp == 1):
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 2):
            f = v
            v1 = (Std.string(v) if ((((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))) else "null")
            _this = self.buf
            s = Std.string(v1)
            _this.b.write(s)
        elif (tmp == 3):
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 4):
            self.fieldsString(v,python_Boot.fields(v))
        elif (tmp == 5):
            self.buf.b.write("\"<fun>\"")
        elif (tmp == 6):
            _g1 = _g.params[0]
            if (_g1 == str):
                self.quote(v)
            elif (_g1 == list):
                v1 = v
                _this = self.buf
                s = "".join(map(chr,[91]))
                _this.b.write(s)
                _hx_len = len(v1)
                last = (_hx_len - 1)
                _g = 0
                while (_g < _hx_len):
                    i = _g
                    _g = (_g + 1)
                    if (i > 0):
                        _this = self.buf
                        s = "".join(map(chr,[44]))
                        _this.b.write(s)
                    else:
                        _hx_local_0 = self
                        _hx_local_1 = _hx_local_0.nind
                        _hx_local_0.nind = (_hx_local_1 + 1)
                        _hx_local_1
                    if self.pretty:
                        _this1 = self.buf
                        s1 = "".join(map(chr,[10]))
                        _this1.b.write(s1)
                    if self.pretty:
                        v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                        _this2 = self.buf
                        s2 = Std.string(v2)
                        _this2.b.write(s2)
                    self.write(i,(v1[i] if i >= 0 and i < len(v1) else None))
                    if (i == last):
                        _hx_local_2 = self
                        _hx_local_3 = _hx_local_2.nind
                        _hx_local_2.nind = (_hx_local_3 - 1)
                        _hx_local_3
                        if self.pretty:
                            _this3 = self.buf
                            s3 = "".join(map(chr,[10]))
                            _this3.b.write(s3)
                        if self.pretty:
                            v3 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                            _this4 = self.buf
                            s4 = Std.string(v3)
                            _this4.b.write(s4)
                _this = self.buf
                s = "".join(map(chr,[93]))
                _this.b.write(s)
            elif (_g1 == haxe_ds_StringMap):
                v1 = v
                o = _hx_AnonObject({})
                k = v1.keys()
                while k.hasNext():
                    k1 = k.next()
                    value = v1.h.get(k1,None)
                    setattr(o,(("_hx_" + k1) if ((k1 in python_Boot.keywords)) else (("_hx_" + k1) if (((((len(k1) > 2) and ((ord(k1[0]) == 95))) and ((ord(k1[1]) == 95))) and ((ord(k1[(len(k1) - 1)]) != 95)))) else k1)),value)
                v1 = o
                self.fieldsString(v1,python_Boot.fields(v1))
            elif (_g1 == Date):
                self.quote(v.toString())
            else:
                self.classString(v)
        elif (tmp == 7):
            _this = self.buf
            s = Std.string(v.index)
            _this.b.write(s)
        elif (tmp == 8):
            self.buf.b.write("\"???\"")
        else:
            pass

    def classString(self,v):
        self.fieldsString(v,python_Boot.getInstanceFields(Type.getClass(v)))

    def fieldsString(self,v,fields):
        _this = self.buf
        s = "".join(map(chr,[123]))
        _this.b.write(s)
        _hx_len = len(fields)
        last = (_hx_len - 1)
        first = True
        _g = 0
        while (_g < _hx_len):
            i = _g
            _g = (_g + 1)
            f = (fields[i] if i >= 0 and i < len(fields) else None)
            value = Reflect.field(v,f)
            if Reflect.isFunction(value):
                continue
            if first:
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.nind
                _hx_local_0.nind = (_hx_local_1 + 1)
                _hx_local_1
                first = False
            else:
                _this = self.buf
                s = "".join(map(chr,[44]))
                _this.b.write(s)
            if self.pretty:
                _this1 = self.buf
                s1 = "".join(map(chr,[10]))
                _this1.b.write(s1)
            if self.pretty:
                v1 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                _this2 = self.buf
                s2 = Std.string(v1)
                _this2.b.write(s2)
            self.quote(f)
            _this3 = self.buf
            s3 = "".join(map(chr,[58]))
            _this3.b.write(s3)
            if self.pretty:
                _this4 = self.buf
                s4 = "".join(map(chr,[32]))
                _this4.b.write(s4)
            self.write(f,value)
            if (i == last):
                _hx_local_2 = self
                _hx_local_3 = _hx_local_2.nind
                _hx_local_2.nind = (_hx_local_3 - 1)
                _hx_local_3
                if self.pretty:
                    _this5 = self.buf
                    s5 = "".join(map(chr,[10]))
                    _this5.b.write(s5)
                if self.pretty:
                    v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                    _this6 = self.buf
                    s6 = Std.string(v2)
                    _this6.b.write(s6)
        _this = self.buf
        s = "".join(map(chr,[125]))
        _this.b.write(s)

    def quote(self,s):
        _this = self.buf
        s1 = "".join(map(chr,[34]))
        _this.b.write(s1)
        i = 0
        length = len(s)
        while (i < length):
            index = i
            i = (i + 1)
            c = ord(s[index])
            if (c == 8):
                self.buf.b.write("\\b")
            elif (c == 9):
                self.buf.b.write("\\t")
            elif (c == 10):
                self.buf.b.write("\\n")
            elif (c == 12):
                self.buf.b.write("\\f")
            elif (c == 13):
                self.buf.b.write("\\r")
            elif (c == 34):
                self.buf.b.write("\\\"")
            elif (c == 92):
                self.buf.b.write("\\\\")
            else:
                _this = self.buf
                s1 = "".join(map(chr,[c]))
                _this.b.write(s1)
        _this = self.buf
        s = "".join(map(chr,[34]))
        _this.b.write(s)

    @staticmethod
    def print(o,replacer = None,space = None):
        printer = haxe_format_JsonPrinter(replacer,space)
        printer.write("",o)
        return printer.buf.b.getvalue()

haxe_format_JsonPrinter._hx_class = haxe_format_JsonPrinter
_hx_classes["haxe.format.JsonPrinter"] = haxe_format_JsonPrinter


class haxe_http_HttpBase:
    _hx_class_name = "haxe.http.HttpBase"
    _hx_is_interface = "False"
    _hx_fields = ["url", "responseBytes", "responseAsString", "postData", "postBytes", "headers", "params", "emptyOnData"]
    _hx_methods = ["addHeader", "setPostData", "request", "onData", "onBytes", "onError", "onStatus", "hasOnData", "success", "get_responseData"]

    def __init__(self,url):
        self.emptyOnData = None
        self.postBytes = None
        self.postData = None
        self.responseAsString = None
        self.responseBytes = None
        self.url = url
        self.headers = []
        self.params = []
        self.emptyOnData = self.onData

    def addHeader(self,header,value):
        self.headers.append(_hx_AnonObject({'name': header, 'value': value}))

    def setPostData(self,data):
        self.postData = data
        self.postBytes = None

    def request(self,post = None):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "haxe/http/HttpBase.hx", 'lineNumber': 186, 'className': "haxe.http.HttpBase", 'methodName': "request"}))

    def onData(self,data):
        pass

    def onBytes(self,data):
        pass

    def onError(self,msg):
        pass

    def onStatus(self,status):
        pass

    def hasOnData(self):
        return (not Reflect.compareMethods(self.onData,self.emptyOnData))

    def success(self,data):
        self.responseBytes = data
        self.responseAsString = None
        if self.hasOnData():
            self.onData(self.get_responseData())
        self.onBytes(self.responseBytes)

    def get_responseData(self):
        if ((self.responseAsString is None) and ((self.responseBytes is not None))):
            self.responseAsString = self.responseBytes.getString(0,self.responseBytes.length,haxe_io_Encoding.UTF8)
        return self.responseAsString

haxe_http_HttpBase._hx_class = haxe_http_HttpBase
_hx_classes["haxe.http.HttpBase"] = haxe_http_HttpBase


class haxe_io_Bytes:
    _hx_class_name = "haxe.io.Bytes"
    _hx_is_interface = "False"
    __slots__ = ("length", "b")
    _hx_fields = ["length", "b"]
    _hx_methods = ["sub", "getString", "toString"]
    _hx_statics = ["alloc", "ofString"]

    def __init__(self,length,b):
        self.length = length
        self.b = b

    def sub(self,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        return haxe_io_Bytes(_hx_len,self.b[pos:(pos + _hx_len)])

    def getString(self,pos,_hx_len,encoding = None):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        return self.b[pos:pos+_hx_len].decode('UTF-8','replace')

    def toString(self):
        return self.getString(0,self.length)

    @staticmethod
    def alloc(length):
        return haxe_io_Bytes(length,bytearray(length))

    @staticmethod
    def ofString(s,encoding = None):
        b = bytearray(s,"UTF-8")
        return haxe_io_Bytes(len(b),b)

haxe_io_Bytes._hx_class = haxe_io_Bytes
_hx_classes["haxe.io.Bytes"] = haxe_io_Bytes


class haxe_io_BytesBuffer:
    _hx_class_name = "haxe.io.BytesBuffer"
    _hx_is_interface = "False"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["getBytes"]

    def __init__(self):
        self.b = bytearray()

    def getBytes(self):
        _hx_bytes = haxe_io_Bytes(len(self.b),self.b)
        self.b = None
        return _hx_bytes

haxe_io_BytesBuffer._hx_class = haxe_io_BytesBuffer
_hx_classes["haxe.io.BytesBuffer"] = haxe_io_BytesBuffer


class haxe_io_Output:
    _hx_class_name = "haxe.io.Output"
    _hx_is_interface = "False"
    __slots__ = ("bigEndian",)
    _hx_fields = ["bigEndian"]
    _hx_methods = ["writeByte", "writeBytes", "close", "set_bigEndian", "writeFullBytes", "prepare", "writeString"]

    def writeByte(self,c):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "haxe/io/Output.hx", 'lineNumber': 47, 'className': "haxe.io.Output", 'methodName': "writeByte"}))

    def writeBytes(self,s,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        b = s.b
        k = _hx_len
        while (k > 0):
            self.writeByte(b[pos])
            pos = (pos + 1)
            k = (k - 1)
        return _hx_len

    def close(self):
        pass

    def set_bigEndian(self,b):
        self.bigEndian = b
        return b

    def writeFullBytes(self,s,pos,_hx_len):
        while (_hx_len > 0):
            k = self.writeBytes(s,pos,_hx_len)
            pos = (pos + k)
            _hx_len = (_hx_len - k)

    def prepare(self,nbytes):
        pass

    def writeString(self,s,encoding = None):
        b = haxe_io_Bytes.ofString(s,encoding)
        self.writeFullBytes(b,0,b.length)

haxe_io_Output._hx_class = haxe_io_Output
_hx_classes["haxe.io.Output"] = haxe_io_Output


class haxe_io_BytesOutput(haxe_io_Output):
    _hx_class_name = "haxe.io.BytesOutput"
    _hx_is_interface = "False"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["writeByte", "writeBytes", "getBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self):
        self.b = haxe_io_BytesBuffer()
        self.set_bigEndian(False)

    def writeByte(self,c):
        self.b.b.append(c)

    def writeBytes(self,buf,pos,_hx_len):
        _this = self.b
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > buf.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        _this.b.extend(buf.b[pos:(pos + _hx_len)])
        return _hx_len

    def getBytes(self):
        return self.b.getBytes()

haxe_io_BytesOutput._hx_class = haxe_io_BytesOutput
_hx_classes["haxe.io.BytesOutput"] = haxe_io_BytesOutput

class haxe_io_Encoding(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.io.Encoding"
    _hx_constructs = ["UTF8", "RawNative"]
haxe_io_Encoding.UTF8 = haxe_io_Encoding("UTF8", 0, ())
haxe_io_Encoding.RawNative = haxe_io_Encoding("RawNative", 1, ())
haxe_io_Encoding._hx_class = haxe_io_Encoding
_hx_classes["haxe.io.Encoding"] = haxe_io_Encoding


class haxe_io_Eof:
    _hx_class_name = "haxe.io.Eof"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["toString"]

    def __init__(self):
        pass

    def toString(self):
        return "Eof"

haxe_io_Eof._hx_class = haxe_io_Eof
_hx_classes["haxe.io.Eof"] = haxe_io_Eof

class haxe_io_Error(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.io.Error"
    _hx_constructs = ["Blocked", "Overflow", "OutsideBounds", "Custom"]

    @staticmethod
    def Custom(e):
        return haxe_io_Error("Custom", 3, (e,))
haxe_io_Error.Blocked = haxe_io_Error("Blocked", 0, ())
haxe_io_Error.Overflow = haxe_io_Error("Overflow", 1, ())
haxe_io_Error.OutsideBounds = haxe_io_Error("OutsideBounds", 2, ())
haxe_io_Error._hx_class = haxe_io_Error
_hx_classes["haxe.io.Error"] = haxe_io_Error


class haxe_io_Input:
    _hx_class_name = "haxe.io.Input"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["readByte", "readBytes"]

    def readByte(self):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "haxe/io/Input.hx", 'lineNumber': 53, 'className': "haxe.io.Input", 'methodName': "readByte"}))

    def readBytes(self,s,pos,_hx_len):
        k = _hx_len
        b = s.b
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        try:
            while (k > 0):
                b[pos] = self.readByte()
                pos = (pos + 1)
                k = (k - 1)
        except BaseException as _g:
            None
            if (not Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof)):
                raise _g
        return (_hx_len - k)

haxe_io_Input._hx_class = haxe_io_Input
_hx_classes["haxe.io.Input"] = haxe_io_Input


class haxe_iterators_ArrayIterator:
    _hx_class_name = "haxe.iterators.ArrayIterator"
    _hx_is_interface = "False"
    __slots__ = ("array", "current")
    _hx_fields = ["array", "current"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        self.current = 0
        self.array = array

    def hasNext(self):
        return (self.current < len(self.array))

    def next(self):
        def _hx_local_3():
            def _hx_local_2():
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return python_internal_ArrayImpl._get(self.array, _hx_local_2())
        return _hx_local_3()

haxe_iterators_ArrayIterator._hx_class = haxe_iterators_ArrayIterator
_hx_classes["haxe.iterators.ArrayIterator"] = haxe_iterators_ArrayIterator


class haxe_iterators_ArrayKeyValueIterator:
    _hx_class_name = "haxe.iterators.ArrayKeyValueIterator"
    _hx_is_interface = "False"
    __slots__ = ("current", "array")
    _hx_fields = ["current", "array"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        self.current = 0
        self.array = array

    def hasNext(self):
        return (self.current < len(self.array))

    def next(self):
        def _hx_local_3():
            def _hx_local_2():
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return _hx_AnonObject({'value': python_internal_ArrayImpl._get(self.array, self.current), 'key': _hx_local_2()})
        return _hx_local_3()

haxe_iterators_ArrayKeyValueIterator._hx_class = haxe_iterators_ArrayKeyValueIterator
_hx_classes["haxe.iterators.ArrayKeyValueIterator"] = haxe_iterators_ArrayKeyValueIterator


class haxe_iterators_MapKeyValueIterator:
    _hx_class_name = "haxe.iterators.MapKeyValueIterator"
    _hx_is_interface = "False"
    __slots__ = ("map", "keys")
    _hx_fields = ["map", "keys"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,_hx_map):
        self.map = _hx_map
        self.keys = _hx_map.keys()

    def hasNext(self):
        return self.keys.hasNext()

    def next(self):
        key = self.keys.next()
        return _hx_AnonObject({'value': self.map.get(key), 'key': key})

haxe_iterators_MapKeyValueIterator._hx_class = haxe_iterators_MapKeyValueIterator
_hx_classes["haxe.iterators.MapKeyValueIterator"] = haxe_iterators_MapKeyValueIterator


class haxe_rtti_Meta:
    _hx_class_name = "haxe.rtti.Meta"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["getType", "getMeta", "getFields"]

    @staticmethod
    def getType(t):
        meta = haxe_rtti_Meta.getMeta(t)
        if ((meta is None) or ((Reflect.field(meta,"obj") is None))):
            return _hx_AnonObject({})
        else:
            return Reflect.field(meta,"obj")

    @staticmethod
    def getMeta(t):
        return Reflect.field(t,"__meta__")

    @staticmethod
    def getFields(t):
        meta = haxe_rtti_Meta.getMeta(t)
        if ((meta is None) or ((Reflect.field(meta,"fields") is None))):
            return _hx_AnonObject({})
        else:
            return Reflect.field(meta,"fields")
haxe_rtti_Meta._hx_class = haxe_rtti_Meta
_hx_classes["haxe.rtti.Meta"] = haxe_rtti_Meta


class parsihax__ParseObject_ParseObject_Impl_:
    _hx_class_name = "parsihax._ParseObject.ParseObject_Impl_"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["_new", "get_apply", "set_apply", "to", "opAdd", "opOr", "opDiv"]
    apply = None

    @staticmethod
    def _new():
        return [None]*1

    @staticmethod
    def get_apply(this1):
        return this1[0]

    @staticmethod
    def set_apply(this1,param):
        this1[0] = param
        return param

    @staticmethod
    def to(v):
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def opAdd(l,r):
        return parsihax_Parser.then(l,r)

    @staticmethod
    def opOr(l,r):
        return parsihax_Parser._hx_or(l,r)

    @staticmethod
    def opDiv(l,r):
        return parsihax_Parser._hx_as(l,r)
parsihax__ParseObject_ParseObject_Impl_._hx_class = parsihax__ParseObject_ParseObject_Impl_
_hx_classes["parsihax._ParseObject.ParseObject_Impl_"] = parsihax__ParseObject_ParseObject_Impl_


class parsihax_ParseUtil:
    _hx_class_name = "parsihax.ParseUtil"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["formatError", "makeSuccess", "makeFailure", "mergeReplies", "unsafeUnion"]

    @staticmethod
    def formatError(result,stream):
        sexpected = None
        if (len(result.expected) == 1):
            sexpected = (result.expected[0] if 0 < len(result.expected) else None)
        else:
            _this = result.expected
            sexpected = ("one of " + HxOverrides.stringOrNull(", ".join([python_Boot.toString1(x1,'') for x1 in _this])))
        indexOffset = result.furthest
        lines = HxString.substring(stream,0,indexOffset).split("\n")
        got = ""
        if (indexOffset == len(stream)):
            got = ", got the end of the stream"
        else:
            suffix = ("...'" if (((len(stream) - indexOffset) > 12)) else "'")
            got = (((((((" at line " + Std.string(len(lines))) + " column ") + Std.string(((len(python_internal_ArrayImpl._get(lines, (len(lines) - 1))) + 1)))) + ", got ") + HxOverrides.stringOrNull((("'..." if ((indexOffset > 0)) else "'")))) + HxOverrides.stringOrNull(HxString.substring(stream,indexOffset,(indexOffset + 12)))) + ("null" if suffix is None else suffix))
        return (("expected " + ("null" if sexpected is None else sexpected)) + ("null" if got is None else got))

    @staticmethod
    def makeSuccess(index,value):
        return _hx_AnonObject({'status': True, 'index': index, 'value': value, 'furthest': -1, 'expected': []})

    @staticmethod
    def makeFailure(index,expected):
        return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': index, 'expected': [expected]})

    @staticmethod
    def mergeReplies(result,last = None):
        if (last is None):
            return result
        if (result.furthest > last.furthest):
            return result
        expected = (parsihax_ParseUtil.unsafeUnion(result.expected,last.expected) if ((result.furthest == last.furthest)) else last.expected)
        return _hx_AnonObject({'status': result.status, 'index': result.index, 'value': result.value, 'furthest': last.furthest, 'expected': expected})

    @staticmethod
    def unsafeUnion(xs,ys):
        if (len(xs) == 0):
            return ys
        elif (len(ys) == 0):
            return xs
        result = (xs + ys)
        def _hx_local_0(a,b):
            a = a.lower()
            b = b.lower()
            if (a < b):
                return -1
            if (a > b):
                return 1
            return 0
        result.sort(key= python_lib_Functools.cmp_to_key(_hx_local_0))
        return result
parsihax_ParseUtil._hx_class = parsihax_ParseUtil
_hx_classes["parsihax.ParseUtil"] = parsihax_ParseUtil


class parsihax_Parser:
    _hx_class_name = "parsihax.Parser"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["index", "letter", "letters", "digit", "digits", "whitespace", "optWhitespace", "any", "all", "eof", "string", "char", "oneOf", "noneOf", "regexp", "succeed", "fail", "empty", "seq", "alt", "sepBy", "sepBy1", "test", "takeWhile", "or", "flatMap", "then", "map", "result", "skip", "many", "many1", "times", "atMost", "atLeast", "as", "lazy"]

    @staticmethod
    def index():
        ret = [None]*1
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            return _hx_AnonObject({'status': True, 'index': i, 'value': i, 'furthest': -1, 'expected': []})
        ret[0] = _hx_local_0
        return ret

    @staticmethod
    def letter():
        return parsihax_Parser._hx_as(parsihax_Parser.regexp(EReg("[a-z]","i")),"a letter")

    @staticmethod
    def letters():
        return parsihax_Parser.regexp(EReg("[a-z]*","i"))

    @staticmethod
    def digit():
        return parsihax_Parser._hx_as(parsihax_Parser.regexp(EReg("[0-9]","")),"a digit")

    @staticmethod
    def digits():
        return parsihax_Parser.regexp(EReg("[0-9]*",""))

    @staticmethod
    def whitespace():
        return parsihax_Parser._hx_as(parsihax_Parser.regexp(EReg("\\s+","")),"whitespace")

    @staticmethod
    def optWhitespace():
        return parsihax_Parser.regexp(EReg("\\s*",""))

    @staticmethod
    def any():
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            if (i >= len(stream)):
                return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': i, 'expected': ["any character"]})
            else:
                return _hx_AnonObject({'status': True, 'index': (i + 1), 'value': ("" if (((i < 0) or ((i >= len(stream))))) else stream[i]), 'furthest': -1, 'expected': []})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def all():
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            return _hx_AnonObject({'status': True, 'index': len(stream), 'value': HxString.substring(stream,i,None), 'furthest': -1, 'expected': []})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def eof():
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            if (i < len(stream)):
                return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': i, 'expected': ["EOF"]})
            else:
                return _hx_AnonObject({'status': True, 'index': i, 'value': None, 'furthest': -1, 'expected': []})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def string(string):
        _hx_len = len(string)
        expected = (("'" + ("null" if string is None else string)) + "'")
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            head = HxString.substring(stream,i,(i + _hx_len))
            if (head == string):
                return _hx_AnonObject({'status': True, 'index': (i + _hx_len), 'value': head, 'furthest': -1, 'expected': []})
            else:
                return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': i, 'expected': [expected]})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def char(character):
        def _hx_local_1():
            def _hx_local_0(ch):
                return (character == ch)
            return parsihax_Parser._hx_as(parsihax_Parser.test(_hx_local_0),(("'" + ("null" if character is None else character)) + "'"))
        return _hx_local_1()

    @staticmethod
    def oneOf(string):
        def _hx_local_1():
            def _hx_local_0(ch):
                return (string.find(ch) >= 0)
            return parsihax_Parser.test(_hx_local_0)
        return _hx_local_1()

    @staticmethod
    def noneOf(string):
        def _hx_local_1():
            def _hx_local_0(ch):
                return (string.find(ch) < 0)
            return parsihax_Parser.test(_hx_local_0)
        return _hx_local_1()

    @staticmethod
    def regexp(re,group = None):
        if (group is None):
            group = 0
        expected = Std.string(re)
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            s = HxString.substring(stream,i,None)
            re.matchObj = python_lib_Re.search(re.pattern,s)
            if (re.matchObj is not None):
                groupMatch = re.matchObj.group(group)
                pos_pos = re.matchObj.start()
                pos_len = (re.matchObj.end() - re.matchObj.start())
                if ((groupMatch is not None) and ((pos_pos == 0))):
                    return _hx_AnonObject({'status': True, 'index': (i + pos_len), 'value': groupMatch, 'furthest': -1, 'expected': []})
            return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': i, 'expected': [expected]})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def succeed(value):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            return _hx_AnonObject({'status': True, 'index': i, 'value': value, 'furthest': -1, 'expected': []})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def fail(expected):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': i, 'expected': [expected]})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def empty():
        return parsihax_Parser.fail("empty")

    @staticmethod
    def seq(parsers):
        if (len(parsers) == 0):
            return parsihax_Parser.fail("sequence of parsers")
        def _hx_local_2(stream,i = None):
            if (i is None):
                i = 0
            result = None
            accum = []
            _g = 0
            while (_g < len(parsers)):
                def _hx_local_1():
                    nonlocal _g
                    _hx_local_0 = _g
                    _g = (_g + 1)
                    return _hx_local_0
                parser = python_internal_ArrayImpl._get(parsers, _hx_local_1())
                result = parsihax_ParseUtil.mergeReplies(parser[0](stream,i),result)
                if (not result.status):
                    return result
                x = result.value
                accum.append(x)
                i = result.index
            return parsihax_ParseUtil.mergeReplies(_hx_AnonObject({'status': True, 'index': i, 'value': accum, 'furthest': -1, 'expected': []}),result)
        v = _hx_local_2
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def alt(parsers):
        if (len(parsers) == 0):
            return parsihax_Parser.fail("at least one alt")
        def _hx_local_2(stream,i = None):
            if (i is None):
                i = 0
            result = None
            _g = 0
            while (_g < len(parsers)):
                def _hx_local_1():
                    nonlocal _g
                    _hx_local_0 = _g
                    _g = (_g + 1)
                    return _hx_local_0
                parser = python_internal_ArrayImpl._get(parsers, _hx_local_1())
                result = parsihax_ParseUtil.mergeReplies(parser[0](stream,i),result)
                if result.status:
                    return result
            return result
        v = _hx_local_2
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def sepBy(parser,separator):
        return parsihax_Parser._hx_or(parsihax_Parser.sepBy1(parser,separator),parsihax_Parser.succeed([]))

    @staticmethod
    def sepBy1(parser,separator):
        pairs = parsihax_Parser.many(parsihax_Parser.then(separator,parser))
        def _hx_local_3():
            def _hx_local_2(r):
                def _hx_local_1():
                    def _hx_local_0(rs):
                        return ([r] + rs)
                    return parsihax_Parser.map(pairs,_hx_local_0)
                return _hx_local_1()
            return parsihax_Parser.flatMap(parser,_hx_local_2)
        return _hx_local_3()

    @staticmethod
    def test(predicate):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            char = ("" if (((i < 0) or ((i >= len(stream))))) else stream[i])
            if ((i < len(stream)) and predicate(char)):
                return _hx_AnonObject({'status': True, 'index': (i + 1), 'value': char, 'furthest': -1, 'expected': []})
            else:
                return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': i, 'expected': [("a character matching " + Std.string(predicate))]})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def takeWhile(predicate):
        def _hx_local_1(stream,i = None):
            if (i is None):
                i = 0
            j = i
            while ((j < len(stream)) and predicate(("" if (((j < 0) or ((j >= len(stream))))) else stream[j]))):
                j = (j + 1)
            return _hx_AnonObject({'status': True, 'index': j, 'value': HxString.substring(stream,i,j), 'furthest': -1, 'expected': []})
        v = _hx_local_1
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def _hx_or(parser,alternative):
        return parsihax_Parser.alt([parser, alternative])

    @staticmethod
    def flatMap(parser,fun):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            result = parser[0](stream,i)
            if (not result.status):
                return result
            return parsihax_ParseUtil.mergeReplies(fun(result.value)[0](stream,result.index),result)
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def then(parser,next):
        def _hx_local_1():
            def _hx_local_0(result):
                return next
            return parsihax_Parser.flatMap(parser,_hx_local_0)
        return _hx_local_1()

    @staticmethod
    def map(parser,fun):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            result = parser[0](stream,i)
            if (not result.status):
                return result
            return parsihax_ParseUtil.mergeReplies(_hx_AnonObject({'status': True, 'index': result.index, 'value': fun(result.value), 'furthest': -1, 'expected': []}),result)
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def result(parser,value):
        def _hx_local_1():
            def _hx_local_0(_):
                return value
            return parsihax_Parser.map(parser,_hx_local_0)
        return _hx_local_1()

    @staticmethod
    def skip(parser,next):
        def _hx_local_1():
            def _hx_local_0(result):
                return parsihax_Parser.result(next,result)
            return parsihax_Parser.flatMap(parser,_hx_local_0)
        return _hx_local_1()

    @staticmethod
    def many(parser):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            accum = []
            result = None
            while True:
                result = parsihax_ParseUtil.mergeReplies(parser[0](stream,i),result)
                if result.status:
                    i = result.index
                    x = result.value
                    accum.append(x)
                else:
                    return parsihax_ParseUtil.mergeReplies(_hx_AnonObject({'status': True, 'index': i, 'value': accum, 'furthest': -1, 'expected': []}),result)
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def many1(parser):
        return parsihax_Parser.atLeast(parser,1)

    @staticmethod
    def times(parser,_hx_min,_hx_max = None):
        if (_hx_max is None):
            _hx_max = _hx_min
        def _hx_local_2(stream,i = None):
            if (i is None):
                i = 0
            accum = []
            result = None
            prevParseResult = None
            _g = 0
            _g1 = _hx_min
            while (_g < _g1):
                _g = (_g + 1)
                result = parser[0](stream,i)
                prevParseResult = parsihax_ParseUtil.mergeReplies(result,prevParseResult)
                if result.status:
                    i = result.index
                    x = result.value
                    accum.append(x)
                else:
                    return prevParseResult
            _g = 0
            _g1 = _hx_max
            while (_g < _g1):
                _g = (_g + 1)
                result = parser[0](stream,i)
                prevParseResult = parsihax_ParseUtil.mergeReplies(result,prevParseResult)
                if result.status:
                    i = result.index
                    x = result.value
                    accum.append(x)
                else:
                    break
            return parsihax_ParseUtil.mergeReplies(_hx_AnonObject({'status': True, 'index': i, 'value': accum, 'furthest': -1, 'expected': []}),prevParseResult)
        v = _hx_local_2
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def atMost(parser,n):
        return parsihax_Parser.times(parser,0,n)

    @staticmethod
    def atLeast(parser,n):
        def _hx_local_1():
            def _hx_local_0(results):
                return ((results[0] if 0 < len(results) else None) + (results[1] if 1 < len(results) else None))
            return parsihax_Parser.map(parsihax_Parser.seq([parsihax_Parser.times(parser,n), parsihax_Parser.many(parser)]),_hx_local_0)
        return _hx_local_1()

    @staticmethod
    def _hx_as(parser,expected):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            reply = parser[0](stream,i)
            if (not reply.status):
                reply.expected = [expected]
            return reply
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def lazy(fun):
        parser = None
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            param = fun()[0]
            parser[0] = param
            return param(stream,i)
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        parser = ret
        return parser
parsihax_Parser._hx_class = parsihax_Parser
_hx_classes["parsihax.Parser"] = parsihax_Parser


class pw_tales_cofdsystem_CofDSystem:
    _hx_class_name = "pw.tales.cofdsystem.CofDSystem"
    _hx_is_interface = "False"
    __slots__ = ("dices", "gameObjects", "traits", "weapons", "armors", "events")
    _hx_fields = ["dices", "gameObjects", "traits", "weapons", "armors", "events"]
    _hx_methods = ["updateWithData"]
    _hx_statics = ["VERSION", "VERSION_CHECK", "fromData"]

    def __init__(self):
        self.events = pw_tales_cofdsystem_utils_events_EventBus()
        self.armors = pw_tales_cofdsystem_utils_registry_Registry(True)
        self.weapons = pw_tales_cofdsystem_utils_registry_Registry(True)
        self.traits = pw_tales_cofdsystem_TraitTypeRegistry()
        self.gameObjects = pw_tales_cofdsystem_utils_registry_Registry()
        self.dices = pw_tales_cofdsystem_dices_DiceRoller()

    def updateWithData(self,data):
        pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization.INSTANCE.updateWithData(self,data)

    @staticmethod
    def fromData(data):
        return pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization.INSTANCE.fromData(data)

pw_tales_cofdsystem_CofDSystem._hx_class = pw_tales_cofdsystem_CofDSystem
_hx_classes["pw.tales.cofdsystem.CofDSystem"] = pw_tales_cofdsystem_CofDSystem


class pw_tales_cofdsystem_LibVersion:
    _hx_class_name = "pw.tales.cofdsystem.LibVersion"
    _hx_is_interface = "False"
    __slots__ = ()
pw_tales_cofdsystem_LibVersion._hx_class = pw_tales_cofdsystem_LibVersion
_hx_classes["pw.tales.cofdsystem.LibVersion"] = pw_tales_cofdsystem_LibVersion


class pw_tales_cofdsystem_utils_registry_Registry:
    _hx_class_name = "pw.tales.cofdsystem.utils.registry.Registry"
    _hx_is_interface = "False"
    __slots__ = ("registry", "normalize", "allowOverwrite")
    _hx_fields = ["registry", "normalize", "allowOverwrite"]
    _hx_methods = ["normalizeDn", "getDN", "getRecord", "saveRecord", "register", "unregister", "items", "clear", "toString"]

    def __init__(self,normalize = None,allowOverwrite = None):
        if (normalize is None):
            normalize = False
        if (allowOverwrite is None):
            allowOverwrite = False
        self.registry = haxe_ds_StringMap()
        self.normalize = normalize
        self.allowOverwrite = allowOverwrite

    def normalizeDn(self,dn):
        return StringTools.replace(dn.lower()," ","_")

    def getDN(self,record):
        dn = record.getDN()
        if self.normalize:
            dn = self.normalizeDn(dn)
        return dn

    def getRecord(self,dn):
        if self.normalize:
            dn = self.normalizeDn(dn)
        return self.registry.h.get(dn,None)

    def saveRecord(self,record):
        dn = self.getDN(record)
        if ((dn in self.registry.h) and (not self.allowOverwrite)):
            raise pw_tales_cofdsystem_utils_registry_exceptions_OverwriteForbiddenException(dn,self.registry.h.get(dn,None),record)
        self.registry.h[dn] = record

    def register(self,record):
        self.saveRecord(record)
        return self

    def unregister(self,record):
        dn = self.getDN(record)
        self.registry.remove(dn)

    def items(self):
        _g = []
        value = self.registry.iterator()
        while value.hasNext():
            value1 = value.next()
            _g.append(value1)
        return _g

    def clear(self):
        self.registry.h.clear()

    def toString(self):
        return (("Registry[" + HxOverrides.stringOrNull((("null" if ((self.registry is None)) else self.registry.toString())))) + "}]")

pw_tales_cofdsystem_utils_registry_Registry._hx_class = pw_tales_cofdsystem_utils_registry_Registry
_hx_classes["pw.tales.cofdsystem.utils.registry.Registry"] = pw_tales_cofdsystem_utils_registry_Registry


class pw_tales_cofdsystem_TraitTypeRegistry(pw_tales_cofdsystem_utils_registry_Registry):
    _hx_class_name = "pw.tales.cofdsystem.TraitTypeRegistry"
    _hx_is_interface = "False"
    __slots__ = ("registartionMap",)
    _hx_fields = ["registartionMap"]
    _hx_methods = ["autoregister", "registerFromClass"]
    _hx_statics = ["AUTOREGISTER_ANNOTATION"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_registry_Registry


    def __init__(self):
        self.registartionMap = haxe_ds_StringMap()
        super().__init__(True)
        self.autoregister()
        pw_tales_cofdsystem_character_traits_merits_Merit.CUSTOM_MERIT_TYPE.setName("Пользовательское Достоинство")

    def autoregister(self):
        try:
            _g_head = CompileTimeClassList.get("pw.tales.cofdsystem,true,").h
            while (_g_head is not None):
                val = _g_head.item
                _g_head = _g_head.next
                if python_Boot.hasField(haxe_rtti_Meta.getType(val),pw_tales_cofdsystem_TraitTypeRegistry.AUTOREGISTER_ANNOTATION):
                    self.registerFromClass(val)
        except BaseException as _g:
            raise haxe_Exception.thrown(haxe_Exception.caught(_g))

    def registerFromClass(self,clazz):
        _g = 0
        _g1 = python_Boot.getClassFields(clazz)
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            fieldName = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            field = Reflect.getProperty(clazz,fieldName)
            if Std.isOfType(field,pw_tales_cofdsystem_game_object_traits_TraitType):
                traitType = field
                self.register(traitType)
                this1 = self.registartionMap
                key = traitType.getDN()
                this1.h[key] = clazz

pw_tales_cofdsystem_TraitTypeRegistry._hx_class = pw_tales_cofdsystem_TraitTypeRegistry
_hx_classes["pw.tales.cofdsystem.TraitTypeRegistry"] = pw_tales_cofdsystem_TraitTypeRegistry


class pw_tales_cofdsystem_action_IAction:
    _hx_class_name = "pw.tales.cofdsystem.action.IAction"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getActionTime", "getActor", "getEventBus", "getSystem", "addModification", "getModifications", "isRelated", "execute"]
pw_tales_cofdsystem_action_IAction._hx_class = pw_tales_cofdsystem_action_IAction
_hx_classes["pw.tales.cofdsystem.action.IAction"] = pw_tales_cofdsystem_action_IAction


class pw_tales_cofdsystem_action_Action:
    _hx_class_name = "pw.tales.cofdsystem.action.Action"
    _hx_is_interface = "False"
    __slots__ = ("system", "time", "eventBus", "modifications")
    _hx_fields = ["system", "time", "eventBus", "modifications"]
    _hx_methods = ["getSystem", "getEventBus", "addModification", "getModifications", "getActionTime", "beforeAction", "perform", "afterAction", "execute", "getActor", "isRelated"]
    _hx_interfaces = [pw_tales_cofdsystem_action_IAction]

    def __init__(self,time,system):
        self.eventBus = None
        self.time = None
        self.system = None
        self.modifications = []
        _gthis = self
        self.time = time
        self.system = system
        def _hx_local_0(event):
            actionEvent = pw_tales_cofdsystem_utils_Utility.downcast(event,pw_tales_cofdsystem_action_events_IActionEvent)
            if (actionEvent is None):
                return False
            return actionEvent.isRelatedAction(_gthis)
        self.eventBus = pw_tales_cofdsystem_utils_events_SubEventBus(system.events,_hx_local_0)

    def getSystem(self):
        return self.system

    def getEventBus(self):
        return self.eventBus

    def addModification(self,modification):
        self.modifications.append(modification)
        modification.init(self)

    def getModifications(self):
        return self.modifications

    def getActionTime(self):
        return self.time

    def beforeAction(self):
        pass

    def perform(self):
        pass

    def afterAction(self):
        self.eventBus.post(pw_tales_cofdsystem_action_events_ActionPerformedEvent(self))
        self.eventBus.disable()

    def execute(self):
        self.beforeAction()
        self.perform()
        self.afterAction()

    def getActor(self):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/action/Action.hx", 'lineNumber': 81, 'className': "pw.tales.cofdsystem.action.Action", 'methodName': "getActor"}))

    def isRelated(self,gameObject):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/action/Action.hx", 'lineNumber': 86, 'className': "pw.tales.cofdsystem.action.Action", 'methodName': "isRelated"}))

pw_tales_cofdsystem_action_Action._hx_class = pw_tales_cofdsystem_action_Action
_hx_classes["pw.tales.cofdsystem.action.Action"] = pw_tales_cofdsystem_action_Action

class pw_tales_cofdsystem_action_EnumTime(Enum):
    __slots__ = ()
    _hx_class_name = "pw.tales.cofdsystem.action.EnumTime"
    _hx_constructs = ["INSTANT", "REFLEXIVE", "EXTENDED"]
pw_tales_cofdsystem_action_EnumTime.INSTANT = pw_tales_cofdsystem_action_EnumTime("INSTANT", 0, ())
pw_tales_cofdsystem_action_EnumTime.REFLEXIVE = pw_tales_cofdsystem_action_EnumTime("REFLEXIVE", 1, ())
pw_tales_cofdsystem_action_EnumTime.EXTENDED = pw_tales_cofdsystem_action_EnumTime("EXTENDED", 2, ())
pw_tales_cofdsystem_action_EnumTime._hx_class = pw_tales_cofdsystem_action_EnumTime
_hx_classes["pw.tales.cofdsystem.action.EnumTime"] = pw_tales_cofdsystem_action_EnumTime


class pw_tales_cofdsystem_action_IActionRoll:
    _hx_class_name = "pw.tales.cofdsystem.action.IActionRoll"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getActor", "getActorPool", "willRoll", "isRelated", "roll"]
pw_tales_cofdsystem_action_IActionRoll._hx_class = pw_tales_cofdsystem_action_IActionRoll
_hx_classes["pw.tales.cofdsystem.action.IActionRoll"] = pw_tales_cofdsystem_action_IActionRoll


class pw_tales_cofdsystem_action_IModification:
    _hx_class_name = "pw.tales.cofdsystem.action.IModification"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["init"]
pw_tales_cofdsystem_action_IModification._hx_class = pw_tales_cofdsystem_action_IModification
_hx_classes["pw.tales.cofdsystem.action.IModification"] = pw_tales_cofdsystem_action_IModification


class pw_tales_cofdsystem_action_NoRollAction(pw_tales_cofdsystem_action_Action):
    _hx_class_name = "pw.tales.cofdsystem.action.NoRollAction"
    _hx_is_interface = "False"
    __slots__ = ("actor",)
    _hx_fields = ["actor"]
    _hx_methods = ["getActor", "isRelated"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_Action


    def __init__(self,actor,time,system):
        self.actor = None
        super().__init__(time,system)
        self.actor = actor

    def getActor(self):
        return self.actor

    def isRelated(self,gameObject):
        return (self.actor == gameObject)

pw_tales_cofdsystem_action_NoRollAction._hx_class = pw_tales_cofdsystem_action_NoRollAction
_hx_classes["pw.tales.cofdsystem.action.NoRollAction"] = pw_tales_cofdsystem_action_NoRollAction


class pw_tales_cofdsystem_action_RollAction(pw_tales_cofdsystem_action_Action):
    _hx_class_name = "pw.tales.cofdsystem.action.RollAction"
    _hx_is_interface = "False"
    __slots__ = ("actionRoll",)
    _hx_fields = ["actionRoll"]
    _hx_methods = ["getActor", "getActionRoll", "isRelated", "roll", "execute"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_Action


    def __init__(self,actionRoll,time,system):
        self.actionRoll = None
        super().__init__(time,system)
        self.actionRoll = actionRoll

    def getActor(self):
        return self.actionRoll.getActor()

    def getActionRoll(self):
        return self.actionRoll

    def isRelated(self,gameObject):
        return self.actionRoll.isRelated(gameObject)

    def roll(self):
        self.actionRoll.roll(self)

    def execute(self):
        self.beforeAction()
        self.roll()
        self.perform()
        self.afterAction()

pw_tales_cofdsystem_action_RollAction._hx_class = pw_tales_cofdsystem_action_RollAction
_hx_classes["pw.tales.cofdsystem.action.RollAction"] = pw_tales_cofdsystem_action_RollAction


class pw_tales_cofdsystem_action_competition_Competition:
    _hx_class_name = "pw.tales.cofdsystem.action.competition.Competition"
    _hx_is_interface = "False"
    __slots__ = ("actorPool", "targetPool")
    _hx_fields = ["actorPool", "targetPool"]
    _hx_methods = ["willRoll", "getWinnerPool", "isRelated", "getActorPool", "getTargetPool", "getActor", "getTarget", "getPool", "roll"]
    _hx_interfaces = [pw_tales_cofdsystem_action_IActionRoll]

    def __init__(self,actorPool,targetPool):
        self.actorPool = actorPool
        self.targetPool = targetPool

    def willRoll(self,roll):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/action/competition/Competition.hx", 'lineNumber': 20, 'className': "pw.tales.cofdsystem.action.competition.Competition", 'methodName': "willRoll"}))

    def getWinnerPool(self):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/action/competition/Competition.hx", 'lineNumber': 25, 'className': "pw.tales.cofdsystem.action.competition.Competition", 'methodName': "getWinnerPool"}))

    def isRelated(self,gameObject):
        if (not self.actorPool.isRelated(gameObject)):
            return self.targetPool.isRelated(gameObject)
        else:
            return True

    def getActorPool(self):
        return self.actorPool

    def getTargetPool(self):
        return self.targetPool

    def getActor(self):
        return self.actorPool.getGameObject()

    def getTarget(self):
        return self.targetPool.getGameObject()

    def getPool(self,gameObject):
        if self.actorPool.isRelated(gameObject):
            return self.actorPool
        if self.targetPool.isRelated(gameObject):
            return self.targetPool
        raise haxe_Exception.thrown("${gameObject} is not part of action.")

    def roll(self,action):
        pass

pw_tales_cofdsystem_action_competition_Competition._hx_class = pw_tales_cofdsystem_action_competition_Competition
_hx_classes["pw.tales.cofdsystem.action.competition.Competition"] = pw_tales_cofdsystem_action_competition_Competition


class pw_tales_cofdsystem_action_competition_Contested(pw_tales_cofdsystem_action_competition_Competition):
    _hx_class_name = "pw.tales.cofdsystem.action.competition.Contested"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getWinnerPool", "willRoll", "roll"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_competition_Competition


    def __init__(self,actorPool,targetPool):
        super().__init__(actorPool,targetPool)

    def getWinnerPool(self):
        actorRollResponse = self.actorPool.getResponse()
        targetRollResponse = self.targetPool.getResponse()
        if (actorRollResponse.getSuccesses() > targetRollResponse.getSuccesses()):
            return self.actorPool
        return self.targetPool

    def willRoll(self,roll):
        if (roll != self.actorPool):
            return (roll == self.targetPool)
        else:
            return True

    def roll(self,action):
        system = action.getSystem()
        system.events.post(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent(action,self.actorPool))
        system.events.post(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent(action,self.targetPool))
        self.actorPool.rollWithPoolEvents(action)
        self.targetPool.rollWithPoolEvents(action)

pw_tales_cofdsystem_action_competition_Contested._hx_class = pw_tales_cofdsystem_action_competition_Contested
_hx_classes["pw.tales.cofdsystem.action.competition.Contested"] = pw_tales_cofdsystem_action_competition_Contested


class pw_tales_cofdsystem_action_competition_Resisted(pw_tales_cofdsystem_action_competition_Competition):
    _hx_class_name = "pw.tales.cofdsystem.action.competition.Resisted"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getWinnerPool", "willRoll", "roll"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_competition_Competition


    def __init__(self,actorPool,targetPool):
        super().__init__(actorPool,targetPool)

    def getWinnerPool(self):
        if pw_tales_cofdsystem_dices_EnumResult.isSuccess(self.actorPool.getResponse().getResult()):
            return self.actorPool
        return self.targetPool

    def willRoll(self,roll):
        return (roll == self.actorPool)

    def roll(self,action):
        system = action.getSystem()
        system.events.post(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent(action,self.actorPool))
        system.events.post(pw_tales_cofdsystem_action_events_pool_ActionBuildResistEvent(action,self.targetPool))
        resist = self.targetPool.getRequest().getPoolSize()
        self.actorPool.getRequest().addModifier(-resist,"resist")
        self.actorPool.rollWithPoolEvents(action)

pw_tales_cofdsystem_action_competition_Resisted._hx_class = pw_tales_cofdsystem_action_competition_Resisted
_hx_classes["pw.tales.cofdsystem.action.competition.Resisted"] = pw_tales_cofdsystem_action_competition_Resisted


class pw_tales_cofdsystem_action_competition_builder_CompetitionBuilder:
    _hx_class_name = "pw.tales.cofdsystem.action.competition.builder.CompetitionBuilder"
    _hx_is_interface = "False"
    __slots__ = ("actorPoolBuilder", "targetPoolBuilder", "oppositionType")
    _hx_fields = ["actorPoolBuilder", "targetPoolBuilder", "oppositionType"]
    _hx_methods = ["getPoolBuilder", "getExplode", "setExplode", "getModifier", "setModifier", "setTraits", "setOppositionType", "build"]
    _hx_statics = ["create"]

    def __init__(self,actorPoolBuilder,targetPoolBuilder):
        self.oppositionType = pw_tales_cofdsystem_action_competition_builder_EnumCompetition.CONTESTED
        self.actorPoolBuilder = actorPoolBuilder
        self.targetPoolBuilder = targetPoolBuilder

    def getPoolBuilder(self,side):
        if (side == pw_tales_cofdsystem_common_EnumSide.ACTOR):
            return self.actorPoolBuilder
        if (side == pw_tales_cofdsystem_common_EnumSide.TARGET):
            return self.targetPoolBuilder
        raise haxe_Exception.thrown("Unknown side.")

    def getExplode(self,side):
        return self.getPoolBuilder(side).getExplode()

    def setExplode(self,side,explode):
        self.getPoolBuilder(side).setExplode(explode)
        return self

    def getModifier(self,side):
        return self.getPoolBuilder(side).getModifier()

    def setModifier(self,side,modifier):
        self.getPoolBuilder(side).setModifier(modifier)
        return self

    def setTraits(self,side,traits):
        self.getPoolBuilder(side).setTraits(traits)
        return self

    def setOppositionType(self,opposition):
        self.oppositionType = opposition
        return self

    def build(self):
        obj = None
        actorRoll = self.actorPoolBuilder.build()
        targetRoll = self.targetPoolBuilder.build()
        tmp = self.oppositionType.index
        if (tmp == 0):
            obj = pw_tales_cofdsystem_action_competition_Contested(actorRoll,targetRoll)
        elif (tmp == 1):
            obj = pw_tales_cofdsystem_action_competition_Resisted(actorRoll,targetRoll)
        else:
            pass
        return obj

    @staticmethod
    def create(actor,target):
        return pw_tales_cofdsystem_action_competition_builder_CompetitionBuilder(pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder(actor),pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder(target))

pw_tales_cofdsystem_action_competition_builder_CompetitionBuilder._hx_class = pw_tales_cofdsystem_action_competition_builder_CompetitionBuilder
_hx_classes["pw.tales.cofdsystem.action.competition.builder.CompetitionBuilder"] = pw_tales_cofdsystem_action_competition_builder_CompetitionBuilder

class pw_tales_cofdsystem_action_competition_builder_EnumCompetition(Enum):
    __slots__ = ()
    _hx_class_name = "pw.tales.cofdsystem.action.competition.builder.EnumCompetition"
    _hx_constructs = ["CONTESTED", "RESISTED"]
pw_tales_cofdsystem_action_competition_builder_EnumCompetition.CONTESTED = pw_tales_cofdsystem_action_competition_builder_EnumCompetition("CONTESTED", 0, ())
pw_tales_cofdsystem_action_competition_builder_EnumCompetition.RESISTED = pw_tales_cofdsystem_action_competition_builder_EnumCompetition("RESISTED", 1, ())
pw_tales_cofdsystem_action_competition_builder_EnumCompetition._hx_class = pw_tales_cofdsystem_action_competition_builder_EnumCompetition
_hx_classes["pw.tales.cofdsystem.action.competition.builder.EnumCompetition"] = pw_tales_cofdsystem_action_competition_builder_EnumCompetition


class pw_tales_cofdsystem_utils_events_IEvent:
    _hx_class_name = "pw.tales.cofdsystem.utils.events.IEvent"
    _hx_is_interface = "True"
    __slots__ = ()
pw_tales_cofdsystem_utils_events_IEvent._hx_class = pw_tales_cofdsystem_utils_events_IEvent
_hx_classes["pw.tales.cofdsystem.utils.events.IEvent"] = pw_tales_cofdsystem_utils_events_IEvent


class pw_tales_cofdsystem_game_object_events_IGameObjectEvent:
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.IGameObjectEvent"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["isRelated"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_events_IEvent]
pw_tales_cofdsystem_game_object_events_IGameObjectEvent._hx_class = pw_tales_cofdsystem_game_object_events_IGameObjectEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.IGameObjectEvent"] = pw_tales_cofdsystem_game_object_events_IGameObjectEvent


class pw_tales_cofdsystem_action_events_IActionEvent:
    _hx_class_name = "pw.tales.cofdsystem.action.events.IActionEvent"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getAction", "isRelatedAction"]
    _hx_interfaces = [pw_tales_cofdsystem_game_object_events_IGameObjectEvent]
pw_tales_cofdsystem_action_events_IActionEvent._hx_class = pw_tales_cofdsystem_action_events_IActionEvent
_hx_classes["pw.tales.cofdsystem.action.events.IActionEvent"] = pw_tales_cofdsystem_action_events_IActionEvent


class pw_tales_cofdsystem_action_events_ActionEvent:
    _hx_class_name = "pw.tales.cofdsystem.action.events.ActionEvent"
    _hx_is_interface = "False"
    __slots__ = ("action",)
    _hx_fields = ["action"]
    _hx_methods = ["getAction", "isActor", "isRelatedAction", "isRelated"]
    _hx_interfaces = [pw_tales_cofdsystem_action_events_IActionEvent]

    def __init__(self,action):
        self.action = action

    def getAction(self):
        return self.action

    def isActor(self,gameObject):
        return (self.action.getActor() == gameObject)

    def isRelatedAction(self,action):
        return (self.action == action)

    def isRelated(self,gameObject):
        return self.action.isRelated(gameObject)

pw_tales_cofdsystem_action_events_ActionEvent._hx_class = pw_tales_cofdsystem_action_events_ActionEvent
_hx_classes["pw.tales.cofdsystem.action.events.ActionEvent"] = pw_tales_cofdsystem_action_events_ActionEvent


class pw_tales_cofdsystem_action_events_ActionGetHandEvent(pw_tales_cofdsystem_action_events_ActionEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.ActionGetHandEvent"
    _hx_is_interface = "False"
    __slots__ = ("hand", "gameObject")
    _hx_fields = ["hand", "gameObject"]
    _hx_methods = ["getGameObject", "setHand", "getHand"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_ActionEvent


    def __init__(self,action,gameObject):
        self.gameObject = None
        self.hand = pw_tales_cofdsystem_common_EnumHand.HAND
        super().__init__(action)
        self.action = action
        self.gameObject = gameObject

    def getGameObject(self):
        return self.gameObject

    def setHand(self,hand):
        self.hand = hand

    def getHand(self):
        return self.hand

pw_tales_cofdsystem_action_events_ActionGetHandEvent._hx_class = pw_tales_cofdsystem_action_events_ActionGetHandEvent
_hx_classes["pw.tales.cofdsystem.action.events.ActionGetHandEvent"] = pw_tales_cofdsystem_action_events_ActionGetHandEvent


class pw_tales_cofdsystem_action_events_ActionPerformedEvent(pw_tales_cofdsystem_action_events_ActionEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.ActionPerformedEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_ActionEvent


    def __init__(self,action):
        super().__init__(action)
pw_tales_cofdsystem_action_events_ActionPerformedEvent._hx_class = pw_tales_cofdsystem_action_events_ActionPerformedEvent
_hx_classes["pw.tales.cofdsystem.action.events.ActionPerformedEvent"] = pw_tales_cofdsystem_action_events_ActionPerformedEvent


class pw_tales_cofdsystem_game_object_events_GameObjectEvent:
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.GameObjectEvent"
    _hx_is_interface = "False"
    __slots__ = ("gameObject",)
    _hx_fields = ["gameObject"]
    _hx_methods = ["getGameObject", "isRelated"]
    _hx_interfaces = [pw_tales_cofdsystem_game_object_events_IGameObjectEvent]

    def __init__(self,gameObject):
        self.gameObject = gameObject

    def getGameObject(self):
        return self.gameObject

    def isRelated(self,gameObject):
        return (self.gameObject == gameObject)

pw_tales_cofdsystem_game_object_events_GameObjectEvent._hx_class = pw_tales_cofdsystem_game_object_events_GameObjectEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.GameObjectEvent"] = pw_tales_cofdsystem_game_object_events_GameObjectEvent


class pw_tales_cofdsystem_action_events_OffhandModiferEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.OffhandModiferEvent"
    _hx_is_interface = "False"
    __slots__ = ("modifer",)
    _hx_fields = ["modifer"]
    _hx_methods = ["getModifer", "setModifer"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject):
        self.modifer = -2
        super().__init__(gameObject)

    def getModifer(self):
        return self.modifer

    def setModifer(self,modifer):
        self.modifer = modifer

pw_tales_cofdsystem_action_events_OffhandModiferEvent._hx_class = pw_tales_cofdsystem_action_events_OffhandModiferEvent
_hx_classes["pw.tales.cofdsystem.action.events.OffhandModiferEvent"] = pw_tales_cofdsystem_action_events_OffhandModiferEvent


class pw_tales_cofdsystem_action_events_RollActionEvent(pw_tales_cofdsystem_action_events_ActionEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.RollActionEvent"
    _hx_is_interface = "False"
    __slots__ = ("rollAction",)
    _hx_fields = ["rollAction"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_ActionEvent


    def __init__(self,action):
        self.rollAction = None
        super().__init__(action)
        self.rollAction = action

pw_tales_cofdsystem_action_events_RollActionEvent._hx_class = pw_tales_cofdsystem_action_events_RollActionEvent
_hx_classes["pw.tales.cofdsystem.action.events.RollActionEvent"] = pw_tales_cofdsystem_action_events_RollActionEvent


class pw_tales_cofdsystem_action_events_pool_ActionPoolEvent(pw_tales_cofdsystem_action_events_RollActionEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.pool.ActionPoolEvent"
    _hx_is_interface = "False"
    __slots__ = ("pool",)
    _hx_fields = ["pool"]
    _hx_methods = ["getActionPool", "isPoolOwner", "isActorPool"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_RollActionEvent


    def __init__(self,action,pool):
        self.pool = None
        super().__init__(action)
        self.pool = pool

    def getActionPool(self):
        return self.pool

    def isPoolOwner(self,gameObject):
        return (self.pool.getGameObject() == gameObject)

    def isActorPool(self):
        return (self.pool == self.rollAction.getActionRoll().getActorPool())

pw_tales_cofdsystem_action_events_pool_ActionPoolEvent._hx_class = pw_tales_cofdsystem_action_events_pool_ActionPoolEvent
_hx_classes["pw.tales.cofdsystem.action.events.pool.ActionPoolEvent"] = pw_tales_cofdsystem_action_events_pool_ActionPoolEvent


class pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent(pw_tales_cofdsystem_action_events_pool_ActionPoolEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.pool.ActionBuildPoolEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_pool_ActionPoolEvent


    def __init__(self,action,pool):
        super().__init__(action,pool)
pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent._hx_class = pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent
_hx_classes["pw.tales.cofdsystem.action.events.pool.ActionBuildPoolEvent"] = pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent


class pw_tales_cofdsystem_action_events_pool_ActionBuildResistEvent(pw_tales_cofdsystem_action_events_pool_ActionPoolEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.pool.ActionBuildResistEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_pool_ActionPoolEvent


    def __init__(self,action,pool):
        super().__init__(action,pool)
pw_tales_cofdsystem_action_events_pool_ActionBuildResistEvent._hx_class = pw_tales_cofdsystem_action_events_pool_ActionBuildResistEvent
_hx_classes["pw.tales.cofdsystem.action.events.pool.ActionBuildResistEvent"] = pw_tales_cofdsystem_action_events_pool_ActionBuildResistEvent


class pw_tales_cofdsystem_action_events_roll_ActionRollEvent(pw_tales_cofdsystem_action_events_RollActionEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.roll.ActionRollEvent"
    _hx_is_interface = "False"
    __slots__ = ("roll",)
    _hx_fields = ["roll"]
    _hx_methods = ["getRoll"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_RollActionEvent


    def __init__(self,action,roll):
        self.roll = None
        super().__init__(action)
        self.roll = roll

    def getRoll(self):
        return self.roll

pw_tales_cofdsystem_action_events_roll_ActionRollEvent._hx_class = pw_tales_cofdsystem_action_events_roll_ActionRollEvent
_hx_classes["pw.tales.cofdsystem.action.events.roll.ActionRollEvent"] = pw_tales_cofdsystem_action_events_roll_ActionRollEvent


class pw_tales_cofdsystem_action_events_roll_ActionPostRollEvent(pw_tales_cofdsystem_action_events_roll_ActionRollEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.roll.ActionPostRollEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_roll_ActionRollEvent


    def __init__(self,action,roll):
        super().__init__(action,roll)
pw_tales_cofdsystem_action_events_roll_ActionPostRollEvent._hx_class = pw_tales_cofdsystem_action_events_roll_ActionPostRollEvent
_hx_classes["pw.tales.cofdsystem.action.events.roll.ActionPostRollEvent"] = pw_tales_cofdsystem_action_events_roll_ActionPostRollEvent


class pw_tales_cofdsystem_action_events_roll_ActionPreRollEvent(pw_tales_cofdsystem_action_events_roll_ActionRollEvent):
    _hx_class_name = "pw.tales.cofdsystem.action.events.roll.ActionPreRollEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_roll_ActionRollEvent


    def __init__(self,action,roll):
        super().__init__(action,roll)
pw_tales_cofdsystem_action_events_roll_ActionPreRollEvent._hx_class = pw_tales_cofdsystem_action_events_roll_ActionPreRollEvent
_hx_classes["pw.tales.cofdsystem.action.events.roll.ActionPreRollEvent"] = pw_tales_cofdsystem_action_events_roll_ActionPreRollEvent


class pw_tales_cofdsystem_action_modifications_Offhand:
    _hx_class_name = "pw.tales.cofdsystem.action.modifications.Offhand"
    _hx_is_interface = "False"
    __slots__ = ("gameObject",)
    _hx_fields = ["gameObject"]
    _hx_methods = ["init", "onHandEvent", "applyRollModifier", "getGameObject"]
    _hx_statics = ["DN", "getModifier"]
    _hx_interfaces = [pw_tales_cofdsystem_action_IModification]

    def __init__(self,gameObject):
        self.gameObject = gameObject

    def init(self,action):
        eventBus = action.getEventBus()
        eventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.applyRollModifier,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)
        eventBus.addHandler(pw_tales_cofdsystem_action_events_ActionGetHandEvent,self.onHandEvent,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def onHandEvent(self,event):
        if (event.getGameObject() == self.gameObject):
            event.setHand(pw_tales_cofdsystem_common_EnumHand.OFFHAND)

    def applyRollModifier(self,event):
        if (not event.isPoolOwner(self.gameObject)):
            return
        pool = event.getActionPool()
        modifer = pw_tales_cofdsystem_action_modifications_Offhand.getModifier(self.gameObject)
        pool.getRequest().addModifier(modifer,pw_tales_cofdsystem_action_modifications_Offhand.DN)

    def getGameObject(self):
        return self.gameObject

    @staticmethod
    def getModifier(gameObject):
        system = gameObject.getSystem()
        modfierEvent = pw_tales_cofdsystem_action_events_OffhandModiferEvent(gameObject)
        system.events.post(modfierEvent)
        return modfierEvent.getModifer()

pw_tales_cofdsystem_action_modifications_Offhand._hx_class = pw_tales_cofdsystem_action_modifications_Offhand
_hx_classes["pw.tales.cofdsystem.action.modifications.Offhand"] = pw_tales_cofdsystem_action_modifications_Offhand


class pw_tales_cofdsystem_action_modifications_Willpower:
    _hx_class_name = "pw.tales.cofdsystem.action.modifications.Willpower"
    _hx_is_interface = "False"
    __slots__ = ("gameObject",)
    _hx_fields = ["gameObject"]
    _hx_methods = ["init", "applyRollBonus", "applyResistBonus", "burnWillpower"]
    _hx_interfaces = [pw_tales_cofdsystem_action_IModification]

    def __init__(self,gameObject):
        self.gameObject = gameObject

    def init(self,action):
        eventBus = action.getEventBus()
        eventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.applyRollBonus,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)
        eventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildResistEvent,self.applyResistBonus,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def applyRollBonus(self,event):
        if (not event.isPoolOwner(self.gameObject)):
            return
        self.burnWillpower()
        event.getActionPool().getRequest().addModifier(3,pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.DN)

    def applyResistBonus(self,event):
        if (not event.isPoolOwner(self.gameObject)):
            return
        self.burnWillpower()
        event.getActionPool().getRequest().addModifier(2,pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.DN)

    def burnWillpower(self):
        self.gameObject.getTrait(pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.TYPE).burnWillpower()

pw_tales_cofdsystem_action_modifications_Willpower._hx_class = pw_tales_cofdsystem_action_modifications_Willpower
_hx_classes["pw.tales.cofdsystem.action.modifications.Willpower"] = pw_tales_cofdsystem_action_modifications_Willpower


class pw_tales_cofdsystem_action_pool_ActionPool:
    _hx_class_name = "pw.tales.cofdsystem.action.pool.ActionPool"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "system", "request", "response")
    _hx_fields = ["gameObject", "system", "request", "response"]
    _hx_methods = ["getGameObject", "getTraits", "hasTrait", "getRequest", "getResponse", "isRelated", "willRoll", "getActor", "getActorPool", "rollWithPoolEvents", "roll"]
    _hx_interfaces = [pw_tales_cofdsystem_action_IActionRoll]

    def __init__(self,gameObject,traits):
        self.request = None
        self.system = None
        self.response = None
        self.gameObject = gameObject
        self.system = self.gameObject.getSystem()
        self.request = pw_tales_cofdsystem_dices_requests_RollRequestTrait(gameObject,traits)

    def getGameObject(self):
        return self.gameObject

    def getTraits(self):
        return self.request.getTraits()

    def hasTrait(self,dn):
        return (python_internal_ArrayImpl.indexOf(self.getTraits(),dn,None) != -1)

    def getRequest(self):
        return self.request

    def getResponse(self):
        if (self.response is None):
            raise pw_tales_cofdsystem_action_pool_exceptions_PoolNotRolledException(self)
        return self.response

    def isRelated(self,gameObject):
        return (self.gameObject == gameObject)

    def willRoll(self,roll):
        return (self == roll)

    def getActor(self):
        return self.gameObject

    def getActorPool(self):
        return self

    def rollWithPoolEvents(self,action):
        self.system.events.post(pw_tales_cofdsystem_action_events_roll_ActionPreRollEvent(action,self))
        self.response = self.system.dices.roll(self.request)
        self.system.events.post(pw_tales_cofdsystem_action_events_roll_ActionPostRollEvent(action,self))

    def roll(self,action):
        self.system.events.post(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent(action,self))
        self.rollWithPoolEvents(action)

pw_tales_cofdsystem_action_pool_ActionPool._hx_class = pw_tales_cofdsystem_action_pool_ActionPool
_hx_classes["pw.tales.cofdsystem.action.pool.ActionPool"] = pw_tales_cofdsystem_action_pool_ActionPool


class pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder:
    _hx_class_name = "pw.tales.cofdsystem.action.pool.builder.ActionPoolBuilder"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "modifier", "traits", "explode")
    _hx_fields = ["gameObject", "modifier", "traits", "explode"]
    _hx_methods = ["getModifier", "setModifier", "getExplode", "setExplode", "getTraits", "setTraits", "build"]
    _hx_statics = ["CUSTOM_MODIFIER"]

    def __init__(self,gameObject):
        self.explode = pw_tales_cofdsystem_dices_EnumExplode.DEFAULT
        self.traits = []
        self.modifier = 0
        self.gameObject = gameObject

    def getModifier(self):
        return self.modifier

    def setModifier(self,modifier):
        self.modifier = modifier
        return self

    def getExplode(self):
        return self.explode

    def setExplode(self,explode):
        self.explode = explode
        return self

    def getTraits(self):
        return self.traits

    def setTraits(self,traits):
        self.traits = traits
        return self

    def build(self):
        actionPool = pw_tales_cofdsystem_action_pool_ActionPool(self.gameObject,self.traits)
        request = actionPool.getRequest()
        request.addModifier(self.modifier,pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder.CUSTOM_MODIFIER)
        request.addIgnoreLimit(pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder.CUSTOM_MODIFIER)
        request.setExplode(self.explode)
        return actionPool

pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder._hx_class = pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder
_hx_classes["pw.tales.cofdsystem.action.pool.builder.ActionPoolBuilder"] = pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder


class pw_tales_cofdsystem_exceptions_CofDSystemException(haxe_Exception):
    _hx_class_name = "pw.tales.cofdsystem.exceptions.CofDSystemException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,message,previous = None,native = None):
        super().__init__(message,previous,native)
pw_tales_cofdsystem_exceptions_CofDSystemException._hx_class = pw_tales_cofdsystem_exceptions_CofDSystemException
_hx_classes["pw.tales.cofdsystem.exceptions.CofDSystemException"] = pw_tales_cofdsystem_exceptions_CofDSystemException


class pw_tales_cofdsystem_action_pool_exceptions_PoolNotRolledException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.action.pool.exceptions.PoolNotRolledException"
    _hx_is_interface = "False"
    __slots__ = ("pool",)
    _hx_fields = ["pool"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,pool):
        self.pool = None
        super().__init__("Pool is not rolled yet.")
        self.pool = pool

pw_tales_cofdsystem_action_pool_exceptions_PoolNotRolledException._hx_class = pw_tales_cofdsystem_action_pool_exceptions_PoolNotRolledException
_hx_classes["pw.tales.cofdsystem.action.pool.exceptions.PoolNotRolledException"] = pw_tales_cofdsystem_action_pool_exceptions_PoolNotRolledException


class pw_tales_cofdsystem_action_attack_AttackAction(pw_tales_cofdsystem_action_RollAction):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.AttackAction"
    _hx_is_interface = "False"
    __slots__ = ("competition", "damage")
    _hx_fields = ["competition", "damage"]
    _hx_methods = ["getCompetition", "getHand", "getWeapon", "getTarget", "getDamage", "createDamageType", "beforeAction", "perform"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_RollAction


    def __init__(self,competition,system):
        self.competition = None
        self.damage = None
        super().__init__(competition,pw_tales_cofdsystem_action_EnumTime.INSTANT,system)
        self.competition = competition

    def getCompetition(self):
        return self.competition

    def getHand(self):
        eventBus = self.getEventBus()
        handEvent = pw_tales_cofdsystem_action_events_ActionGetHandEvent(self,self.getActor())
        eventBus.post(handEvent)
        return handEvent.getHand()

    def getWeapon(self):
        hand = self.getHand()
        trait = self.getActor().getTrait(pw_tales_cofdsystem_character_traits_HeldWeapon.TYPE)
        if (trait is None):
            return None
        return trait.getHand(hand)

    def getTarget(self):
        return self.competition.getTarget()

    def getDamage(self):
        if (self.damage is None):
            raise haxe_Exception.thrown("Asked for damage too early")
        return self.damage

    def createDamageType(self,value,damageType):
        if (damageType == "AGGRAVATED"):
            return pw_tales_cofdsystem_damage_Damage(0,0,value)
        if (damageType == "LETHAL"):
            return pw_tales_cofdsystem_damage_Damage(0,value,0)
        return pw_tales_cofdsystem_damage_Damage(value,0,0)

    def beforeAction(self):
        super().beforeAction()
        self.system.events.post(pw_tales_cofdsystem_action_attack_events_AttackInitiatedEvent(self))

    def perform(self):
        actorPool = self.competition.getActorPool()
        targetPool = self.competition.getTargetPool()
        target = targetPool.getGameObject()
        if (self.competition.getWinnerPool() == actorPool):
            self.system.events.post(pw_tales_cofdsystem_action_attack_events_AttackHitEvent(self))
            successes = actorPool.getResponse().getSuccesses()
            if self.competition.willRoll(targetPool):
                successes = (successes - targetPool.getResponse().getSuccesses())
            damageType = "BASHING"
            eventDamageType = pw_tales_cofdsystem_action_attack_events_AttackDamageGetTypeEvent(damageType,self)
            self.system.events.post(eventDamageType)
            damageType = eventDamageType.getDamageType()
            eventAttackSuccess = pw_tales_cofdsystem_action_attack_events_AttackSuccesesEvent(successes,self)
            self.system.events.post(eventAttackSuccess)
            successes = eventAttackSuccess.getDamageSucceses()
            self.damage = self.createDamageType(successes,damageType)
            eventDamage = pw_tales_cofdsystem_action_attack_events_AttackDamageGetEvent(self.damage,self)
            self.system.events.post(eventDamage)
            self.damage = eventDamage.getDamage()
            pw_tales_cofdsystem_game_object_health_helper_HealthTraitHelper.get(target).dealDamage(self.damage)
            self.system.events.post(pw_tales_cofdsystem_action_attack_events_AttackDamageDealtEvent(self.damage,self))
        else:
            self.system.events.post(pw_tales_cofdsystem_action_attack_events_AttackMissEvent(self))

pw_tales_cofdsystem_action_attack_AttackAction._hx_class = pw_tales_cofdsystem_action_attack_AttackAction
_hx_classes["pw.tales.cofdsystem.action_attack.AttackAction"] = pw_tales_cofdsystem_action_attack_AttackAction


class pw_tales_cofdsystem_action_attack_builder_AttackBuilder:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.builder.AttackBuilder"
    _hx_is_interface = "False"
    __slots__ = ("system", "competitionBuilder", "specifiedTarget", "actor", "actorWillpower", "actorHand", "actorAllOut", "target", "targetWillpower", "targetHand", "targetResistType")
    _hx_fields = ["system", "competitionBuilder", "specifiedTarget", "actor", "actorWillpower", "actorHand", "actorAllOut", "target", "targetWillpower", "targetHand", "targetResistType"]
    _hx_methods = ["getActor", "getTarget", "getGameObject", "isRelated", "isAllOut", "setAllOut", "getExplode", "setExplode", "getSpecifiedTarget", "setSpecifiedTarget", "getModifier", "setModifier", "getSpendWillpower", "setSpendWillpower", "getHand", "setHand", "getResistType", "setResistType", "build"]
    _hx_statics = ["updateCompetitionResistType"]

    def __init__(self,actor,target):
        self.target = None
        self.actor = None
        self.targetResistType = pw_tales_cofdsystem_action_attack_builder_EnumResistType.DEFAULT
        self.targetHand = pw_tales_cofdsystem_common_EnumHand.HAND
        self.targetWillpower = False
        self.actorAllOut = False
        self.actorHand = pw_tales_cofdsystem_common_EnumHand.HAND
        self.actorWillpower = False
        self.specifiedTarget = None
        self.system = actor.getSystem()
        self.competitionBuilder = pw_tales_cofdsystem_action_competition_builder_CompetitionBuilder.create(actor,target)
        self.competitionBuilder.setTraits(pw_tales_cofdsystem_common_EnumSide.ACTOR,[pw_tales_cofdsystem_character_traits_attribute_Attributes.STRENGTH.getDN(), pw_tales_cofdsystem_character_traits_skill_Skills.BRAWL.getDN()])
        pw_tales_cofdsystem_action_attack_builder_AttackBuilder.updateCompetitionResistType(self.competitionBuilder,self.targetResistType)
        self.actor = actor
        self.target = target

    def getActor(self):
        return self.actor

    def getTarget(self):
        return self.target

    def getGameObject(self,side):
        if (side == pw_tales_cofdsystem_common_EnumSide.ACTOR):
            return self.getActor()
        elif (side == pw_tales_cofdsystem_common_EnumSide.TARGET):
            return self.getTarget()
        else:
            raise pw_tales_cofdsystem_builder_exceptions_UnknownSideException()

    def isRelated(self,gameObject):
        if (self.actor != gameObject):
            return (self.target == gameObject)
        else:
            return True

    def isAllOut(self):
        return self.actorAllOut

    def setAllOut(self,allOut):
        self.actorAllOut = allOut
        return self

    def getExplode(self,side):
        return self.competitionBuilder.getExplode(side)

    def setExplode(self,side,explode):
        self.competitionBuilder.setExplode(side,explode)
        return self

    def getSpecifiedTarget(self):
        return self.specifiedTarget

    def setSpecifiedTarget(self,specifiedTarget):
        self.specifiedTarget = specifiedTarget
        return self

    def getModifier(self,side):
        return self.competitionBuilder.getModifier(side)

    def setModifier(self,side,value):
        self.competitionBuilder.setModifier(side,value)
        return self

    def getSpendWillpower(self,side):
        if (side == pw_tales_cofdsystem_common_EnumSide.ACTOR):
            return self.actorWillpower
        elif (side == pw_tales_cofdsystem_common_EnumSide.TARGET):
            return self.targetWillpower
        else:
            raise pw_tales_cofdsystem_builder_exceptions_UnknownSideException()

    def setSpendWillpower(self,side,value = None):
        if (value is None):
            value = True
        willpower = self.getGameObject(side).getTrait(pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.TYPE)
        if ((willpower is None) or (not willpower.canUse())):
            raise pw_tales_cofdsystem_action_attack_builder_exceptions_NoWillpowerBuilderException(self)
        if (side == pw_tales_cofdsystem_common_EnumSide.ACTOR):
            self.actorWillpower = value
        elif (side == pw_tales_cofdsystem_common_EnumSide.TARGET):
            self.targetWillpower = value
        else:
            raise pw_tales_cofdsystem_builder_exceptions_UnknownSideException()
        return self

    def getHand(self,side):
        if (side == pw_tales_cofdsystem_common_EnumSide.ACTOR):
            return self.actorHand
        elif (side == pw_tales_cofdsystem_common_EnumSide.TARGET):
            return self.targetHand
        else:
            raise pw_tales_cofdsystem_builder_exceptions_UnknownSideException()

    def setHand(self,side,hand):
        if (side == pw_tales_cofdsystem_common_EnumSide.ACTOR):
            self.actorHand = hand
        elif (side == pw_tales_cofdsystem_common_EnumSide.TARGET):
            self.targetHand = hand
        else:
            raise pw_tales_cofdsystem_builder_exceptions_UnknownSideException()
        return self

    def getResistType(self):
        return self.targetResistType

    def setResistType(self,resistType):
        self.targetResistType = resistType
        pw_tales_cofdsystem_action_attack_builder_AttackBuilder.updateCompetitionResistType(self.competitionBuilder,self.targetResistType)
        return self

    def build(self):
        action = pw_tales_cofdsystem_action_attack_AttackAction(self.competitionBuilder.build(),self.system)
        if (self.specifiedTarget is not None):
            action.addModification(pw_tales_cofdsystem_action_attack_modifications_SpecifiedTarget(self.specifiedTarget.getTarget()))
        if self.actorAllOut:
            action.addModification(pw_tales_cofdsystem_action_attack_modifications_AllOutAttack(self.actor))
        if self.actorWillpower:
            action.addModification(pw_tales_cofdsystem_action_modifications_Willpower(self.actor))
        if self.targetWillpower:
            action.addModification(pw_tales_cofdsystem_action_modifications_Willpower(self.target))
        if (self.actorHand == pw_tales_cofdsystem_common_EnumHand.OFFHAND):
            action.addModification(pw_tales_cofdsystem_action_modifications_Offhand(self.actor))
        if (self.targetHand == pw_tales_cofdsystem_common_EnumHand.OFFHAND):
            action.addModification(pw_tales_cofdsystem_action_modifications_Offhand(self.actor))
        return action

    @staticmethod
    def updateCompetitionResistType(builder,resist):
        if (resist == pw_tales_cofdsystem_action_attack_builder_EnumResistType.DEFAULT):
            builder.setOppositionType(pw_tales_cofdsystem_action_competition_builder_EnumCompetition.RESISTED)
            builder.setTraits(pw_tales_cofdsystem_common_EnumSide.TARGET,[pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.DN])
        elif (resist == pw_tales_cofdsystem_action_attack_builder_EnumResistType.DODGE):
            builder.setOppositionType(pw_tales_cofdsystem_action_competition_builder_EnumCompetition.CONTESTED)
            builder.setTraits(pw_tales_cofdsystem_common_EnumSide.TARGET,[pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.DN, pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.DN])
        elif (resist == pw_tales_cofdsystem_action_attack_builder_EnumResistType.NO_DEFENCE):
            builder.setOppositionType(pw_tales_cofdsystem_action_competition_builder_EnumCompetition.RESISTED)
            builder.setTraits(pw_tales_cofdsystem_common_EnumSide.TARGET,[])
        else:
            pass

pw_tales_cofdsystem_action_attack_builder_AttackBuilder._hx_class = pw_tales_cofdsystem_action_attack_builder_AttackBuilder
_hx_classes["pw.tales.cofdsystem.action_attack.builder.AttackBuilder"] = pw_tales_cofdsystem_action_attack_builder_AttackBuilder


class pw_tales_cofdsystem_utils_EnumNamed:
    _hx_class_name = "pw.tales.cofdsystem.utils.EnumNamed"
    _hx_is_interface = "False"
    __slots__ = ("name",)
    _hx_fields = ["name"]
    _hx_methods = ["getName", "toString"]

    def __init__(self,name):
        self.name = name

    def getName(self):
        return self.name

    def toString(self):
        return self.getName()

pw_tales_cofdsystem_utils_EnumNamed._hx_class = pw_tales_cofdsystem_utils_EnumNamed
_hx_classes["pw.tales.cofdsystem.utils.EnumNamed"] = pw_tales_cofdsystem_utils_EnumNamed


class pw_tales_cofdsystem_action_attack_builder_EnumResistType(pw_tales_cofdsystem_utils_EnumNamed):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.builder.EnumResistType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["VALUES", "DEFAULT", "DODGE", "NO_DEFENCE", "byName"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_EnumNamed


    def __init__(self,name):
        super().__init__(name)
        pw_tales_cofdsystem_action_attack_builder_EnumResistType.VALUES.h[name] = self

    @staticmethod
    def byName(name):
        value = pw_tales_cofdsystem_action_attack_builder_EnumResistType.VALUES.h.get(name,None)
        if (value is None):
            raise haxe_Exception.thrown("Wrong name")
        return value
pw_tales_cofdsystem_action_attack_builder_EnumResistType._hx_class = pw_tales_cofdsystem_action_attack_builder_EnumResistType
_hx_classes["pw.tales.cofdsystem.action_attack.builder.EnumResistType"] = pw_tales_cofdsystem_action_attack_builder_EnumResistType


class pw_tales_cofdsystem_action_attack_targets_ITarget:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.targets.ITarget"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getDN", "getAttackModifer", "apply"]
pw_tales_cofdsystem_action_attack_targets_ITarget._hx_class = pw_tales_cofdsystem_action_attack_targets_ITarget
_hx_classes["pw.tales.cofdsystem.action_attack.targets.ITarget"] = pw_tales_cofdsystem_action_attack_targets_ITarget


class pw_tales_cofdsystem_action_attack_targets_Arm:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.targets.Arm"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getDN", "getAttackModifer", "apply"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_action_attack_targets_ITarget]

    def __init__(self):
        pass

    def getDN(self):
        return "arm"

    def getAttackModifer(self):
        return -2

    def apply(self,action):
        damage = action.getDamage()
        totalDamage = ((damage.getBashing() + damage.getLethal()) + damage.getAggravated())
        gameObject = action.getCompetition().getTarget()
        if (totalDamage > gameObject.getTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.STAMINA).getValue()):
            gameObject.getTraitManager().addTrait(pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt.TYPE)

pw_tales_cofdsystem_action_attack_targets_Arm._hx_class = pw_tales_cofdsystem_action_attack_targets_Arm
_hx_classes["pw.tales.cofdsystem.action_attack.targets.Arm"] = pw_tales_cofdsystem_action_attack_targets_Arm


class pw_tales_cofdsystem_action_attack_targets_Eye:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.targets.Eye"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getDN", "getAttackModifer", "apply"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_action_attack_targets_ITarget]

    def __init__(self):
        pass

    def getDN(self):
        return "eye"

    def getAttackModifer(self):
        return -5

    def apply(self,action):
        damage = action.getDamage()
        if (((damage.getBashing() + damage.getLethal()) + damage.getAggravated()) > 0):
            action.getCompetition().getTargetPool().getGameObject().getTraitManager().addTrait(pw_tales_cofdsystem_character_traits_tilts_BlindedTilt.TYPE)

pw_tales_cofdsystem_action_attack_targets_Eye._hx_class = pw_tales_cofdsystem_action_attack_targets_Eye
_hx_classes["pw.tales.cofdsystem.action_attack.targets.Eye"] = pw_tales_cofdsystem_action_attack_targets_Eye


class pw_tales_cofdsystem_action_attack_targets_Hand:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.targets.Hand"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getDN", "getAttackModifer", "apply"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_action_attack_targets_ITarget]

    def __init__(self):
        pass

    def getDN(self):
        return "hand"

    def getAttackModifer(self):
        return -4

    def apply(self,action):
        damage = action.getDamage()
        if (((damage.getBashing() + damage.getLethal()) + damage.getAggravated()) > 0):
            action.getCompetition().getTarget().getTraitManager().addTrait(pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt.TYPE)

pw_tales_cofdsystem_action_attack_targets_Hand._hx_class = pw_tales_cofdsystem_action_attack_targets_Hand
_hx_classes["pw.tales.cofdsystem.action_attack.targets.Hand"] = pw_tales_cofdsystem_action_attack_targets_Hand


class pw_tales_cofdsystem_action_attack_targets_Head:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.targets.Head"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getDN", "getAttackModifer", "apply"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_action_attack_targets_ITarget]

    def __init__(self):
        pass

    def getDN(self):
        return "head"

    def getAttackModifer(self):
        return -3

    def apply(self,action):
        damage = action.getDamage()
        totalDamage = ((damage.getBashing() + damage.getLethal()) + damage.getAggravated())
        gameObject = action.getCompetition().getTarget()
        if (totalDamage >= ((gameObject.getTrait(pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.TYPE).getValue() - 1))):
            gameObject.getTraitManager().addTrait(pw_tales_cofdsystem_character_traits_tilts_StunnedTilt.TYPE)

pw_tales_cofdsystem_action_attack_targets_Head._hx_class = pw_tales_cofdsystem_action_attack_targets_Head
_hx_classes["pw.tales.cofdsystem.action_attack.targets.Head"] = pw_tales_cofdsystem_action_attack_targets_Head


class pw_tales_cofdsystem_action_attack_targets_Heart:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.targets.Heart"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getDN", "getAttackModifer", "apply"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_action_attack_targets_ITarget]

    def __init__(self):
        pass

    def getDN(self):
        return "heart"

    def getAttackModifer(self):
        return -3

    def apply(self,action):
        damage = action.getDamage()
        if (((damage.getBashing() + damage.getLethal()) + damage.getAggravated()) >= 5):
            gameObject = action.getCompetition().getTarget()
            gameObject.getSystem().events.post(pw_tales_cofdsystem_action_attack_events_HeartPiercedEvent(gameObject))

pw_tales_cofdsystem_action_attack_targets_Heart._hx_class = pw_tales_cofdsystem_action_attack_targets_Heart
_hx_classes["pw.tales.cofdsystem.action_attack.targets.Heart"] = pw_tales_cofdsystem_action_attack_targets_Heart


class pw_tales_cofdsystem_action_attack_targets_Leg:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.targets.Leg"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getDN", "getAttackModifer", "apply"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_action_attack_targets_ITarget]

    def __init__(self):
        pass

    def getDN(self):
        return "leg"

    def getAttackModifer(self):
        return -2

    def apply(self,action):
        damage = action.getDamage()
        totalDamage = ((damage.getBashing() + damage.getLethal()) + damage.getAggravated())
        gameObject = action.getCompetition().getTarget()
        if (totalDamage > gameObject.getTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.STAMINA).getValue()):
            gameObject.getTraitManager().addTrait(pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt.TYPE)

pw_tales_cofdsystem_action_attack_targets_Leg._hx_class = pw_tales_cofdsystem_action_attack_targets_Leg
_hx_classes["pw.tales.cofdsystem.action_attack.targets.Leg"] = pw_tales_cofdsystem_action_attack_targets_Leg


class pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget(pw_tales_cofdsystem_utils_EnumNamed):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.builder.EnumSpecifiedTarget"
    _hx_is_interface = "False"
    __slots__ = ("target",)
    _hx_fields = ["target"]
    _hx_methods = ["getTarget"]
    _hx_statics = ["VALUES", "ARM", "LEG", "HEAD", "HEART", "HAND", "EYE", "byName"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_EnumNamed


    def __init__(self,target):
        self.target = None
        super().__init__(target.getDN())
        self.target = target
        key = self.getName()
        pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.VALUES.h[key] = self

    def getTarget(self):
        return self.target

    @staticmethod
    def byName(name):
        value = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.VALUES.h.get(name,None)
        if (value is None):
            raise haxe_Exception.thrown("Wrong name")
        return value

pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget._hx_class = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget
_hx_classes["pw.tales.cofdsystem.action_attack.builder.EnumSpecifiedTarget"] = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget


class pw_tales_cofdsystem_action_attack_builder_exceptions_AttackBuilderException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.builder.exceptions.AttackBuilderException"
    _hx_is_interface = "False"
    __slots__ = ("attackBuilder",)
    _hx_fields = ["attackBuilder"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,attackBuilder,msg,previous = None,native = None):
        self.attackBuilder = None
        super().__init__(msg,previous,native)
        self.attackBuilder = attackBuilder

pw_tales_cofdsystem_action_attack_builder_exceptions_AttackBuilderException._hx_class = pw_tales_cofdsystem_action_attack_builder_exceptions_AttackBuilderException
_hx_classes["pw.tales.cofdsystem.action_attack.builder.exceptions.AttackBuilderException"] = pw_tales_cofdsystem_action_attack_builder_exceptions_AttackBuilderException


class pw_tales_cofdsystem_action_attack_builder_exceptions_NoWillpowerBuilderException(pw_tales_cofdsystem_action_attack_builder_exceptions_AttackBuilderException):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.builder.exceptions.NoWillpowerBuilderException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_builder_exceptions_AttackBuilderException


    def __init__(self,attackBuilder):
        super().__init__(attackBuilder,"Can't use willpower.")
pw_tales_cofdsystem_action_attack_builder_exceptions_NoWillpowerBuilderException._hx_class = pw_tales_cofdsystem_action_attack_builder_exceptions_NoWillpowerBuilderException
_hx_classes["pw.tales.cofdsystem.action_attack.builder.exceptions.NoWillpowerBuilderException"] = pw_tales_cofdsystem_action_attack_builder_exceptions_NoWillpowerBuilderException


class pw_tales_cofdsystem_action_attack_events_AttackEvent(pw_tales_cofdsystem_action_events_ActionEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackEvent"
    _hx_is_interface = "False"
    __slots__ = ("attackAction",)
    _hx_fields = ["attackAction"]
    _hx_methods = ["getAttackAction", "getAction", "isTarget"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_events_ActionEvent


    def __init__(self,action):
        self.attackAction = None
        super().__init__(action)
        self.attackAction = action

    def getAttackAction(self):
        return self.attackAction

    def getAction(self):
        return self.attackAction

    def isTarget(self,gameObject):
        return (self.attackAction.getCompetition().getTarget() == gameObject)

pw_tales_cofdsystem_action_attack_events_AttackEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackEvent"] = pw_tales_cofdsystem_action_attack_events_AttackEvent


class pw_tales_cofdsystem_action_attack_events_AttackDamageEvent(pw_tales_cofdsystem_action_attack_events_AttackEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackDamageEvent"
    _hx_is_interface = "False"
    __slots__ = ("damage",)
    _hx_fields = ["damage"]
    _hx_methods = ["getDamage"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackEvent


    def __init__(self,damage,action):
        self.damage = None
        super().__init__(action)
        self.damage = damage

    def getDamage(self):
        return self.damage

pw_tales_cofdsystem_action_attack_events_AttackDamageEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackDamageEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackDamageEvent"] = pw_tales_cofdsystem_action_attack_events_AttackDamageEvent


class pw_tales_cofdsystem_action_attack_events_AttackDamageDealtEvent(pw_tales_cofdsystem_action_attack_events_AttackDamageEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackDamageDealtEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackDamageEvent


    def __init__(self,damage,action):
        super().__init__(damage,action)
pw_tales_cofdsystem_action_attack_events_AttackDamageDealtEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackDamageDealtEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackDamageDealtEvent"] = pw_tales_cofdsystem_action_attack_events_AttackDamageDealtEvent


class pw_tales_cofdsystem_action_attack_events_AttackDamageGetEvent(pw_tales_cofdsystem_action_attack_events_AttackDamageEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackDamageGetEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setDamage"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackDamageEvent


    def __init__(self,damage,action):
        super().__init__(damage,action)

    def setDamage(self,damage):
        self.damage = damage

pw_tales_cofdsystem_action_attack_events_AttackDamageGetEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackDamageGetEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackDamageGetEvent"] = pw_tales_cofdsystem_action_attack_events_AttackDamageGetEvent


class pw_tales_cofdsystem_action_attack_events_AttackDamageGetTypeEvent(pw_tales_cofdsystem_action_attack_events_AttackEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackDamageGetTypeEvent"
    _hx_is_interface = "False"
    __slots__ = ("damageType",)
    _hx_fields = ["damageType"]
    _hx_methods = ["getDamageType", "setDamageType"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackEvent


    def __init__(self,damageType,action):
        self.damageType = None
        super().__init__(action)
        self.damageType = damageType

    def getDamageType(self):
        return self.damageType

    def setDamageType(self,damage):
        self.damageType = damage

pw_tales_cofdsystem_action_attack_events_AttackDamageGetTypeEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackDamageGetTypeEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackDamageGetTypeEvent"] = pw_tales_cofdsystem_action_attack_events_AttackDamageGetTypeEvent


class pw_tales_cofdsystem_action_attack_events_AttackStatusEvent(pw_tales_cofdsystem_action_attack_events_AttackEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackStatusEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackEvent


    def __init__(self,action):
        super().__init__(action)
pw_tales_cofdsystem_action_attack_events_AttackStatusEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackStatusEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackStatusEvent"] = pw_tales_cofdsystem_action_attack_events_AttackStatusEvent


class pw_tales_cofdsystem_action_attack_events_AttackHitEvent(pw_tales_cofdsystem_action_attack_events_AttackStatusEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackHitEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackStatusEvent


    def __init__(self,action):
        super().__init__(action)
pw_tales_cofdsystem_action_attack_events_AttackHitEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackHitEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackHitEvent"] = pw_tales_cofdsystem_action_attack_events_AttackHitEvent


class pw_tales_cofdsystem_action_attack_events_AttackInitiatedEvent(pw_tales_cofdsystem_action_attack_events_AttackEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackInitiatedEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackEvent


    def __init__(self,action):
        super().__init__(action)
pw_tales_cofdsystem_action_attack_events_AttackInitiatedEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackInitiatedEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackInitiatedEvent"] = pw_tales_cofdsystem_action_attack_events_AttackInitiatedEvent


class pw_tales_cofdsystem_action_attack_events_AttackMissEvent(pw_tales_cofdsystem_action_attack_events_AttackStatusEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackMissEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackStatusEvent


    def __init__(self,action):
        super().__init__(action)
pw_tales_cofdsystem_action_attack_events_AttackMissEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackMissEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackMissEvent"] = pw_tales_cofdsystem_action_attack_events_AttackMissEvent


class pw_tales_cofdsystem_action_attack_events_AttackSuccesesEvent(pw_tales_cofdsystem_action_attack_events_AttackEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.AttackSuccesesEvent"
    _hx_is_interface = "False"
    __slots__ = ("succeses",)
    _hx_fields = ["succeses"]
    _hx_methods = ["getDamageSucceses", "setDamageSucceses"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackEvent


    def __init__(self,succeses,action):
        self.succeses = None
        super().__init__(action)
        self.succeses = succeses

    def getDamageSucceses(self):
        return self.succeses

    def setDamageSucceses(self,succeses):
        self.succeses = succeses

pw_tales_cofdsystem_action_attack_events_AttackSuccesesEvent._hx_class = pw_tales_cofdsystem_action_attack_events_AttackSuccesesEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.AttackSuccesesEvent"] = pw_tales_cofdsystem_action_attack_events_AttackSuccesesEvent


class pw_tales_cofdsystem_action_attack_events_HeartPiercedEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.action_attack.events.HeartPiercedEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_action_attack_events_HeartPiercedEvent._hx_class = pw_tales_cofdsystem_action_attack_events_HeartPiercedEvent
_hx_classes["pw.tales.cofdsystem.action_attack.events.HeartPiercedEvent"] = pw_tales_cofdsystem_action_attack_events_HeartPiercedEvent


class pw_tales_cofdsystem_action_attack_modifications_AllOutAttack:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.modifications.AllOutAttack"
    _hx_is_interface = "False"
    __slots__ = ("gameObject",)
    _hx_fields = ["gameObject"]
    _hx_methods = ["init", "applyRollBonus"]
    _hx_statics = ["DN"]
    _hx_interfaces = [pw_tales_cofdsystem_action_IModification]

    def __init__(self,gameObject):
        self.gameObject = gameObject

    def init(self,action):
        action.getEventBus().addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.applyRollBonus,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def applyRollBonus(self,event):
        event.getActionPool().getRequest().addModifier(2,pw_tales_cofdsystem_action_attack_modifications_AllOutAttack.DN)
        self.gameObject.getTrait(pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.TYPE).loseDefence()

pw_tales_cofdsystem_action_attack_modifications_AllOutAttack._hx_class = pw_tales_cofdsystem_action_attack_modifications_AllOutAttack
_hx_classes["pw.tales.cofdsystem.action_attack.modifications.AllOutAttack"] = pw_tales_cofdsystem_action_attack_modifications_AllOutAttack


class pw_tales_cofdsystem_action_attack_modifications_SpecifiedTarget:
    _hx_class_name = "pw.tales.cofdsystem.action_attack.modifications.SpecifiedTarget"
    _hx_is_interface = "False"
    __slots__ = ("target",)
    _hx_fields = ["target"]
    _hx_methods = ["init", "applyPenalty", "applyEffect"]
    _hx_statics = ["DN"]
    _hx_interfaces = [pw_tales_cofdsystem_action_IModification]

    def __init__(self,target):
        self.target = target

    def init(self,action):
        eventBus = action.getEventBus()
        eventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.applyPenalty,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)
        eventBus.addHandler(pw_tales_cofdsystem_action_attack_events_AttackDamageDealtEvent,self.applyEffect,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def applyPenalty(self,event):
        action = pw_tales_cofdsystem_utils_Utility.downcast(event.getAction(),pw_tales_cofdsystem_action_attack_AttackAction)
        if (action is None):
            return
        action.getCompetition().getActorPool().getRequest().addModifier(self.target.getAttackModifer(),pw_tales_cofdsystem_action_attack_modifications_SpecifiedTarget.DN)

    def applyEffect(self,event):
        self.target.apply(event.getAction())

pw_tales_cofdsystem_action_attack_modifications_SpecifiedTarget._hx_class = pw_tales_cofdsystem_action_attack_modifications_SpecifiedTarget
_hx_classes["pw.tales.cofdsystem.action_attack.modifications.SpecifiedTarget"] = pw_tales_cofdsystem_action_attack_modifications_SpecifiedTarget


class pw_tales_cofdsystem_game_object_prefabs_Accessor:
    _hx_class_name = "pw.tales.cofdsystem.game_object.prefabs.Accessor"
    _hx_is_interface = "False"
    __slots__ = ("gameObject",)
    _hx_fields = ["gameObject"]
    _hx_methods = ["getTrait", "getText", "getInt", "getGameObject", "equals"]

    def __init__(self,gameObject):
        self.gameObject = gameObject

    def getTrait(self,_hx_type):
        trait = self.gameObject.getTrait(_hx_type)
        if (trait is None):
            raise pw_tales_cofdsystem_game_object_prefabs_exceptions_NoTraitAccessorException(self.gameObject,_hx_type)
        return trait

    def getText(self,_hx_type):
        textTrait = self.gameObject.getTrait(_hx_type)
        if (textTrait is None):
            return ""
        return textTrait.getText()

    def getInt(self,_hx_type):
        intTrait = self.gameObject.getTrait(_hx_type)
        if (intTrait is None):
            return 0
        return intTrait.getValue()

    def getGameObject(self):
        return self.gameObject

    def equals(self,other):
        if (self == other):
            return True
        otherAccessor = pw_tales_cofdsystem_utils_Utility.downcast(other,Type.getClass(self))
        if (otherAccessor is None):
            return False
        return (self.getGameObject() == otherAccessor.getGameObject())

pw_tales_cofdsystem_game_object_prefabs_Accessor._hx_class = pw_tales_cofdsystem_game_object_prefabs_Accessor
_hx_classes["pw.tales.cofdsystem.game_object.prefabs.Accessor"] = pw_tales_cofdsystem_game_object_prefabs_Accessor


class pw_tales_cofdsystem_equipment_Equipment(pw_tales_cofdsystem_game_object_prefabs_Accessor):
    _hx_class_name = "pw.tales.cofdsystem.equipment.Equipment"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getEquipper", "ensureEquipable", "setHolder", "unsetHolder"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_prefabs_Accessor


    def __init__(self,gameObject):
        super().__init__(gameObject)

    def getEquipper(self):
        try:
            return self.ensureEquipable().getHolder()
        except BaseException as _g:
            return None

    def ensureEquipable(self):
        return self.getTrait(pw_tales_cofdsystem_equipment_traits_Equippable.TYPE)

    def setHolder(self,gameObject):
        try:
            self.ensureEquipable().setHolder(gameObject)
        except BaseException as _g:
            pass

    def unsetHolder(self):
        try:
            self.ensureEquipable().unset()
        except BaseException as _g:
            pass

pw_tales_cofdsystem_equipment_Equipment._hx_class = pw_tales_cofdsystem_equipment_Equipment
_hx_classes["pw.tales.cofdsystem.equipment.Equipment"] = pw_tales_cofdsystem_equipment_Equipment


class pw_tales_cofdsystem_armor_IArmor:
    _hx_class_name = "pw.tales.cofdsystem.armor.IArmor"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getBallistic", "getGeneral", "getStrengthReq", "getDefenceMod", "getSpeedMod"]
pw_tales_cofdsystem_armor_IArmor._hx_class = pw_tales_cofdsystem_armor_IArmor
_hx_classes["pw.tales.cofdsystem.armor.IArmor"] = pw_tales_cofdsystem_armor_IArmor


class pw_tales_cofdsystem_armor_Armor(pw_tales_cofdsystem_equipment_Equipment):
    _hx_class_name = "pw.tales.cofdsystem.armor.Armor"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getGeneral", "getBallistic", "getStrengthReq", "getDefenceMod", "getSpeedMod", "setHolder", "unsetHolder"]
    _hx_statics = []
    _hx_interfaces = [pw_tales_cofdsystem_armor_IArmor]
    _hx_super = pw_tales_cofdsystem_equipment_Equipment


    def __init__(self,gameObject):
        super().__init__(gameObject)

    def getGeneral(self):
        armorRating = self.gameObject.getTrait(pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating.TYPE)
        if (armorRating is None):
            return 0
        return armorRating.getGeneral()

    def getBallistic(self):
        armorRating = self.gameObject.getTrait(pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating.TYPE)
        if (armorRating is None):
            return 0
        return armorRating.getBallistic()

    def getStrengthReq(self):
        return self.getInt(pw_tales_cofdsystem_equipment_traits_StrengthReq.TYPE)

    def getDefenceMod(self):
        return self.getInt(pw_tales_cofdsystem_armor_traits_DefenceModifer.TYPE)

    def getSpeedMod(self):
        return self.getInt(pw_tales_cofdsystem_armor_traits_SpeedModifer.TYPE)

    def setHolder(self,gameObject):
        super().setHolder(gameObject)

    def unsetHolder(self):
        super().ensureEquipable().unset()

pw_tales_cofdsystem_armor_Armor._hx_class = pw_tales_cofdsystem_armor_Armor
_hx_classes["pw.tales.cofdsystem.armor.Armor"] = pw_tales_cofdsystem_armor_Armor


class pw_tales_cofdsystem_armor_actions_DonAction(pw_tales_cofdsystem_action_NoRollAction):
    _hx_class_name = "pw.tales.cofdsystem.armor.actions.DonAction"
    _hx_is_interface = "False"
    __slots__ = ("armor",)
    _hx_fields = ["armor"]
    _hx_methods = ["perform"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_NoRollAction


    def __init__(self,actor,armor,system):
        self.armor = None
        super().__init__(actor,pw_tales_cofdsystem_action_EnumTime.EXTENDED,system)
        self.armor = armor

    def perform(self):
        self.actor.getTrait(pw_tales_cofdsystem_character_traits_WornArmor.TYPE).setArmor(self.armor)

pw_tales_cofdsystem_armor_actions_DonAction._hx_class = pw_tales_cofdsystem_armor_actions_DonAction
_hx_classes["pw.tales.cofdsystem.armor.actions.DonAction"] = pw_tales_cofdsystem_armor_actions_DonAction


class pw_tales_cofdsystem_utils_registry_IRecord:
    _hx_class_name = "pw.tales.cofdsystem.utils.registry.IRecord"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getDN"]
pw_tales_cofdsystem_utils_registry_IRecord._hx_class = pw_tales_cofdsystem_utils_registry_IRecord
_hx_classes["pw.tales.cofdsystem.utils.registry.IRecord"] = pw_tales_cofdsystem_utils_registry_IRecord


class pw_tales_cofdsystem_game_object_prefabs_IPrefab:
    _hx_class_name = "pw.tales.cofdsystem.game_object.prefabs.IPrefab"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["createGameObject"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_registry_IRecord]
pw_tales_cofdsystem_game_object_prefabs_IPrefab._hx_class = pw_tales_cofdsystem_game_object_prefabs_IPrefab
_hx_classes["pw.tales.cofdsystem.game_object.prefabs.IPrefab"] = pw_tales_cofdsystem_game_object_prefabs_IPrefab


class pw_tales_cofdsystem_game_object_prefabs_Prefab:
    _hx_class_name = "pw.tales.cofdsystem.game_object.prefabs.Prefab"
    _hx_is_interface = "False"
    __slots__ = ("dn",)
    _hx_fields = ["dn"]
    _hx_methods = ["getDN", "setUpGameObject", "createGameObject", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_game_object_prefabs_IPrefab]

    def __init__(self,dn):
        self.dn = dn

    def getDN(self):
        return self.dn

    def setUpGameObject(self,gameObject):
        raise haxe_Exception.thrown(thx_error_NotImplemented(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/game_object/prefabs/Prefab.hx", 'lineNumber': 19, 'className': "pw.tales.cofdsystem.game_object.prefabs.Prefab", 'methodName': "setUpGameObject"})))

    def createGameObject(self,system):
        gameObject = pw_tales_cofdsystem_game_object_GameObject(thx_Uuid.create(),system)
        gameObject.setState(pw_tales_cofdsystem_game_object_GameObjectState.LOADING)
        self.setUpGameObject(gameObject)
        gameObject.setState(pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE)
        return gameObject

    def toString(self):
        return (((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[dn=") + HxOverrides.stringOrNull(self.dn)) + "]")

pw_tales_cofdsystem_game_object_prefabs_Prefab._hx_class = pw_tales_cofdsystem_game_object_prefabs_Prefab
_hx_classes["pw.tales.cofdsystem.game_object.prefabs.Prefab"] = pw_tales_cofdsystem_game_object_prefabs_Prefab


class pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab(pw_tales_cofdsystem_game_object_prefabs_Prefab):
    _hx_class_name = "pw.tales.cofdsystem.equipment.prefabs.EquipmentPrefab"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setUpGameObject"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_prefabs_Prefab


    def __init__(self,dn):
        super().__init__(dn)

    def setUpGameObject(self,equipmentGameObject):
        equipmentGameObject.getTraitManager().addTrait(pw_tales_cofdsystem_equipment_traits_Equippable.TYPE)

pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab._hx_class = pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab
_hx_classes["pw.tales.cofdsystem.equipment.prefabs.EquipmentPrefab"] = pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab


class pw_tales_cofdsystem_armor_prefabs_ArmorPrefab(pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab):
    _hx_class_name = "pw.tales.cofdsystem.armor.prefabs.ArmorPrefab"
    _hx_is_interface = "False"
    __slots__ = ("name", "ballistic", "general", "defenceMod", "speedMod", "strengthReq")
    _hx_fields = ["name", "ballistic", "general", "defenceMod", "speedMod", "strengthReq"]
    _hx_methods = ["getName", "getDisplayName", "getBallistic", "getGeneral", "getStrengthReq", "getDefenceMod", "getSpeedMod", "setUpGameObject", "createArmor"]
    _hx_statics = []
    _hx_interfaces = [pw_tales_cofdsystem_armor_IArmor]
    _hx_super = pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab


    def __init__(self,name,ballistic,general,defenceMod,speedMod,strengthReq,dn):
        self.strengthReq = 0
        self.speedMod = 0
        self.defenceMod = 0
        self.general = 0
        self.ballistic = 0
        self.name = None
        super().__init__(dn)
        if (name is not None):
            self.name = name
        if (ballistic is not None):
            self.ballistic = ballistic
        if (general is not None):
            self.general = general
        if (defenceMod is not None):
            self.defenceMod = defenceMod
        if (speedMod is not None):
            self.speedMod = speedMod
        if (strengthReq is not None):
            self.strengthReq = strengthReq

    def getName(self):
        return self.name

    def getDisplayName(self):
        if (self.name is not None):
            return self.name
        return self.dn

    def getBallistic(self):
        return self.ballistic

    def getGeneral(self):
        return self.general

    def getStrengthReq(self):
        return self.strengthReq

    def getDefenceMod(self):
        return self.defenceMod

    def getSpeedMod(self):
        return self.speedMod

    def setUpGameObject(self,armorGameObject):
        super().setUpGameObject(armorGameObject)
        manager = armorGameObject.getTraitManager()
        armorRating = manager.addTrait(pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating.TYPE)
        armorRating.setGeneral(self.getGeneral())
        armorRating.setBallistic(self.getBallistic())
        manager.addTrait(pw_tales_cofdsystem_armor_traits_DefenceModifer.TYPE).setValue(self.getDefenceMod())
        manager.addTrait(pw_tales_cofdsystem_armor_traits_SpeedModifer.TYPE).setValue(self.getSpeedMod())
        manager.addTrait(pw_tales_cofdsystem_equipment_traits_StrengthReq.TYPE).setValue(self.getStrengthReq())

    def createArmor(self,system):
        return pw_tales_cofdsystem_armor_Armor(self.createGameObject(system))

pw_tales_cofdsystem_armor_prefabs_ArmorPrefab._hx_class = pw_tales_cofdsystem_armor_prefabs_ArmorPrefab
_hx_classes["pw.tales.cofdsystem.armor.prefabs.ArmorPrefab"] = pw_tales_cofdsystem_armor_prefabs_ArmorPrefab


class pw_tales_cofdsystem_game_object_traits_Trait:
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.Trait"
    _hx_is_interface = "False"
    __slots__ = ("type", "gameObject", "system", "eventBus", "version", "dn")
    _hx_fields = ["type", "gameObject", "system", "eventBus", "version", "dn"]
    _hx_methods = ["getDisplayName", "getType", "getDN", "getGameObject", "getValue", "shouldUpdateView", "notifyUpdated", "onAttached", "onRemoved", "serialize", "deserialize", "isNew", "hasChanges", "acceptChanges", "revertChanges", "collect", "toString"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_registry_IRecord]

    def __init__(self,dn,gameObject,_hx_type):
        self.version = pw_tales_cofdsystem_game_object_traits_TraitVersion.NEW
        self.dn = dn
        self.type = _hx_type
        self.gameObject = gameObject
        self.system = gameObject.getSystem()
        self.eventBus = gameObject.getEventBus().createSubBus()

    def getDisplayName(self):
        return self.type.getDisplayName()

    def getType(self):
        return self.type

    def getDN(self):
        return self.dn

    def getGameObject(self):
        return self.gameObject

    def getValue(self):
        raise haxe_Exception.thrown(thx_error_AbstractMethod(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/game_object/traits/Trait.hx", 'lineNumber': 87, 'className': "pw.tales.cofdsystem.game_object.traits.Trait", 'methodName': "getValue"})))

    def shouldUpdateView(self,event):
        traitEvent = Std.downcast(event,pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent)
        if (traitEvent is None):
            return False
        return (traitEvent.getTrait() == self)

    def notifyUpdated(self):
        self.eventBus.post(pw_tales_cofdsystem_game_object_events_traits_TraitPostUpdateEvent(self))

    def onAttached(self):
        pass

    def onRemoved(self):
        self.eventBus.disable()

    def serialize(self):
        data = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.serialize(self)
        value = self.getType().getDN()
        setattr(data,(("_hx_" + "type") if (("type" in python_Boot.keywords)) else (("_hx_" + "type") if (((((len("type") > 2) and ((ord("type"[0]) == 95))) and ((ord("type"[1]) == 95))) and ((ord("type"[(len("type") - 1)]) != 95)))) else "type")),value)
        return data

    def deserialize(self,data):
        pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.deserialize(self,data)
        self.acceptChanges()
        self.eventBus.post(pw_tales_cofdsystem_game_object_events_traits_TraitPostDeserializeEvent(self))

    def isNew(self):
        return (self.version == pw_tales_cofdsystem_game_object_traits_TraitVersion.NEW)

    def hasChanges(self):
        _g = self.version
        tmp = _g.index
        if (tmp == 0):
            return True
        elif (tmp == 1):
            return (haxe_format_JsonPrinter.print(_g.params[0],None,None) != haxe_format_JsonPrinter.print(self.serialize(),None,None))
        else:
            pass

    def acceptChanges(self):
        self.version = pw_tales_cofdsystem_game_object_traits_TraitVersion.VERSION(self.serialize())

    def revertChanges(self):
        self.deserialize(self.version)

    def collect(self,e):
        e.collect(self)

    def toString(self):
        return (((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[") + Std.string(self.serialize())) + "]")

pw_tales_cofdsystem_game_object_traits_Trait._hx_class = pw_tales_cofdsystem_game_object_traits_Trait
_hx_classes["pw.tales.cofdsystem.game_object.traits.Trait"] = pw_tales_cofdsystem_game_object_traits_Trait


class pw_tales_cofdsystem_equipment_traits_EquipmentTrait(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.equipment.traits.EquipmentTrait"
    _hx_is_interface = "False"
    __slots__ = ("holderEventBus",)
    _hx_fields = ["holderEventBus"]
    _hx_methods = ["getHolder", "getHand", "filterHolderEvent", "onRemoved"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.holderEventBus = None
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus = pw_tales_cofdsystem_utils_events_SubEventBus(self.system.events,self.filterHolderEvent)

    def getHolder(self):
        equippable = self.gameObject.getTrait(pw_tales_cofdsystem_equipment_traits_Equippable.TYPE)
        if (equippable is None):
            return None
        return equippable.getHolder()

    def getHand(self):
        holdingHang = self.gameObject.getTrait(pw_tales_cofdsystem_equipment_traits_HoldingHand.TYPE)
        if (holdingHang is None):
            return None
        return holdingHang.getHand()

    def filterHolderEvent(self,event):
        holder = self.getHolder()
        if (holder is None):
            return False
        e = Std.downcast(event,pw_tales_cofdsystem_game_object_events_IGameObjectEvent)
        if (e is not None):
            return e.isRelated(holder)
        else:
            return False

    def onRemoved(self):
        self.holderEventBus.disable()
        super().onRemoved()

pw_tales_cofdsystem_equipment_traits_EquipmentTrait._hx_class = pw_tales_cofdsystem_equipment_traits_EquipmentTrait
_hx_classes["pw.tales.cofdsystem.equipment.traits.EquipmentTrait"] = pw_tales_cofdsystem_equipment_traits_EquipmentTrait


class pw_tales_cofdsystem_equipment_traits_EquipmentMod(pw_tales_cofdsystem_equipment_traits_EquipmentTrait):
    _hx_class_name = "pw.tales.cofdsystem.equipment.traits.EquipmentMod"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["setValue", "getValue"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_equipment_traits_EquipmentTrait


    def __init__(self,dn,gameObject,_hx_type):
        self.value = 0
        super().__init__(dn,gameObject,_hx_type)

    def setValue(self,value):
        self.value = value
        self.notifyUpdated()

    def getValue(self):
        return self.value

pw_tales_cofdsystem_equipment_traits_EquipmentMod._hx_class = pw_tales_cofdsystem_equipment_traits_EquipmentMod
_hx_classes["pw.tales.cofdsystem.equipment.traits.EquipmentMod"] = pw_tales_cofdsystem_equipment_traits_EquipmentMod


class pw_tales_cofdsystem_game_object_traits_TraitType:
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.TraitType"
    _hx_is_interface = "False"
    __slots__ = ("dn", "name", "factoryMethod", "multiInstanced")
    _hx_fields = ["dn", "name", "factoryMethod", "multiInstanced"]
    _hx_methods = ["getDN", "getDisplayName", "getName", "setName", "isMultiInstanced", "setMultiInstanced", "canAdd", "createWithDN", "create", "toString"]
    _hx_statics = ["createType"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_registry_IRecord]

    def __init__(self,dn):
        self.multiInstanced = False
        self.factoryMethod = None
        self.name = None
        self.dn = dn

    def getDN(self):
        return self.dn

    def getDisplayName(self):
        if (self.name is not None):
            return self.name
        return StringTools.replace(self.dn,"_"," ")

    def getName(self):
        return self.name

    def setName(self,name):
        self.name = name

    def isMultiInstanced(self):
        return self.multiInstanced

    def setMultiInstanced(self,multiInstanced):
        self.multiInstanced = multiInstanced
        return self

    def canAdd(self,gameObject):
        createEvent = pw_tales_cofdsystem_game_object_events_TraitAddEvent(gameObject,self)
        gameObject.getSystem().events.post(createEvent)
        return (not createEvent.isCancelled())

    def createWithDN(self,dn,gameObject):
        if (self.factoryMethod is not None):
            return self.factoryMethod(dn,gameObject,self)
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/game_object/traits/TraitType.hx", 'lineNumber': 85, 'className': "pw.tales.cofdsystem.game_object.traits.TraitType", 'methodName': "createWithDN"}))

    def create(self,gameObject):
        newDn = None
        if self.isMultiInstanced():
            newDn = thx_Uuid.create()
        else:
            newDn = self.getDN()
        return self.createWithDN(newDn,gameObject)

    def toString(self):
        return (((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[") + HxOverrides.stringOrNull(self.getDN())) + "]")

    @staticmethod
    def createType(dn,factoryMethod):
        newType = pw_tales_cofdsystem_game_object_traits_TraitType(dn)
        newType.factoryMethod = factoryMethod
        return newType

pw_tales_cofdsystem_game_object_traits_TraitType._hx_class = pw_tales_cofdsystem_game_object_traits_TraitType
_hx_classes["pw.tales.cofdsystem.game_object.traits.TraitType"] = pw_tales_cofdsystem_game_object_traits_TraitType


class pw_tales_cofdsystem_game_object_events_AdvantageModEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.AdvantageModEvent"
    _hx_is_interface = "False"
    __slots__ = ("finalModifier", "advantage")
    _hx_fields = ["finalModifier", "advantage"]
    _hx_methods = ["getAdvantage", "apply", "getModifier"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject,advantage):
        self.advantage = None
        self.finalModifier = 0
        super().__init__(gameObject)
        self.advantage = advantage

    def getAdvantage(self):
        return self.advantage

    def apply(self,modifier):
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.finalModifier
        _hx_local_0.finalModifier = (_hx_local_1 + modifier)
        _hx_local_0.finalModifier

    def getModifier(self):
        return self.finalModifier

pw_tales_cofdsystem_game_object_events_AdvantageModEvent._hx_class = pw_tales_cofdsystem_game_object_events_AdvantageModEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.AdvantageModEvent"] = pw_tales_cofdsystem_game_object_events_AdvantageModEvent


class pw_tales_cofdsystem_utils_events_IEventBus:
    _hx_class_name = "pw.tales.cofdsystem.utils.events.IEventBus"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["createSubBus", "post", "addHandler", "addHandlerRecord", "removeHandlerRecord"]
pw_tales_cofdsystem_utils_events_IEventBus._hx_class = pw_tales_cofdsystem_utils_events_IEventBus
_hx_classes["pw.tales.cofdsystem.utils.events.IEventBus"] = pw_tales_cofdsystem_utils_events_IEventBus


class pw_tales_cofdsystem_utils_events_SubEventBus:
    _hx_class_name = "pw.tales.cofdsystem.utils.events.SubEventBus"
    _hx_is_interface = "False"
    __slots__ = ("parent", "filter", "enabled", "handlers")
    _hx_fields = ["parent", "filter", "enabled", "handlers"]
    _hx_methods = ["createSubBus", "post", "addHandler", "addHandlerRecord", "removeHandlerRecord", "enable", "disable", "checkEnabled"]
    _hx_statics = ["NO_FILTER"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_events_IEventBus]

    def __init__(self,parent,_hx_filter = None):
        self.handlers = []
        self.enabled = True
        self.parent = parent
        if (_hx_filter is None):
            _hx_filter = pw_tales_cofdsystem_utils_events_SubEventBus.NO_FILTER
        self.filter = _hx_filter

    def createSubBus(self):
        return pw_tales_cofdsystem_utils_events_SubEventBus(self)

    def post(self,event):
        self.checkEnabled()
        self.parent.post(event)

    def addHandler(self,_hx_type,handler,priority = None):
        _gthis = self
        self.checkEnabled()
        def _hx_local_0(event):
            if _gthis.filter(event):
                handler(event)
        record = self.parent.addHandler(_hx_type,_hx_local_0,priority)
        self.handlers.append(record)
        return record

    def addHandlerRecord(self,record):
        self.checkEnabled()
        self.parent.addHandlerRecord(record)
        self.handlers.append(record)

    def removeHandlerRecord(self,record):
        self.checkEnabled()
        self.parent.removeHandlerRecord(record)
        python_internal_ArrayImpl.remove(self.handlers,record)

    def enable(self):
        self.enabled = True
        _g = 0
        _g1 = self.handlers
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            record = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            self.parent.addHandlerRecord(record)

    def disable(self):
        self.enabled = False
        _g = 0
        _g1 = self.handlers
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            record = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            self.parent.removeHandlerRecord(record)

    def checkEnabled(self):
        if (not self.enabled):
            raise haxe_Exception.thrown("Attempt to use disabled sub bus.")

pw_tales_cofdsystem_utils_events_SubEventBus._hx_class = pw_tales_cofdsystem_utils_events_SubEventBus
_hx_classes["pw.tales.cofdsystem.utils.events.SubEventBus"] = pw_tales_cofdsystem_utils_events_SubEventBus


class pw_tales_cofdsystem_armor_traits_DefenceModifer(pw_tales_cofdsystem_equipment_traits_EquipmentMod):
    _hx_class_name = "pw.tales.cofdsystem.armor.traits.DefenceModifer"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["applyMod"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_equipment_traits_EquipmentMod


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_game_object_events_AdvantageModEvent,self.applyMod)

    def applyMod(self,event):
        if (event.getAdvantage().getType() != pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.TYPE):
            return
        event.apply(self.value)

pw_tales_cofdsystem_armor_traits_DefenceModifer._hx_class = pw_tales_cofdsystem_armor_traits_DefenceModifer
_hx_classes["pw.tales.cofdsystem.armor.traits.DefenceModifer"] = pw_tales_cofdsystem_armor_traits_DefenceModifer


class pw_tales_cofdsystem_armor_traits_SpeedModifer(pw_tales_cofdsystem_equipment_traits_EquipmentMod):
    _hx_class_name = "pw.tales.cofdsystem.armor.traits.SpeedModifer"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["applyMod"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_equipment_traits_EquipmentMod


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_game_object_events_AdvantageModEvent,self.applyMod)

    def applyMod(self,event):
        if (event.getAdvantage().getType() != pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.TYPE):
            return
        event.apply(self.value)

pw_tales_cofdsystem_armor_traits_SpeedModifer._hx_class = pw_tales_cofdsystem_armor_traits_SpeedModifer
_hx_classes["pw.tales.cofdsystem.armor.traits.SpeedModifer"] = pw_tales_cofdsystem_armor_traits_SpeedModifer


class pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating(pw_tales_cofdsystem_equipment_traits_EquipmentTrait):
    _hx_class_name = "pw.tales.cofdsystem.armor.traits.armor_rating.ArmorRating"
    _hx_is_interface = "False"
    __slots__ = ("general", "ballistic")
    _hx_fields = ["general", "ballistic"]
    _hx_methods = ["setGeneral", "setBallistic", "getGeneral", "getBallistic", "isRangedWeaponAttack", "applyArmorAbsorption"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_equipment_traits_EquipmentTrait


    def __init__(self,dn,gameObject,_hx_type):
        self.ballistic = 0
        self.general = 0
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_attack_events_AttackDamageGetEvent,self.applyArmorAbsorption)

    def setGeneral(self,general):
        self.general = general
        self.notifyUpdated()

    def setBallistic(self,ballistic):
        self.ballistic = ballistic
        self.notifyUpdated()

    def getGeneral(self):
        return self.general

    def getBallistic(self):
        return self.ballistic

    def isRangedWeaponAttack(self,action):
        weapon = action.getWeapon()
        if (weapon is None):
            return False
        return (weapon.getGameObject().getTrait(pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon.TYPE) is not None)

    def applyArmorAbsorption(self,event):
        holder = self.getHolder()
        if (holder is None):
            return
        if (not event.isTarget(holder)):
            return
        action = event.getAction()
        system = action.getSystem()
        general = self.getGeneral()
        ballistic = self.getBallistic()
        if (not self.isRangedWeaponAttack(action)):
            ballistic = 0
        armorGetEvent = pw_tales_cofdsystem_armor_traits_armor_rating_events_AttackArmorGetEvent(action,general,ballistic)
        system.events.post(armorGetEvent)
        general = armorGetEvent.getGeneral()
        ballistic = armorGetEvent.getBallistic()
        event.setDamage(pw_tales_cofdsystem_damage_DamageUtil.INSTANCE.simpleAbsorb(general,ballistic,event.getDamage()))

pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating._hx_class = pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating
_hx_classes["pw.tales.cofdsystem.armor.traits.armor_rating.ArmorRating"] = pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating


class pw_tales_cofdsystem_armor_traits_armor_rating_events_AttackArmorGetEvent(pw_tales_cofdsystem_action_attack_events_AttackEvent):
    _hx_class_name = "pw.tales.cofdsystem.armor.traits.armor_rating.events.AttackArmorGetEvent"
    _hx_is_interface = "False"
    __slots__ = ("general", "ballistic")
    _hx_fields = ["general", "ballistic"]
    _hx_methods = ["getGeneral", "getBallistic", "setGeneral", "setBallistic"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_attack_events_AttackEvent


    def __init__(self,action,general,ballistic):
        self.ballistic = None
        self.general = None
        super().__init__(action)
        self.general = general
        self.ballistic = ballistic

    def getGeneral(self):
        return self.general

    def getBallistic(self):
        return self.ballistic

    def setGeneral(self,general):
        self.general = general

    def setBallistic(self,ballistic):
        self.ballistic = ballistic

pw_tales_cofdsystem_armor_traits_armor_rating_events_AttackArmorGetEvent._hx_class = pw_tales_cofdsystem_armor_traits_armor_rating_events_AttackArmorGetEvent
_hx_classes["pw.tales.cofdsystem.armor.traits.armor_rating.events.AttackArmorGetEvent"] = pw_tales_cofdsystem_armor_traits_armor_rating_events_AttackArmorGetEvent


class pw_tales_cofdsystem_builder_exceptions_UnknownSideException(haxe_Exception):
    _hx_class_name = "pw.tales.cofdsystem.builder.exceptions.UnknownSideException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self):
        super().__init__("Unknown side.")
pw_tales_cofdsystem_builder_exceptions_UnknownSideException._hx_class = pw_tales_cofdsystem_builder_exceptions_UnknownSideException
_hx_classes["pw.tales.cofdsystem.builder.exceptions.UnknownSideException"] = pw_tales_cofdsystem_builder_exceptions_UnknownSideException


class pw_tales_cofdsystem_game_object_traits_text_TextTraitType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.text.TextTraitType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,dn):
        super().__init__(dn)

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_game_object_traits_text_TextTrait(dn,gameObject,self)

pw_tales_cofdsystem_game_object_traits_text_TextTraitType._hx_class = pw_tales_cofdsystem_game_object_traits_text_TextTraitType
_hx_classes["pw.tales.cofdsystem.game_object.traits.text.TextTraitType"] = pw_tales_cofdsystem_game_object_traits_text_TextTraitType


class pw_tales_cofdsystem_character_Character(pw_tales_cofdsystem_game_object_prefabs_Accessor):
    _hx_class_name = "pw.tales.cofdsystem.character.Character"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getName"]
    _hx_statics = ["__meta__", "NAME", "AGE", "PLAYER", "RACE", "NATION", "LANGUAGE", "VIRTUE", "VICE", "CONCEPT"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_prefabs_Accessor


    def __init__(self,gameObject):
        super().__init__(gameObject)

    def getName(self):
        return self.getText(pw_tales_cofdsystem_character_Character.NAME)

pw_tales_cofdsystem_character_Character._hx_class = pw_tales_cofdsystem_character_Character
_hx_classes["pw.tales.cofdsystem.character.Character"] = pw_tales_cofdsystem_character_Character


class pw_tales_cofdsystem_character_advancement_experience_ExpAdvancementType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.experience.ExpAdvancementType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,dn):
        super().__init__(dn)

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement(gameObject)

pw_tales_cofdsystem_character_advancement_experience_ExpAdvancementType._hx_class = pw_tales_cofdsystem_character_advancement_experience_ExpAdvancementType
_hx_classes["pw.tales.cofdsystem.character.advancement.experience.ExpAdvancementType"] = pw_tales_cofdsystem_character_advancement_experience_ExpAdvancementType


class pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.experience.ExpAdvancement"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canBeAdded", "canBeUpdated", "canBeRemoved"]
    _hx_statics = ["DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,gameObject):
        super().__init__(pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement.DN,gameObject,pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement.TYPE)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_events_TraitAddEvent,self.canBeAdded)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_events_TraitRemoveEvent,self.canBeRemoved)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent,self.canBeUpdated)

    def canBeAdded(self,event):
        if (self.gameObject.getState() != pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE):
            return
        advanceableType = pw_tales_cofdsystem_utils_Utility.downcast(event.getTraitType(),pw_tales_cofdsystem_character_advancement_experience_IAdvanceableType)
        if (advanceableType is None):
            event.setCancelled(True)
            return
        cost = advanceableType.getCreateCost()
        if (cost is None):
            event.setCancelled(True)
            return
        experience = self.gameObject.getTrait(pw_tales_cofdsystem_character_traits_Experience.TYPE)
        if (experience is None):
            event.setCancelled(True)
            return
        if (not experience.isEnough(cost)):
            event.setCancelled(True)
            return
        experience.spend(cost)

    def canBeUpdated(self,event):
        if (self.gameObject.getState() != pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE):
            return
        advanceableTrait = pw_tales_cofdsystem_utils_Utility.downcast(event.getTrait(),pw_tales_cofdsystem_character_advancement_experience_IAdvanceableTrait)
        if (advanceableTrait is None):
            event.setCancelled(True)
            return
        if (event.getTrait().getValue() <= event.getNewValue()):
            event.setCancelled(True)
            return
        cost = advanceableTrait.getCost(event.getNewValue())
        if (cost is None):
            event.setCancelled(True)
            return
        experience = self.gameObject.getTrait(pw_tales_cofdsystem_character_traits_Experience.TYPE)
        if (experience is None):
            event.setCancelled(True)
            return
        if (not experience.isEnough(cost)):
            event.setCancelled(True)
            return
        experience.spend(cost)

    def canBeRemoved(self,event):
        if (self.gameObject.getState() != pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE):
            return
        event.setCancelled(True)

pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.experience.ExpAdvancement"] = pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement


class pw_tales_cofdsystem_character_advancement_experience_IAdvanceableTrait:
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.experience.IAdvanceableTrait"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getCost"]
pw_tales_cofdsystem_character_advancement_experience_IAdvanceableTrait._hx_class = pw_tales_cofdsystem_character_advancement_experience_IAdvanceableTrait
_hx_classes["pw.tales.cofdsystem.character.advancement.experience.IAdvanceableTrait"] = pw_tales_cofdsystem_character_advancement_experience_IAdvanceableTrait


class pw_tales_cofdsystem_character_advancement_experience_IAdvanceableType:
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.experience.IAdvanceableType"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getCreateCost"]
pw_tales_cofdsystem_character_advancement_experience_IAdvanceableType._hx_class = pw_tales_cofdsystem_character_advancement_experience_IAdvanceableType
_hx_classes["pw.tales.cofdsystem.character.advancement.experience.IAdvanceableType"] = pw_tales_cofdsystem_character_advancement_experience_IAdvanceableType


class pw_tales_cofdsystem_character_advancement_generation_GenAdvancementType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.GenAdvancementType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,dn):
        super().__init__(dn)

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_advancement_generation_GenAdvancement(gameObject)

pw_tales_cofdsystem_character_advancement_generation_GenAdvancementType._hx_class = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementType
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.GenAdvancementType"] = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementType


class pw_tales_cofdsystem_character_advancement_generation_GenAdvancement(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.GenAdvancement"
    _hx_is_interface = "False"
    __slots__ = ("restrictions",)
    _hx_fields = ["restrictions"]
    _hx_methods = ["canBeAdded", "canBeUpdated"]
    _hx_statics = ["DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,gameObject):
        self.restrictions = []
        super().__init__(pw_tales_cofdsystem_character_advancement_generation_GenAdvancement.DN,gameObject,pw_tales_cofdsystem_character_advancement_generation_GenAdvancement.TYPE)
        x = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenAttributeAdvancement(gameObject)
        self.restrictions.append(x)
        x = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSkillAdvancement(gameObject)
        self.restrictions.append(x)
        x = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSpecialityAdvancement(gameObject)
        self.restrictions.append(x)
        x = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritAdvancement(gameObject)
        self.restrictions.append(x)
        x = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenWealthAdvancement(gameObject)
        self.restrictions.append(x)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_events_TraitAddEvent,self.canBeAdded)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent,self.canBeUpdated)

    def canBeAdded(self,event):
        if (self.gameObject.getState() != pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE):
            return
        _g = 0
        _g1 = self.restrictions
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            restriction = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            if event.isCancelled():
                return
            restriction.canBeAdded(event)

    def canBeUpdated(self,event):
        if (self.gameObject.getState() != pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE):
            return
        _g = 0
        _g1 = self.restrictions
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            restriction = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            if event.isCancelled():
                return
            restriction.canBeUpdated(event)

pw_tales_cofdsystem_character_advancement_generation_GenAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_GenAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.GenAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_GenAdvancement


class pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem:
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.GenAdvancementItem"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "traitClazz", "traitTypeClazz")
    _hx_fields = ["gameObject", "traitClazz", "traitTypeClazz"]
    _hx_methods = ["canTraitBeAdded", "canTraitBeUpdated", "canBeAdded", "canBeUpdated"]

    def __init__(self,traitClazz,traitTypeClazz,gameObject):
        self.gameObject = gameObject
        self.traitClazz = traitClazz
        self.traitTypeClazz = traitTypeClazz

    def canTraitBeAdded(self,traitType):
        raise haxe_Exception.thrown(thx_error_AbstractMethod(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/character/advancement/generation/GenAdvancementItem.hx", 'lineNumber': 30, 'className': "pw.tales.cofdsystem.character.advancement.generation.GenAdvancementItem", 'methodName': "canTraitBeAdded"})))

    def canTraitBeUpdated(self,trait,newValue):
        raise haxe_Exception.thrown(thx_error_AbstractMethod(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/character/advancement/generation/GenAdvancementItem.hx", 'lineNumber': 33, 'className': "pw.tales.cofdsystem.character.advancement.generation.GenAdvancementItem", 'methodName': "canTraitBeUpdated"})))

    def canBeAdded(self,event):
        traitType = pw_tales_cofdsystem_utils_Utility.downcast(event.getTraitType(),self.traitTypeClazz)
        if (traitType is None):
            return
        if (not self.canTraitBeAdded(traitType)):
            event.setCancelled(True)

    def canBeUpdated(self,event):
        trait = pw_tales_cofdsystem_utils_Utility.downcast(event.getTrait(),self.traitClazz)
        if (trait is None):
            return
        if (not self.canTraitBeUpdated(trait,event.getNewValue())):
            event.setCancelled(True)

pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem._hx_class = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.GenAdvancementItem"] = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem


class pw_tales_cofdsystem_game_object_events_CollectEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.CollectEvent"
    _hx_is_interface = "False"
    __slots__ = ("collected",)
    _hx_fields = ["collected"]
    _hx_methods = ["collect", "getCollected"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject):
        self.collected = []
        super().__init__(gameObject)

    def collect(self,aspiration):
        self.collected.append(aspiration)

    def getCollected(self):
        return self.collected

pw_tales_cofdsystem_game_object_events_CollectEvent._hx_class = pw_tales_cofdsystem_game_object_events_CollectEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.CollectEvent"] = pw_tales_cofdsystem_game_object_events_CollectEvent


class pw_tales_cofdsystem_character_advancement_generation_events_GenMeritCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.events.GenMeritCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_advancement_generation_events_GenMeritCollectEvent._hx_class = pw_tales_cofdsystem_character_advancement_generation_events_GenMeritCollectEvent
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.events.GenMeritCollectEvent"] = pw_tales_cofdsystem_character_advancement_generation_events_GenMeritCollectEvent


class pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement(pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenGroupAdvancement"
    _hx_is_interface = "False"
    __slots__ = ("freebuys",)
    _hx_fields = ["freebuys"]
    _hx_methods = ["getGroup", "getMinValue", "calcualteGroupSpent", "canTraitBeAdded", "canTraitBeUpdated"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem


    def __init__(self,traitClazz,traitTypeClazz,gameObject,freebuys):
        self.freebuys = None
        super().__init__(traitClazz,traitTypeClazz,gameObject)
        self.freebuys = freebuys

    def getGroup(self,traitType):
        raise haxe_Exception.thrown(thx_error_AbstractMethod(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/character/advancement/generation/trait_advancements/GenGroupAdvancement.hx", 'lineNumber': 28, 'className': "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenGroupAdvancement", 'methodName': "getGroup"})))

    def getMinValue(self):
        raise haxe_Exception.thrown(thx_error_AbstractMethod(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/character/advancement/generation/trait_advancements/GenGroupAdvancement.hx", 'lineNumber': 31, 'className': "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenGroupAdvancement", 'methodName': "getMinValue"})))

    def calcualteGroupSpent(self):
        groupValues = haxe_ds_StringMap()
        _g = 0
        _g1 = self.gameObject.getTraitManager().getTraits().items()
        while (_g < len(_g1)):
            trait = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            traitType = pw_tales_cofdsystem_utils_Utility.downcast(trait.getType(),self.traitTypeClazz)
            if (traitType is None):
                continue
            group = self.getGroup(traitType)
            currentValue = groupValues.h.get(group,None)
            if (currentValue is None):
                currentValue = 0
            v = ((currentValue + trait.getValue()) - self.getMinValue())
            groupValues.h[group] = v
        return groupValues

    def canTraitBeAdded(self,traitType):
        return True

    def canTraitBeUpdated(self,trait,newValue):
        if (newValue < self.getMinValue()):
            return False
        traitType = pw_tales_cofdsystem_utils_Utility.downcast(trait.getType(),self.traitTypeClazz)
        if (traitType is None):
            return False
        traitGroup = self.getGroup(traitType)
        groupSpentMap = self.calcualteGroupSpent()
        traitGroupSpent = groupSpentMap.h.get(traitGroup,None)
        if (traitGroupSpent is None):
            traitGroupSpent = 0
        availableFreebuys = list(self.freebuys)
        claimedFreebuys = haxe_ds_StringMap()
        _g = 0
        _g1 = []
        _hx_map = groupSpentMap
        item_keys = _hx_map.keys()
        while item_keys.hasNext():
            key = item_keys.next()
            item = _hx_AnonObject({'value': _hx_map.get(key), 'key': key})
            _g1.append(item)
        def _hx_local_0(a,b):
            return (b.value - a.value)
        _g1.sort(key= python_lib_Functools.cmp_to_key(_hx_local_0))
        while (_g < len(_g1)):
            item = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            first = (availableFreebuys[0] if 0 < len(availableFreebuys) else None)
            second = 0
            if (len(availableFreebuys) > 0):
                second = (availableFreebuys[1] if 1 < len(availableFreebuys) else None)
            if (item.value > second):
                claimedFreebuys.h[item.key] = first
                python_internal_ArrayImpl.remove(availableFreebuys,first)
        targetedFreebuy = traitGroupSpent
        if (traitGroup in claimedFreebuys.h):
            targetedFreebuy = claimedFreebuys.h.get(traitGroup,None)
        elif (len(availableFreebuys) > 0):
            biggestFreebuy = (availableFreebuys[0] if 0 < len(availableFreebuys) else None)
            if (targetedFreebuy <= biggestFreebuy):
                targetedFreebuy = biggestFreebuy
        return (((traitGroupSpent - trait.getValue()) + newValue) <= targetedFreebuy)

pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenGroupAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement


class pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenAttributeAdvancement(pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenAttributeAdvancement"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getMinValue", "getGroup"]
    _hx_statics = ["FREEBUYS"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement


    def __init__(self,gameObject):
        super().__init__(pw_tales_cofdsystem_character_traits_attribute_Attribute,pw_tales_cofdsystem_character_traits_attribute_AttributeType,gameObject,pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenAttributeAdvancement.FREEBUYS)

    def getMinValue(self):
        return pw_tales_cofdsystem_character_traits_attribute_Attribute.STARTING_VALUE

    def getGroup(self,traitType):
        return traitType.getGroup().getName()

pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenAttributeAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenAttributeAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenAttributeAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenAttributeAdvancement


class pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement(pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenMeritGroupAdvancement"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["collectMeritForGeneration", "calcualteMeritTotal"]
    _hx_statics = ["MERIT_GENERATION_LIMIT"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem


    def __init__(self,traitClazz,traitTypeClazz,gameObject):
        super().__init__(traitClazz,traitTypeClazz,gameObject)

    def collectMeritForGeneration(self,gameObject):
        event = pw_tales_cofdsystem_character_advancement_generation_events_GenMeritCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()

    def calcualteMeritTotal(self):
        merits = self.collectMeritForGeneration(self.gameObject)
        meritTotal = 0
        _g = 0
        while (_g < len(merits)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            trait = python_internal_ArrayImpl._get(merits, _hx_local_1())
            meritTotal = (meritTotal + trait.getValue())
        return meritTotal

pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenMeritGroupAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement


class pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritAdvancement(pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenMeritAdvancement"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canTraitBeAdded", "canTraitBeUpdated"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement


    def __init__(self,gameObject):
        super().__init__(pw_tales_cofdsystem_character_traits_merits_Merit,pw_tales_cofdsystem_character_traits_merits_MeritType,gameObject)

    def canTraitBeAdded(self,meritType):
        newValue = meritType.getLowestValue()
        return ((self.calcualteMeritTotal() + newValue) <= pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement.MERIT_GENERATION_LIMIT)

    def canTraitBeUpdated(self,merit,newValue):
        return (((self.calcualteMeritTotal() - merit.getValue()) + newValue) <= pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement.MERIT_GENERATION_LIMIT)

pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenMeritAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritAdvancement


class pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSkillAdvancement(pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenSkillAdvancement"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getMinValue", "getGroup"]
    _hx_statics = ["FREEBUYS"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenGroupAdvancement


    def __init__(self,gameObject):
        super().__init__(pw_tales_cofdsystem_character_traits_skill_Skill,pw_tales_cofdsystem_character_traits_skill_SkillType,gameObject,pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSkillAdvancement.FREEBUYS)

    def getMinValue(self):
        return 0

    def getGroup(self,traitType):
        return traitType.getGroup().getName()

pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSkillAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSkillAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenSkillAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSkillAdvancement


class pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSpecialityAdvancement(pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenSpecialityAdvancement"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canTraitBeAdded", "canTraitBeUpdated"]
    _hx_statics = ["SPECIALITY_GENERATION_LIMIT"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementItem


    def __init__(self,gameObject):
        super().__init__(pw_tales_cofdsystem_character_traits_speciality_Speciality,pw_tales_cofdsystem_game_object_traits_TraitType,gameObject)

    def canTraitBeAdded(self,specialityType):
        return ((len(pw_tales_cofdsystem_character_traits_speciality_Specialities.collect(self.gameObject)) + 1) <= pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSpecialityAdvancement.SPECIALITY_GENERATION_LIMIT)

    def canTraitBeUpdated(self,speciality,newValue):
        return True

pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSpecialityAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSpecialityAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenSpecialityAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSpecialityAdvancement


class pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenWealthAdvancement(pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement):
    _hx_class_name = "pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenWealthAdvancement"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canTraitBeAdded", "canTraitBeUpdated"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement


    def __init__(self,gameObject):
        super().__init__(pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage,pw_tales_cofdsystem_game_object_traits_TraitType,gameObject)

    def canTraitBeAdded(self,wealthAdvantageType):
        return True

    def canTraitBeUpdated(self,wealth,newValue):
        return (((self.calcualteMeritTotal() - wealth.getValue()) + newValue) <= pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement.MERIT_GENERATION_LIMIT)

pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenWealthAdvancement._hx_class = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenWealthAdvancement
_hx_classes["pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenWealthAdvancement"] = pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenWealthAdvancement


class pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent:
    _hx_class_name = "pw.tales.cofdsystem.scene.initiative.events.InitiativeEvent"
    _hx_is_interface = "False"
    __slots__ = ("initiative",)
    _hx_fields = ["initiative"]
    _hx_methods = ["getInitiative"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_events_IEvent]

    def __init__(self,initiative):
        self.initiative = initiative

    def getInitiative(self):
        return self.initiative

pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent._hx_class = pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent
_hx_classes["pw.tales.cofdsystem.scene.initiative.events.InitiativeEvent"] = pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent


class pw_tales_cofdsystem_scene_initiative_events_InitiativeModifiersEvent(pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent):
    _hx_class_name = "pw.tales.cofdsystem.scene.initiative.events.InitiativeModifiersEvent"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "finalModifier")
    _hx_fields = ["gameObject", "finalModifier"]
    _hx_methods = ["getGameObject", "apply", "getModifier", "isRelated"]
    _hx_statics = []
    _hx_interfaces = [pw_tales_cofdsystem_game_object_events_IGameObjectEvent]
    _hx_super = pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent


    def __init__(self,gameObject,initiative):
        self.gameObject = None
        self.finalModifier = 0
        super().__init__(initiative)
        self.gameObject = gameObject

    def getGameObject(self):
        return self.gameObject

    def apply(self,modifier):
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.finalModifier
        _hx_local_0.finalModifier = (_hx_local_1 + modifier)
        _hx_local_0.finalModifier

    def getModifier(self):
        return self.finalModifier

    def isRelated(self,gameObject):
        return (self.gameObject == gameObject)

pw_tales_cofdsystem_scene_initiative_events_InitiativeModifiersEvent._hx_class = pw_tales_cofdsystem_scene_initiative_events_InitiativeModifiersEvent
_hx_classes["pw.tales.cofdsystem.scene.initiative.events.InitiativeModifiersEvent"] = pw_tales_cofdsystem_scene_initiative_events_InitiativeModifiersEvent


class pw_tales_cofdsystem_utils_events_HandlerPriority:
    _hx_class_name = "pw.tales.cofdsystem.utils.events.HandlerPriority"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["LOWEST", "LOW", "NORMAL", "HIGH", "HIGHEST", "sortedCopy", "lower", "higher", "comparator"]

    @staticmethod
    def sortedCopy(prorities):
        copy = list(prorities)
        copy.sort(key= python_lib_Functools.cmp_to_key(pw_tales_cofdsystem_utils_events_HandlerPriority.comparator))
        return copy

    @staticmethod
    def lower(prorities):
        if (len(prorities) == 0):
            return pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL
        return (python_internal_ArrayImpl._get(pw_tales_cofdsystem_utils_events_HandlerPriority.sortedCopy(prorities), (len(prorities) - 1)) + 1)

    @staticmethod
    def higher(prorities):
        if (len(prorities) == 0):
            return pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL
        return (python_internal_ArrayImpl._get(pw_tales_cofdsystem_utils_events_HandlerPriority.sortedCopy(prorities), 0) - 1)

    @staticmethod
    def comparator(priority1,priority2):
        return (priority1 - priority2)
pw_tales_cofdsystem_utils_events_HandlerPriority._hx_class = pw_tales_cofdsystem_utils_events_HandlerPriority
_hx_classes["pw.tales.cofdsystem.utils.events.HandlerPriority"] = pw_tales_cofdsystem_utils_events_HandlerPriority


class pw_tales_cofdsystem_character_traits_HeldWeapon(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.HeldWeapon"
    _hx_is_interface = "False"
    __slots__ = ("mainHand", "offHand")
    _hx_fields = ["mainHand", "offHand"]
    _hx_methods = ["getHand", "setHand", "getMainHand", "getOffHand", "setMainHand", "setOffHand", "calculateWeaponsInitiativeMod", "applyInitiativeMod"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.offHand = None
        self.mainHand = None
        super().__init__(dn,gameObject,_hx_type)
        self.eventBus.addHandler(pw_tales_cofdsystem_scene_initiative_events_InitiativeModifiersEvent,self.applyInitiativeMod,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def getHand(self,hand):
        if (hand == pw_tales_cofdsystem_common_EnumHand.HAND):
            return self.getMainHand()
        if (hand == pw_tales_cofdsystem_common_EnumHand.OFFHAND):
            return self.getOffHand()
        return None

    def setHand(self,hand,newWeapon):
        oldWeapon = self.getHand(hand)
        if (oldWeapon is not None):
            oldWeapon.unsetEquipper()
        if (hand == pw_tales_cofdsystem_common_EnumHand.HAND):
            self.mainHand = newWeapon
        elif (hand == pw_tales_cofdsystem_common_EnumHand.OFFHAND):
            self.offHand = newWeapon
        else:
            pass
        if (newWeapon is not None):
            newWeapon.setEquipper(self.gameObject,hand)

    def getMainHand(self):
        return self.mainHand

    def getOffHand(self):
        return self.offHand

    def setMainHand(self,mainHand):
        self.setHand(pw_tales_cofdsystem_common_EnumHand.HAND,mainHand)

    def setOffHand(self,offHand):
        self.setHand(pw_tales_cofdsystem_common_EnumHand.OFFHAND,offHand)

    def calculateWeaponsInitiativeMod(self,gameObject):
        mainWeaponMod = (self.mainHand.getInitiativeMod() if ((self.mainHand is not None)) else None)
        offWeaponMod = (self.offHand.getInitiativeMod() if ((self.offHand is not None)) else None)
        if ((mainWeaponMod is not None) and ((offWeaponMod is not None))):
            x = (mainWeaponMod if (python_lib_Math.isnan(mainWeaponMod)) else (offWeaponMod if (python_lib_Math.isnan(offWeaponMod)) else min(mainWeaponMod,offWeaponMod)))
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                None
                tmp = None
            return (tmp - 1)
        if (mainWeaponMod is not None):
            return mainWeaponMod
        if (offWeaponMod is not None):
            return offWeaponMod
        return 0

    def applyInitiativeMod(self,event):
        event.apply(self.calculateWeaponsInitiativeMod(self.gameObject))

pw_tales_cofdsystem_character_traits_HeldWeapon._hx_class = pw_tales_cofdsystem_character_traits_HeldWeapon
_hx_classes["pw.tales.cofdsystem.character.traits.HeldWeapon"] = pw_tales_cofdsystem_character_traits_HeldWeapon


class pw_tales_cofdsystem_character_traits_WornArmor(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.WornArmor"
    _hx_is_interface = "False"
    __slots__ = ("armor",)
    _hx_fields = ["armor"]
    _hx_methods = ["setArmor", "getArmor"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.armor = None
        super().__init__(dn,gameObject,_hx_type)

    def setArmor(self,armor):
        if (self.armor is not None):
            self.armor.unsetHolder()
        self.armor = armor
        if (self.armor is not None):
            self.armor.setHolder(self.gameObject)

    def getArmor(self):
        return self.armor

pw_tales_cofdsystem_character_traits_WornArmor._hx_class = pw_tales_cofdsystem_character_traits_WornArmor
_hx_classes["pw.tales.cofdsystem.character.traits.WornArmor"] = pw_tales_cofdsystem_character_traits_WornArmor


class pw_tales_cofdsystem_character_traits_position_PositionType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.position.PositionType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,dn):
        super().__init__(dn)

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_position_PositionTrait(gameObject)

pw_tales_cofdsystem_character_traits_position_PositionType._hx_class = pw_tales_cofdsystem_character_traits_position_PositionType
_hx_classes["pw.tales.cofdsystem.character.traits.position.PositionType"] = pw_tales_cofdsystem_character_traits_position_PositionType


class pw_tales_cofdsystem_character_traits_position_PositionTrait(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.position.PositionTrait"
    _hx_is_interface = "False"
    __slots__ = ("provider",)
    _hx_fields = ["provider"]
    _hx_methods = ["setPosProvider", "getPos", "distanceTo"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,gameObject):
        self.provider = None
        super().__init__(pw_tales_cofdsystem_character_traits_position_PositionTrait.TYPE.getDN(),gameObject,pw_tales_cofdsystem_character_traits_position_PositionTrait.TYPE)

    def setPosProvider(self,provider):
        self.provider = provider

    def getPos(self):
        if (self.provider is None):
            raise haxe_Exception.thrown((("Pos source is not set for " + Std.string(self.gameObject)) + "."))
        return self.provider.getPos()

    def distanceTo(self,other):
        p0 = self.getPos()
        p1 = other.getPos()
        x = (p0.x - p1.x)
        y = (p0.y - p1.y)
        z = (p0.z - p1.z)
        v = (((x * x) + ((y * y))) + ((z * z)))
        x = (Math.NaN if ((v < 0)) else python_lib_Math.sqrt(v))
        try:
            return int(x)
        except BaseException as _g:
            None
            return None

pw_tales_cofdsystem_character_traits_position_PositionTrait._hx_class = pw_tales_cofdsystem_character_traits_position_PositionTrait
_hx_classes["pw.tales.cofdsystem.character.traits.position.PositionTrait"] = pw_tales_cofdsystem_character_traits_position_PositionTrait


class pw_tales_cofdsystem_character_traits_attribute_AttributePurpose(pw_tales_cofdsystem_utils_EnumNamed):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.attribute.AttributePurpose"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["VALUES", "POWER", "FINESSE", "RESISTANCE", "byName"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_EnumNamed


    def __init__(self,name):
        super().__init__(name)
        pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.VALUES.h[name] = self

    @staticmethod
    def byName(name):
        value = pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.VALUES.h.get(name,None)
        if (value is None):
            raise haxe_Exception.thrown("Wrong name")
        return value
pw_tales_cofdsystem_character_traits_attribute_AttributePurpose._hx_class = pw_tales_cofdsystem_character_traits_attribute_AttributePurpose
_hx_classes["pw.tales.cofdsystem.character.traits.attribute.AttributePurpose"] = pw_tales_cofdsystem_character_traits_attribute_AttributePurpose


class pw_tales_cofdsystem_character_traits_attribute_AttributeGroup(pw_tales_cofdsystem_utils_EnumNamed):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.attribute.AttributeGroup"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["VALUES", "MENTAL", "PHYSICAL", "SOCIAL", "byName"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_EnumNamed


    def __init__(self,name):
        super().__init__(name)
        pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.VALUES.h[name] = self

    @staticmethod
    def byName(name):
        value = pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.VALUES.h.get(name,None)
        if (value is None):
            raise haxe_Exception.thrown("Wrong name")
        return value
pw_tales_cofdsystem_character_traits_attribute_AttributeGroup._hx_class = pw_tales_cofdsystem_character_traits_attribute_AttributeGroup
_hx_classes["pw.tales.cofdsystem.character.traits.attribute.AttributeGroup"] = pw_tales_cofdsystem_character_traits_attribute_AttributeGroup


class pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.value_trait.ValueTraitType"
    _hx_is_interface = "False"
    __slots__ = ("dotCost",)
    _hx_fields = ["dotCost"]
    _hx_methods = ["getLowestValue", "getDotCost", "getCreateCost"]
    _hx_statics = []
    _hx_interfaces = [pw_tales_cofdsystem_character_advancement_experience_IAdvanceableType]
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,dn):
        self.dotCost = None
        super().__init__(dn)

    def getLowestValue(self):
        return 0

    def getDotCost(self):
        return self.dotCost

    def getCreateCost(self):
        if (self.dotCost is None):
            return None
        return (self.getLowestValue() * self.dotCost)

pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType._hx_class = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType
_hx_classes["pw.tales.cofdsystem.game_object.traits.value_trait.ValueTraitType"] = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType


class pw_tales_cofdsystem_character_traits_attribute_AttributeType(pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.attribute.AttributeType"
    _hx_is_interface = "False"
    __slots__ = ("purpose", "group")
    _hx_fields = ["purpose", "group"]
    _hx_methods = ["getPurpose", "getGroup", "createWithDN"]
    _hx_statics = ["STARTING_VALUE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType


    def __init__(self,dn,purpose,group):
        self.group = None
        self.purpose = None
        super().__init__(dn)
        self.purpose = purpose
        self.group = group

    def getPurpose(self):
        return self.purpose

    def getGroup(self):
        return self.group

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_attribute_Attribute(dn,gameObject,self,pw_tales_cofdsystem_character_traits_attribute_AttributeType.STARTING_VALUE)

pw_tales_cofdsystem_character_traits_attribute_AttributeType._hx_class = pw_tales_cofdsystem_character_traits_attribute_AttributeType
_hx_classes["pw.tales.cofdsystem.character.traits.attribute.AttributeType"] = pw_tales_cofdsystem_character_traits_attribute_AttributeType


class pw_tales_cofdsystem_character_traits_attribute_Attributes:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.attribute.Attributes"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["__meta__", "INTELLIGENCE", "WITS", "RESOLVE", "STRENGTH", "DEXTERITY", "STAMINA", "PRESENCE", "MANIPULATION", "COMPOSURE"]
pw_tales_cofdsystem_character_traits_attribute_Attributes._hx_class = pw_tales_cofdsystem_character_traits_attribute_Attributes
_hx_classes["pw.tales.cofdsystem.character.traits.attribute.Attributes"] = pw_tales_cofdsystem_character_traits_attribute_Attributes


class pw_tales_cofdsystem_character_traits_skill_SkillGroup(pw_tales_cofdsystem_utils_EnumNamed):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.skill.SkillGroup"
    _hx_is_interface = "False"
    __slots__ = ("penalty",)
    _hx_fields = ["penalty"]
    _hx_methods = ["getPenalty"]
    _hx_statics = ["VALUES", "MENTAL", "PHYSICAL", "SOCIAL", "byName"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_EnumNamed


    def __init__(self,name,penalty):
        self.penalty = None
        super().__init__(name)
        self.penalty = penalty
        pw_tales_cofdsystem_character_traits_skill_SkillGroup.VALUES.h[name] = self

    def getPenalty(self):
        return self.penalty

    @staticmethod
    def byName(name):
        value = pw_tales_cofdsystem_character_traits_skill_SkillGroup.VALUES.h.get(name,None)
        if (value is None):
            raise haxe_Exception.thrown("Wrong name")
        return value

pw_tales_cofdsystem_character_traits_skill_SkillGroup._hx_class = pw_tales_cofdsystem_character_traits_skill_SkillGroup
_hx_classes["pw.tales.cofdsystem.character.traits.skill.SkillGroup"] = pw_tales_cofdsystem_character_traits_skill_SkillGroup


class pw_tales_cofdsystem_character_traits_skill_SkillType(pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.skill.SkillType"
    _hx_is_interface = "False"
    __slots__ = ("group",)
    _hx_fields = ["group"]
    _hx_methods = ["getGroup", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType


    def __init__(self,dn,group):
        self.group = None
        super().__init__(dn)
        self.group = group

    def getGroup(self):
        return self.group

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_skill_Skill(dn,gameObject,self)

pw_tales_cofdsystem_character_traits_skill_SkillType._hx_class = pw_tales_cofdsystem_character_traits_skill_SkillType
_hx_classes["pw.tales.cofdsystem.character.traits.skill.SkillType"] = pw_tales_cofdsystem_character_traits_skill_SkillType


class pw_tales_cofdsystem_character_traits_skill_Skills:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.skill.Skills"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["__meta__", "ACADEMICS", "ENIGMAS", "CRAFTS", "INVESTIGATION", "MEDICINE", "OCCULT", "POLITICS", "SCIENCE", "ATHLETICS", "BRAWL", "RIDE", "SHOOTING", "LARCENY", "STEALTH", "SURVIVAL", "WEAPONRY", "ANIMAL_KEN", "EMPATHY", "EXPRESSION", "INTIMIDATION", "PERSUASION", "SOCIALIZE", "STREETWISE", "SUBTERFUGE", "collect", "collectByGroup"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_character_traits_skill_events_SkillCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()

    @staticmethod
    def collectByGroup(gameObject,group):
        event = pw_tales_cofdsystem_character_traits_skill_events_SkillGroupCollectEvent(gameObject,group)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_character_traits_skill_Skills._hx_class = pw_tales_cofdsystem_character_traits_skill_Skills
_hx_classes["pw.tales.cofdsystem.character.traits.skill.Skills"] = pw_tales_cofdsystem_character_traits_skill_Skills


class pw_tales_cofdsystem_game_object_traits_advantages_Advantage(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.advantages.Advantage"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["shouldUpdateView"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)

    def shouldUpdateView(self,event):
        return True

pw_tales_cofdsystem_game_object_traits_advantages_Advantage._hx_class = pw_tales_cofdsystem_game_object_traits_advantages_Advantage
_hx_classes["pw.tales.cofdsystem.game_object.traits.advantages.Advantage"] = pw_tales_cofdsystem_game_object_traits_advantages_Advantage


class pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression(pw_tales_cofdsystem_game_object_traits_advantages_Advantage):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.advantages.AdvantageExpression"
    _hx_is_interface = "False"
    __slots__ = ("pool",)
    _hx_fields = ["pool"]
    _hx_methods = ["getValue"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_Advantage


    def __init__(self,dn,gameObject,_hx_type,poolBuilder):
        self.pool = None
        super().__init__(dn,gameObject,_hx_type)
        self.pool = poolBuilder.build(gameObject)

    def getValue(self):
        event = pw_tales_cofdsystem_game_object_events_AdvantageModEvent(self.gameObject,self)
        self.gameObject.getSystem().events.post(event)
        return (self.pool.calculate() + event.getModifier())

pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression._hx_class = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression
_hx_classes["pw.tales.cofdsystem.game_object.traits.advantages.AdvantageExpression"] = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression


class pw_tales_cofdsystem_dices_pool_IPoolBuilder:
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.IPoolBuilder"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["plus", "getHumanReadable", "build"]
pw_tales_cofdsystem_dices_pool_IPoolBuilder._hx_class = pw_tales_cofdsystem_dices_pool_IPoolBuilder
_hx_classes["pw.tales.cofdsystem.dices.pool.IPoolBuilder"] = pw_tales_cofdsystem_dices_pool_IPoolBuilder


class pw_tales_cofdsystem_dices_pool_builder_PoolBuilder:
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.builder.PoolBuilder"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getHumanReadable", "build", "plus"]
    _hx_interfaces = [pw_tales_cofdsystem_dices_pool_IPoolBuilder]

    def __init__(self):
        pass

    def getHumanReadable(self):
        raise haxe_Exception.thrown("Unimplemented")

    def build(self,gameObject):
        raise haxe_Exception.thrown("Unimplemented")

    def plus(self,other):
        return pw_tales_cofdsystem_dices_pool_builder_PBSum(self,other)

pw_tales_cofdsystem_dices_pool_builder_PoolBuilder._hx_class = pw_tales_cofdsystem_dices_pool_builder_PoolBuilder
_hx_classes["pw.tales.cofdsystem.dices.pool.builder.PoolBuilder"] = pw_tales_cofdsystem_dices_pool_builder_PoolBuilder


class pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_dices_pool_builder_PoolBuilder):
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.builder.PBTrait"
    _hx_is_interface = "False"
    __slots__ = ("dn",)
    _hx_fields = ["dn"]
    _hx_methods = ["getHumanReadable", "build"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_dices_pool_builder_PoolBuilder


    def __init__(self,dn):
        self.dn = None
        super().__init__()
        self.dn = dn

    def getHumanReadable(self):
        return Std.string(self.dn)

    def build(self,gameObject):
        return pw_tales_cofdsystem_dices_pool_math_PoolTrait(gameObject,self.dn)

pw_tales_cofdsystem_dices_pool_builder_PBTrait._hx_class = pw_tales_cofdsystem_dices_pool_builder_PBTrait
_hx_classes["pw.tales.cofdsystem.dices.pool.builder.PBTrait"] = pw_tales_cofdsystem_dices_pool_builder_PBTrait


class pw_tales_cofdsystem_dices_pool_builder_PBBinary(pw_tales_cofdsystem_dices_pool_builder_PoolBuilder):
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.builder.PBBinary"
    _hx_is_interface = "False"
    __slots__ = ("producer", "operand1", "operand2")
    _hx_fields = ["producer", "operand1", "operand2"]
    _hx_methods = ["build"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_dices_pool_builder_PoolBuilder


    def __init__(self,producer,operand1,operand2):
        self.operand2 = None
        self.operand1 = None
        self.producer = None
        super().__init__()
        self.producer = producer
        self.operand1 = operand1
        self.operand2 = operand2

    def build(self,gameObject):
        return self.producer(self.operand1.build(gameObject),self.operand2.build(gameObject))

pw_tales_cofdsystem_dices_pool_builder_PBBinary._hx_class = pw_tales_cofdsystem_dices_pool_builder_PBBinary
_hx_classes["pw.tales.cofdsystem.dices.pool.builder.PBBinary"] = pw_tales_cofdsystem_dices_pool_builder_PBBinary


class pw_tales_cofdsystem_dices_pool_builder_PBMin(pw_tales_cofdsystem_dices_pool_builder_PBBinary):
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.builder.PBMin"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getHumanReadable"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_dices_pool_builder_PBBinary


    def __init__(self,operand1,operand2):
        def _hx_local_0(operand1,operand2):
            return pw_tales_cofdsystem_utils_math_MathMin(operand1,operand2)
        super().__init__(_hx_local_0,operand1,operand2)

    def getHumanReadable(self):
        return (((("min(" + HxOverrides.stringOrNull(self.operand1.getHumanReadable())) + ", ") + HxOverrides.stringOrNull(self.operand2.getHumanReadable())) + ")")

pw_tales_cofdsystem_dices_pool_builder_PBMin._hx_class = pw_tales_cofdsystem_dices_pool_builder_PBMin
_hx_classes["pw.tales.cofdsystem.dices.pool.builder.PBMin"] = pw_tales_cofdsystem_dices_pool_builder_PBMin


class pw_tales_cofdsystem_utils_math_IMathOperation:
    _hx_class_name = "pw.tales.cofdsystem.utils.math.IMathOperation"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getOperands", "calculate"]
pw_tales_cofdsystem_utils_math_IMathOperation._hx_class = pw_tales_cofdsystem_utils_math_IMathOperation
_hx_classes["pw.tales.cofdsystem.utils.math.IMathOperation"] = pw_tales_cofdsystem_utils_math_IMathOperation


class pw_tales_cofdsystem_utils_math_MathBinaryOperation:
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathBinaryOperation"
    _hx_is_interface = "False"
    __slots__ = ("operand1", "operand2")
    _hx_fields = ["operand1", "operand2"]
    _hx_methods = ["getOperands", "calculate"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_math_IMathOperation]

    def __init__(self,operand1,operand2):
        self.operand1 = operand1
        self.operand2 = operand2

    def getOperands(self):
        return [self.operand1, self.operand2]

    def calculate(self):
        raise haxe_Exception.thrown("Unimplemented")

pw_tales_cofdsystem_utils_math_MathBinaryOperation._hx_class = pw_tales_cofdsystem_utils_math_MathBinaryOperation
_hx_classes["pw.tales.cofdsystem.utils.math.MathBinaryOperation"] = pw_tales_cofdsystem_utils_math_MathBinaryOperation


class pw_tales_cofdsystem_utils_math_MathMin(pw_tales_cofdsystem_utils_math_MathBinaryOperation):
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathMin"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["calculate"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_math_MathBinaryOperation


    def __init__(self,operand1,operand2):
        super().__init__(operand1,operand2)

    def calculate(self):
        a = self.operand1.calculate()
        b = self.operand2.calculate()
        return (a if (python_lib_Math.isnan(a)) else (b if (python_lib_Math.isnan(b)) else min(a,b)))

pw_tales_cofdsystem_utils_math_MathMin._hx_class = pw_tales_cofdsystem_utils_math_MathMin
_hx_classes["pw.tales.cofdsystem.utils.math.MathMin"] = pw_tales_cofdsystem_utils_math_MathMin


class pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.DefenceAdvantage"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["loseDefence"]
    _hx_statics = ["__meta__", "DN", "TYPE", "EXPR"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type,pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.EXPR)

    def loseDefence(self):
        pass

pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage._hx_class = pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.DefenceAdvantage"] = pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage


class pw_tales_cofdsystem_game_object_health_helper_IHealthTrait:
    _hx_class_name = "pw.tales.cofdsystem.game_object.health_helper.IHealthTrait"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["dealDamage"]
pw_tales_cofdsystem_game_object_health_helper_IHealthTrait._hx_class = pw_tales_cofdsystem_game_object_health_helper_IHealthTrait
_hx_classes["pw.tales.cofdsystem.game_object.health_helper.IHealthTrait"] = pw_tales_cofdsystem_game_object_health_helper_IHealthTrait


class pw_tales_cofdsystem_game_object_traits_advantages_AdvantageValue(pw_tales_cofdsystem_game_object_traits_advantages_Advantage):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.advantages.AdvantageValue"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["setValue", "getValue"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_Advantage


    def __init__(self,dn,gameObject,_hx_type,value):
        self.value = None
        super().__init__(dn,gameObject,_hx_type)
        self.value = value

    def setValue(self,value):
        self.value = value
        self.notifyUpdated()

    def getValue(self):
        event = pw_tales_cofdsystem_game_object_events_AdvantageModEvent(self.gameObject,self)
        self.eventBus.post(event)
        return (self.value + event.getModifier())

pw_tales_cofdsystem_game_object_traits_advantages_AdvantageValue._hx_class = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageValue
_hx_classes["pw.tales.cofdsystem.game_object.traits.advantages.AdvantageValue"] = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageValue


class pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_AdvantageValue):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.advantages.SizeAdvantage"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageValue


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type,5)
pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage._hx_class = pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage
_hx_classes["pw.tales.cofdsystem.game_object.traits.advantages.SizeAdvantage"] = pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage


class pw_tales_cofdsystem_game_object_health_helper_GetHealthTraitEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.health_helper.GetHealthTraitEvent"
    _hx_is_interface = "False"
    __slots__ = ("trait",)
    _hx_fields = ["trait"]
    _hx_methods = ["setHealthTrait", "getHealthTrait"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject):
        self.trait = None
        super().__init__(gameObject)

    def setHealthTrait(self,trait):
        self.trait = trait

    def getHealthTrait(self):
        return self.trait

pw_tales_cofdsystem_game_object_health_helper_GetHealthTraitEvent._hx_class = pw_tales_cofdsystem_game_object_health_helper_GetHealthTraitEvent
_hx_classes["pw.tales.cofdsystem.game_object.health_helper.GetHealthTraitEvent"] = pw_tales_cofdsystem_game_object_health_helper_GetHealthTraitEvent


class pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.health.HealthAdvantage"
    _hx_is_interface = "False"
    __slots__ = ("bashing", "lethal", "aggravated")
    _hx_fields = ["bashing", "lethal", "aggravated"]
    _hx_methods = ["getBashing", "getLethal", "getAggravated", "getFilledDamage", "getHealthLeft", "isDead", "applyDamage", "dealDamage", "setHealthTrait", "applyHealthPenalty"]
    _hx_statics = ["__meta__", "DN", "TYPE", "EXPR"]
    _hx_interfaces = [pw_tales_cofdsystem_game_object_health_helper_IHealthTrait]
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression


    def __init__(self,dn,gameObject,_hx_type):
        self.aggravated = 0
        self.lethal = 0
        self.bashing = 0
        super().__init__(dn,gameObject,_hx_type,pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.EXPR)
        self.eventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.applyHealthPenalty,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_health_helper_GetHealthTraitEvent,self.setHealthTrait,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def getBashing(self):
        return self.bashing

    def getLethal(self):
        return self.lethal

    def getAggravated(self):
        return self.aggravated

    def getFilledDamage(self):
        return ((self.bashing + self.lethal) + self.aggravated)

    def getHealthLeft(self):
        return (self.getValue() - self.getFilledDamage())

    def isDead(self):
        healthValue = self.getValue()
        return (self.aggravated >= healthValue)

    def applyDamage(self,damage):
        maxHealth = self.getValue()
        _g = 0
        _g1 = damage.getBashing()
        while (_g < _g1):
            _g = (_g + 1)
            if (self.getFilledDamage() >= maxHealth):
                if (self.bashing != 0):
                    _hx_local_1 = self
                    _hx_local_2 = _hx_local_1.bashing
                    _hx_local_1.bashing = (_hx_local_2 - 1)
                    _hx_local_2
                    _hx_local_3 = self
                    _hx_local_4 = _hx_local_3.lethal
                    _hx_local_3.lethal = (_hx_local_4 + 1)
                    _hx_local_4
                elif (self.lethal != 0):
                    _hx_local_5 = self
                    _hx_local_6 = _hx_local_5.lethal
                    _hx_local_5.lethal = (_hx_local_6 - 1)
                    _hx_local_6
                    _hx_local_7 = self
                    _hx_local_8 = _hx_local_7.aggravated
                    _hx_local_7.aggravated = (_hx_local_8 + 1)
                    _hx_local_8
            else:
                _hx_local_9 = self
                _hx_local_10 = _hx_local_9.bashing
                _hx_local_9.bashing = (_hx_local_10 + 1)
                _hx_local_10
        _g = 0
        _g1 = damage.getLethal()
        while (_g < _g1):
            _g = (_g + 1)
            if (self.getFilledDamage() >= maxHealth):
                if (self.bashing != 0):
                    _hx_local_12 = self
                    _hx_local_13 = _hx_local_12.bashing
                    _hx_local_12.bashing = (_hx_local_13 - 1)
                    _hx_local_13
                    _hx_local_14 = self
                    _hx_local_15 = _hx_local_14.lethal
                    _hx_local_14.lethal = (_hx_local_15 + 1)
                    _hx_local_15
                elif (self.lethal != 0):
                    _hx_local_16 = self
                    _hx_local_17 = _hx_local_16.lethal
                    _hx_local_16.lethal = (_hx_local_17 - 1)
                    _hx_local_17
                    _hx_local_18 = self
                    _hx_local_19 = _hx_local_18.aggravated
                    _hx_local_18.aggravated = (_hx_local_19 + 1)
                    _hx_local_19
            else:
                _hx_local_20 = self
                _hx_local_21 = _hx_local_20.lethal
                _hx_local_20.lethal = (_hx_local_21 + 1)
                _hx_local_21
        _g = 0
        _g1 = damage.getAggravated()
        while (_g < _g1):
            _g = (_g + 1)
            if (self.getFilledDamage() >= maxHealth):
                if (self.bashing != 0):
                    _hx_local_23 = self
                    _hx_local_24 = _hx_local_23.bashing
                    _hx_local_23.bashing = (_hx_local_24 - 1)
                    _hx_local_24
                    _hx_local_25 = self
                    _hx_local_26 = _hx_local_25.aggravated
                    _hx_local_25.aggravated = (_hx_local_26 + 1)
                    _hx_local_26
                elif (self.lethal != 0):
                    _hx_local_27 = self
                    _hx_local_28 = _hx_local_27.lethal
                    _hx_local_27.lethal = (_hx_local_28 - 1)
                    _hx_local_28
                    _hx_local_29 = self
                    _hx_local_30 = _hx_local_29.aggravated
                    _hx_local_29.aggravated = (_hx_local_30 + 1)
                    _hx_local_30
            else:
                _hx_local_31 = self
                _hx_local_32 = _hx_local_31.aggravated
                _hx_local_31.aggravated = (_hx_local_32 + 1)
                _hx_local_32

    def dealDamage(self,damage):
        self.applyDamage(damage)
        self.eventBus.post(pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDamagedEvent(self.gameObject,damage))
        if self.isDead():
            self.eventBus.post(pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDiedEvent(self.gameObject))
        self.notifyUpdated()

    def setHealthTrait(self,event):
        event.setHealthTrait(self)

    def applyHealthPenalty(self,event):
        if (not event.isPoolOwner(self.gameObject)):
            return
        healthLeft = self.getHealthLeft()
        penalty = 0
        if (healthLeft == 3):
            penalty = -1
        if (healthLeft == 2):
            penalty = -2
        if (healthLeft <= 1):
            penalty = -3
        event.getActionPool().getRequest().addModifier(penalty,pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.DN)

pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage._hx_class = pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.health.HealthAdvantage"] = pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage


class pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.InitiativeAdvantage"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["applyInitiativeMod"]
    _hx_statics = ["__meta__", "DN", "TYPE", "EXPR"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type,pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage.EXPR)
        self.eventBus.addHandler(pw_tales_cofdsystem_scene_initiative_events_InitiativeModifiersEvent,self.applyInitiativeMod,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def applyInitiativeMod(self,event):
        event.apply(self.getValue())

pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage._hx_class = pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.InitiativeAdvantage"] = pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage


class pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_Advantage):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.IntegrityAdvantage"
    _hx_is_interface = "False"
    __slots__ = ("points",)
    _hx_fields = ["points"]
    _hx_methods = ["getValue"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_Advantage


    def __init__(self,dn,gameObject,_hx_type):
        self.points = 7
        super().__init__(dn,gameObject,_hx_type)

    def getValue(self):
        return self.points

pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage._hx_class = pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.IntegrityAdvantage"] = pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage


class pw_tales_cofdsystem_dices_pool_builder_PBValue(pw_tales_cofdsystem_dices_pool_builder_PoolBuilder):
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.builder.PBValue"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["getHumanReadable", "build"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_dices_pool_builder_PoolBuilder


    def __init__(self,value):
        self.value = None
        super().__init__()
        self.value = value

    def getHumanReadable(self):
        return Std.string(self.value)

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathValue(self.value)

pw_tales_cofdsystem_dices_pool_builder_PBValue._hx_class = pw_tales_cofdsystem_dices_pool_builder_PBValue
_hx_classes["pw.tales.cofdsystem.dices.pool.builder.PBValue"] = pw_tales_cofdsystem_dices_pool_builder_PBValue


class pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.SpeedAdvantage"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE", "EXPR"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type,pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.EXPR)
pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage._hx_class = pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.SpeedAdvantage"] = pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage


class pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.willpower.WillpowerAdvantage"
    _hx_is_interface = "False"
    __slots__ = ("points",)
    _hx_fields = ["points"]
    _hx_methods = ["canUse", "getPoints", "burnWillpower"]
    _hx_statics = ["__meta__", "DN", "TYPE", "EXPR"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_AdvantageExpression


    def __init__(self,dn,gameObject,_hx_type):
        self.points = None
        super().__init__(dn,gameObject,_hx_type,pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.EXPR)

    def canUse(self):
        return (self.getPoints() > 0)

    def getPoints(self):
        if (self.points is not None):
            return self.points
        return self.getValue()

    def burnWillpower(self):
        newPoints = (self.getPoints() - 1)
        if (not self.canUse()):
            raise pw_tales_cofdsystem_character_traits_advantages_willpower_exceptions_NoWillpowerException(self)
        self.points = newPoints
        self.notifyUpdated()

pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage._hx_class = pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.willpower.WillpowerAdvantage"] = pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage


class pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage(pw_tales_cofdsystem_game_object_traits_advantages_Advantage):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.WealthAdvantage"
    _hx_is_interface = "False"
    __slots__ = ("points",)
    _hx_fields = ["points"]
    _hx_methods = ["canUpdate", "setValue", "getValue"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_advantages_Advantage


    def __init__(self,dn,gameObject,_hx_type):
        self.points = 0
        super().__init__(dn,gameObject,_hx_type)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_advancement_generation_events_GenMeritCollectEvent,self.collect)

    def canUpdate(self,newValue):
        event = pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent(self,newValue)
        self.system.events.post(event)
        return (not event.isCancelled())

    def setValue(self,points):
        if (not self.canUpdate(points)):
            return
        self.points = points
        self.notifyUpdated()

    def getValue(self):
        return self.points

pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage._hx_class = pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.WealthAdvantage"] = pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage


class pw_tales_cofdsystem_character_prefabs_HumanPrefab(pw_tales_cofdsystem_game_object_prefabs_Prefab):
    _hx_class_name = "pw.tales.cofdsystem.character.prefabs.HumanPrefab"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setUpGameObject"]
    _hx_statics = ["INSTANCE", "TRAITS"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_prefabs_Prefab


    def __init__(self,dn):
        super().__init__(dn)

    def setUpGameObject(self,gameObject):
        traitManager = gameObject.getTraitManager()
        _g = 0
        _g1 = pw_tales_cofdsystem_character_prefabs_HumanPrefab.TRAITS
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            record = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            traitManager.addTrait(record)

pw_tales_cofdsystem_character_prefabs_HumanPrefab._hx_class = pw_tales_cofdsystem_character_prefabs_HumanPrefab
_hx_classes["pw.tales.cofdsystem.character.prefabs.HumanPrefab"] = pw_tales_cofdsystem_character_prefabs_HumanPrefab


class pw_tales_cofdsystem_character_prefabs_PlayerPrefab(pw_tales_cofdsystem_character_prefabs_HumanPrefab):
    _hx_class_name = "pw.tales.cofdsystem.character.prefabs.PlayerPrefab"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setUpGameObject"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_prefabs_HumanPrefab


    def __init__(self,dn):
        super().__init__(dn)

    def setUpGameObject(self,gameObject):
        super().setUpGameObject(gameObject)
        gameObject.getTraitManager().addTrait(pw_tales_cofdsystem_character_traits_Experience.TYPE)

pw_tales_cofdsystem_character_prefabs_PlayerPrefab._hx_class = pw_tales_cofdsystem_character_prefabs_PlayerPrefab
_hx_classes["pw.tales.cofdsystem.character.prefabs.PlayerPrefab"] = pw_tales_cofdsystem_character_prefabs_PlayerPrefab


class pw_tales_cofdsystem_character_traits_Experience(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.Experience"
    _hx_is_interface = "False"
    __slots__ = ("beats", "spent")
    _hx_fields = ["beats", "spent"]
    _hx_methods = ["getExperience", "getBeats", "grantBeat", "isEnough", "spend"]
    _hx_statics = ["__meta__", "DN", "TYPE", "BEAT_AMOUNT"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.spent = 0
        self.beats = 0
        super().__init__(dn,gameObject,_hx_type)

    def getExperience(self):
        x = (self.beats / pw_tales_cofdsystem_character_traits_Experience.BEAT_AMOUNT)
        tmp = None
        try:
            tmp = int(x)
        except BaseException as _g:
            None
            tmp = None
        return (tmp - self.spent)

    def getBeats(self):
        return HxOverrides.mod(self.beats, pw_tales_cofdsystem_character_traits_Experience.BEAT_AMOUNT)

    def grantBeat(self):
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.beats
        _hx_local_0.beats = (_hx_local_1 + 1)
        _hx_local_0.beats
        self.notifyUpdated()

    def isEnough(self,amount):
        return (self.getExperience() < amount)

    def spend(self,amount,restriction = None):
        if (restriction is None):
            restriction = True
        if (restriction and self.isEnough(amount)):
            raise haxe_Exception.thrown("Not enough experience!")
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.spent
        _hx_local_0.spent = (_hx_local_1 + amount)
        _hx_local_0.spent
        self.notifyUpdated()

pw_tales_cofdsystem_character_traits_Experience._hx_class = pw_tales_cofdsystem_character_traits_Experience
_hx_classes["pw.tales.cofdsystem.character.traits.Experience"] = pw_tales_cofdsystem_character_traits_Experience


class pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDamagedEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.health.events.GameObjectDamagedEvent"
    _hx_is_interface = "False"
    __slots__ = ("damage",)
    _hx_fields = ["damage"]
    _hx_methods = ["getDamage"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject,damage):
        self.damage = None
        super().__init__(gameObject)
        self.damage = damage

    def getDamage(self):
        return self.damage

pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDamagedEvent._hx_class = pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDamagedEvent
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.health.events.GameObjectDamagedEvent"] = pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDamagedEvent


class pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDiedEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.health.events.GameObjectDiedEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDiedEvent._hx_class = pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDiedEvent
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.health.events.GameObjectDiedEvent"] = pw_tales_cofdsystem_character_traits_advantages_health_events_GameObjectDiedEvent


class pw_tales_cofdsystem_game_object_exceptions_GameObjectException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.exceptions.GameObjectException"
    _hx_is_interface = "False"
    __slots__ = ("gameObject",)
    _hx_fields = ["gameObject"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,gameObject,msg,previous = None):
        self.gameObject = None
        super().__init__(msg,previous)
        self.gameObject = gameObject

pw_tales_cofdsystem_game_object_exceptions_GameObjectException._hx_class = pw_tales_cofdsystem_game_object_exceptions_GameObjectException
_hx_classes["pw.tales.cofdsystem.game_object.exceptions.GameObjectException"] = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


class pw_tales_cofdsystem_game_object_exceptions_TraitException(pw_tales_cofdsystem_game_object_exceptions_GameObjectException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.exceptions.TraitException"
    _hx_is_interface = "False"
    __slots__ = ("trait",)
    _hx_fields = ["trait"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


    def __init__(self,trait,msg,previous = None):
        self.trait = None
        super().__init__(trait.getGameObject(),msg,previous)
        self.trait = trait

pw_tales_cofdsystem_game_object_exceptions_TraitException._hx_class = pw_tales_cofdsystem_game_object_exceptions_TraitException
_hx_classes["pw.tales.cofdsystem.game_object.exceptions.TraitException"] = pw_tales_cofdsystem_game_object_exceptions_TraitException


class pw_tales_cofdsystem_character_traits_advantages_willpower_exceptions_NoWillpowerException(pw_tales_cofdsystem_game_object_exceptions_TraitException):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.advantages.willpower.exceptions.NoWillpowerException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_TraitException


    def __init__(self,trait):
        super().__init__(trait,"No willpower.")
pw_tales_cofdsystem_character_traits_advantages_willpower_exceptions_NoWillpowerException._hx_class = pw_tales_cofdsystem_character_traits_advantages_willpower_exceptions_NoWillpowerException
_hx_classes["pw.tales.cofdsystem.character.traits.advantages.willpower.exceptions.NoWillpowerException"] = pw_tales_cofdsystem_character_traits_advantages_willpower_exceptions_NoWillpowerException


class pw_tales_cofdsystem_game_object_traits_text_TextTrait(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.text.TextTrait"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["getText", "setText"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.value = ""
        super().__init__(dn,gameObject,_hx_type)

    def getText(self):
        return self.value

    def setText(self,value):
        self.value = value
        self.notifyUpdated()

pw_tales_cofdsystem_game_object_traits_text_TextTrait._hx_class = pw_tales_cofdsystem_game_object_traits_text_TextTrait
_hx_classes["pw.tales.cofdsystem.game_object.traits.text.TextTrait"] = pw_tales_cofdsystem_game_object_traits_text_TextTrait


class pw_tales_cofdsystem_character_traits_aspiration_Aspiration(pw_tales_cofdsystem_game_object_traits_text_TextTrait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.aspiration.Aspiration"
    _hx_is_interface = "False"
    __slots__ = ("description",)
    _hx_fields = ["description"]
    _hx_methods = ["setTitle", "getTitle", "setDescription", "getDescription", "accomplish"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_text_TextTrait


    def __init__(self,dn,gameObject,_hx_type):
        self.description = ""
        _gthis = self
        super().__init__(dn,gameObject,_hx_type)
        def _hx_local_0(e):
            e.collect(_gthis)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_traits_aspiration_events_AspirationsCollectEvent,_hx_local_0)

    def setTitle(self,title):
        self.setText(title)

    def getTitle(self):
        return self.getText()

    def setDescription(self,description):
        self.description = description
        self.notifyUpdated()

    def getDescription(self):
        return self.description

    def accomplish(self):
        self.gameObject.getTrait(pw_tales_cofdsystem_character_traits_Experience.TYPE).grantBeat()
        self.gameObject.getTraitManager().removeTrait(self)

pw_tales_cofdsystem_character_traits_aspiration_Aspiration._hx_class = pw_tales_cofdsystem_character_traits_aspiration_Aspiration
_hx_classes["pw.tales.cofdsystem.character.traits.aspiration.Aspiration"] = pw_tales_cofdsystem_character_traits_aspiration_Aspiration


class pw_tales_cofdsystem_character_traits_aspiration_AspirationType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.aspiration.AspirationType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isMultiInstanced", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,dn):
        super().__init__(dn)

    def isMultiInstanced(self):
        return True

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_aspiration_Aspiration(dn,gameObject,self)

pw_tales_cofdsystem_character_traits_aspiration_AspirationType._hx_class = pw_tales_cofdsystem_character_traits_aspiration_AspirationType
_hx_classes["pw.tales.cofdsystem.character.traits.aspiration.AspirationType"] = pw_tales_cofdsystem_character_traits_aspiration_AspirationType


class pw_tales_cofdsystem_character_traits_aspiration_Aspirations:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.aspiration.Aspirations"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["__meta__", "TYPE", "SHORT_TERM_TYPE", "LONG_TERM_TYPE", "collect"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_character_traits_aspiration_events_AspirationsCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_character_traits_aspiration_Aspirations._hx_class = pw_tales_cofdsystem_character_traits_aspiration_Aspirations
_hx_classes["pw.tales.cofdsystem.character.traits.aspiration.Aspirations"] = pw_tales_cofdsystem_character_traits_aspiration_Aspirations


class pw_tales_cofdsystem_character_traits_aspiration_events_AspirationsCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.aspiration.events.AspirationsCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_traits_aspiration_events_AspirationsCollectEvent._hx_class = pw_tales_cofdsystem_character_traits_aspiration_events_AspirationsCollectEvent
_hx_classes["pw.tales.cofdsystem.character.traits.aspiration.events.AspirationsCollectEvent"] = pw_tales_cofdsystem_character_traits_aspiration_events_AspirationsCollectEvent


class pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.value_trait.ValueTrait"
    _hx_is_interface = "False"
    __slots__ = ("value", "valueType")
    _hx_fields = ["value", "valueType"]
    _hx_methods = ["getValue", "canUpdate", "getCost", "setValue"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = [pw_tales_cofdsystem_character_advancement_experience_IAdvanceableTrait]
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type,defaultValue):
        self.valueType = None
        self.value = None
        super().__init__(dn,gameObject,_hx_type)
        self.value = defaultValue
        self.valueType = _hx_type

    def getValue(self):
        return self.value

    def canUpdate(self,newValue):
        event = pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent(self,newValue)
        self.system.events.post(event)
        return (not event.isCancelled())

    def getCost(self,newValue):
        dotCost = self.valueType.getDotCost()
        if (dotCost is None):
            return None
        return (((newValue - self.getValue())) * dotCost)

    def setValue(self,value):
        if (not self.canUpdate(value)):
            raise pw_tales_cofdsystem_game_object_traits_value_trait_exceptions_UpdateRejectedException(self,value)
        self.value = value
        self.notifyUpdated()

pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait._hx_class = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait
_hx_classes["pw.tales.cofdsystem.game_object.traits.value_trait.ValueTrait"] = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait


class pw_tales_cofdsystem_character_traits_attribute_Attribute(pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.attribute.Attribute"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["STARTING_VALUE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait


    def __init__(self,dn,gameObject,_hx_type,defaultValue):
        super().__init__(dn,gameObject,_hx_type,defaultValue)
pw_tales_cofdsystem_character_traits_attribute_Attribute._hx_class = pw_tales_cofdsystem_character_traits_attribute_Attribute
_hx_classes["pw.tales.cofdsystem.character.traits.attribute.Attribute"] = pw_tales_cofdsystem_character_traits_attribute_Attribute


class pw_tales_cofdsystem_character_traits_condition_Condition(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.condition.Condition"
    _hx_is_interface = "False"
    __slots__ = ("customName", "description")
    _hx_fields = ["customName", "description"]
    _hx_methods = ["setCustomName", "getCustomName", "setDescription", "getDescription", "getDisplayName"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.description = ""
        self.customName = None
        super().__init__(dn,gameObject,_hx_type)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_traits_condition_events_ConditionsCollectEvent,self.collect)

    def setCustomName(self,customName):
        self.customName = customName
        self.notifyUpdated()

    def getCustomName(self):
        return self.customName

    def setDescription(self,description):
        self.description = description
        self.notifyUpdated()

    def getDescription(self):
        return self.description

    def getDisplayName(self):
        if (self.customName is not None):
            return self.customName
        return super().getDisplayName()

pw_tales_cofdsystem_character_traits_condition_Condition._hx_class = pw_tales_cofdsystem_character_traits_condition_Condition
_hx_classes["pw.tales.cofdsystem.character.traits.condition.Condition"] = pw_tales_cofdsystem_character_traits_condition_Condition


class pw_tales_cofdsystem_character_traits_condition_Conditions:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.condition.Conditions"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["collect"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_character_traits_condition_events_ConditionsCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_character_traits_condition_Conditions._hx_class = pw_tales_cofdsystem_character_traits_condition_Conditions
_hx_classes["pw.tales.cofdsystem.character.traits.condition.Conditions"] = pw_tales_cofdsystem_character_traits_condition_Conditions


class pw_tales_cofdsystem_character_traits_condition_events_ConditionsCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.condition.events.ConditionsCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_traits_condition_events_ConditionsCollectEvent._hx_class = pw_tales_cofdsystem_character_traits_condition_events_ConditionsCollectEvent
_hx_classes["pw.tales.cofdsystem.character.traits.condition.events.ConditionsCollectEvent"] = pw_tales_cofdsystem_character_traits_condition_events_ConditionsCollectEvent


class pw_tales_cofdsystem_character_traits_merits_MeritType(pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.MeritType"
    _hx_is_interface = "False"
    __slots__ = ("levels", "requirements")
    _hx_fields = ["levels", "requirements"]
    _hx_methods = ["getRequirements", "addRequirements", "setRequirements", "getLevels", "setLevels", "isMultiInstanced", "getLowestValue", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTraitType


    def __init__(self,dn):
        self.requirements = None
        self.levels = pw_tales_cofdsystem_parser_nodes_NodeDotsRange.create(1,5)
        super().__init__(dn)

    def getRequirements(self):
        return self.requirements

    def addRequirements(self,requirements):
        if (self.requirements is None):
            self.requirements = requirements
        else:
            self.requirements = pw_tales_cofdsystem_parser_nodes_NodeAnd(self.requirements,requirements)

    def setRequirements(self,requirement):
        self.requirements = requirement

    def getLevels(self):
        return self.levels

    def setLevels(self,levels):
        self.levels = levels

    def isMultiInstanced(self):
        return True

    def getLowestValue(self):
        return python_internal_ArrayImpl._get(self.levels.getLevels(), 0)

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_merits_Merit(dn,gameObject,self)

pw_tales_cofdsystem_character_traits_merits_MeritType._hx_class = pw_tales_cofdsystem_character_traits_merits_MeritType
_hx_classes["pw.tales.cofdsystem.character.traits.merits.MeritType"] = pw_tales_cofdsystem_character_traits_merits_MeritType


class pw_tales_cofdsystem_character_traits_merits_Merit(pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.Merit"
    _hx_is_interface = "False"
    __slots__ = ("meritType", "customName", "description")
    _hx_fields = ["meritType", "customName", "description"]
    _hx_methods = ["canUpdate", "getValue", "setCustomName", "getCustomName", "setDescription", "getDescription", "getDisplayName"]
    _hx_statics = ["__meta__", "CUSTOM_MERIT_TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait


    def __init__(self,dn,gameObject,_hx_type,customName = None,description = None):
        self.meritType = None
        self.description = ""
        self.customName = None
        _gthis = self
        super().__init__(dn,gameObject,_hx_type,_hx_type.getLowestValue())
        self.meritType = _hx_type
        self.customName = customName
        if (description is not None):
            self.description = description
        def _hx_local_0(e):
            e.collect(_gthis)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_traits_merits_events_MeritsCollectEvent,_hx_local_0)
        def _hx_local_1(e):
            e.collect(_gthis)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_advancement_generation_events_GenMeritCollectEvent,_hx_local_1)

    def canUpdate(self,newValue):
        if (python_internal_ArrayImpl.indexOf(self.meritType.getLevels().getLevels(),newValue,None) == -1):
            return False
        return super().canUpdate(newValue)

    def getValue(self):
        return self.value

    def setCustomName(self,customName):
        self.customName = customName
        self.notifyUpdated()

    def getCustomName(self):
        return self.customName

    def setDescription(self,description):
        self.description = description
        self.notifyUpdated()

    def getDescription(self):
        return self.description

    def getDisplayName(self):
        if (self.customName is not None):
            return self.customName
        return super().getDisplayName()

pw_tales_cofdsystem_character_traits_merits_Merit._hx_class = pw_tales_cofdsystem_character_traits_merits_Merit
_hx_classes["pw.tales.cofdsystem.character.traits.merits.Merit"] = pw_tales_cofdsystem_character_traits_merits_Merit


class pw_tales_cofdsystem_character_traits_merits_Merits:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.Merits"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["collect"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_character_traits_merits_events_MeritsCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_character_traits_merits_Merits._hx_class = pw_tales_cofdsystem_character_traits_merits_Merits
_hx_classes["pw.tales.cofdsystem.character.traits.merits.Merits"] = pw_tales_cofdsystem_character_traits_merits_Merits


class pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMeritType(pw_tales_cofdsystem_character_traits_merits_MeritType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.ambidextrous.AmbidextrousMeritType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isMultiInstanced", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_MeritType


    def __init__(self,dn):
        super().__init__(dn)

    def isMultiInstanced(self):
        return False

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMerit(dn,gameObject,self)

pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMeritType._hx_class = pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMeritType
_hx_classes["pw.tales.cofdsystem.character.traits.merits.ambidextrous.AmbidextrousMeritType"] = pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMeritType


class pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMerit(pw_tales_cofdsystem_character_traits_merits_Merit):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.ambidextrous.AmbidextrousMerit"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["onOffhandModifer"]
    _hx_statics = ["__meta__", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_Merit


    def __init__(self,dn,gameObject,_hx_type,customName = None):
        super().__init__(dn,gameObject,_hx_type,customName)
        self.eventBus.addHandler(pw_tales_cofdsystem_action_events_OffhandModiferEvent,self.onOffhandModifer,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def onOffhandModifer(self,event):
        event.setModifer(0)

pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMerit._hx_class = pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMerit
_hx_classes["pw.tales.cofdsystem.character.traits.merits.ambidextrous.AmbidextrousMerit"] = pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMerit


class pw_tales_cofdsystem_character_traits_merits_events_MeritsCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.events.MeritsCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_traits_merits_events_MeritsCollectEvent._hx_class = pw_tales_cofdsystem_character_traits_merits_events_MeritsCollectEvent
_hx_classes["pw.tales.cofdsystem.character.traits.merits.events.MeritsCollectEvent"] = pw_tales_cofdsystem_character_traits_merits_events_MeritsCollectEvent


class pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootType(pw_tales_cofdsystem_character_traits_merits_MeritType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.fleet_of_foot.FleetOfFootType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isMultiInstanced", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_MeritType


    def __init__(self,dn):
        super().__init__(dn)

    def isMultiInstanced(self):
        return False

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootMerit(dn,gameObject,self)

pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootType._hx_class = pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootType
_hx_classes["pw.tales.cofdsystem.character.traits.merits.fleet_of_foot.FleetOfFootType"] = pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootType


class pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootMerit(pw_tales_cofdsystem_character_traits_merits_Merit):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.fleet_of_foot.FleetOfFootMerit"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["onAdvantageModEvent"]
    _hx_statics = ["__meta__", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_Merit


    def __init__(self,dn,gameObject,_hx_type,customName = None):
        super().__init__(dn,gameObject,_hx_type,customName)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_events_AdvantageModEvent,self.onAdvantageModEvent,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def onAdvantageModEvent(self,event):
        if (event.getAdvantage().getType() != pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.TYPE):
            return
        event.apply(self.getValue())

pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootMerit._hx_class = pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootMerit
_hx_classes["pw.tales.cofdsystem.character.traits.merits.fleet_of_foot.FleetOfFootMerit"] = pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootMerit


class pw_tales_cofdsystem_character_traits_merits_giant_GiantMeritType(pw_tales_cofdsystem_character_traits_merits_MeritType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.giant.GiantMeritType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isMultiInstanced", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_MeritType


    def __init__(self,dn):
        super().__init__(dn)

    def isMultiInstanced(self):
        return False

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_merits_giant_GiantMerit(dn,gameObject,self)

pw_tales_cofdsystem_character_traits_merits_giant_GiantMeritType._hx_class = pw_tales_cofdsystem_character_traits_merits_giant_GiantMeritType
_hx_classes["pw.tales.cofdsystem.character.traits.merits.giant.GiantMeritType"] = pw_tales_cofdsystem_character_traits_merits_giant_GiantMeritType


class pw_tales_cofdsystem_character_traits_merits_giant_GiantMerit(pw_tales_cofdsystem_character_traits_merits_Merit):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.giant.GiantMerit"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["onAdvantageModEvent"]
    _hx_statics = ["__meta__", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_Merit


    def __init__(self,dn,gameObject,_hx_type,customName = None):
        super().__init__(dn,gameObject,_hx_type,customName)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_events_AdvantageModEvent,self.onAdvantageModEvent,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def onAdvantageModEvent(self,event):
        if (event.getAdvantage().getType() != pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.TYPE):
            return
        event.apply(1)

pw_tales_cofdsystem_character_traits_merits_giant_GiantMerit._hx_class = pw_tales_cofdsystem_character_traits_merits_giant_GiantMerit
_hx_classes["pw.tales.cofdsystem.character.traits.merits.giant.GiantMerit"] = pw_tales_cofdsystem_character_traits_merits_giant_GiantMerit


class pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedType(pw_tales_cofdsystem_character_traits_merits_MeritType):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.small_framed.SmallFramedType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isMultiInstanced", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_MeritType


    def __init__(self,dn):
        super().__init__(dn)

    def isMultiInstanced(self):
        return False

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedMerit(dn,gameObject,self)

pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedType._hx_class = pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedType
_hx_classes["pw.tales.cofdsystem.character.traits.merits.small_framed.SmallFramedType"] = pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedType


class pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedMerit(pw_tales_cofdsystem_character_traits_merits_Merit):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.merits.small_framed.SmallFramedMerit"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["onAdvantageModEvent"]
    _hx_statics = ["__meta__", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_merits_Merit


    def __init__(self,dn,gameObject,_hx_type,customName = None):
        super().__init__(dn,gameObject,_hx_type,customName)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_events_AdvantageModEvent,self.onAdvantageModEvent,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def onAdvantageModEvent(self,event):
        if (event.getAdvantage().getType() != pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.TYPE):
            return
        event.apply(-1)

pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedMerit._hx_class = pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedMerit
_hx_classes["pw.tales.cofdsystem.character.traits.merits.small_framed.SmallFramedMerit"] = pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedMerit


class pw_tales_cofdsystem_character_traits_position_Position:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.position.Position"
    _hx_is_interface = "False"
    __slots__ = ("x", "y", "z")
    _hx_fields = ["x", "y", "z"]

    def __init__(self,x,y,z):
        self.x = x
        self.y = y
        self.z = z

pw_tales_cofdsystem_character_traits_position_Position._hx_class = pw_tales_cofdsystem_character_traits_position_Position
_hx_classes["pw.tales.cofdsystem.character.traits.position.Position"] = pw_tales_cofdsystem_character_traits_position_Position


class pw_tales_cofdsystem_character_traits_position_PositionProvider:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.position.PositionProvider"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["getPos"]

    def __init__(self):
        pass

    def getPos(self):
        raise haxe_Exception.thrown(thx_error_AbstractMethod(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/character/traits/position/PositionProvider.hx", 'lineNumber': 11, 'className': "pw.tales.cofdsystem.character.traits.position.PositionProvider", 'methodName': "getPos"})))

pw_tales_cofdsystem_character_traits_position_PositionProvider._hx_class = pw_tales_cofdsystem_character_traits_position_PositionProvider
_hx_classes["pw.tales.cofdsystem.character.traits.position.PositionProvider"] = pw_tales_cofdsystem_character_traits_position_PositionProvider


class pw_tales_cofdsystem_character_traits_skill_Skill(pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.skill.Skill"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isSkillSpeciality", "shouldUpdateView", "getSpecialities"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait


    def __init__(self,dn,gameObject,_hx_type):
        _gthis = self
        super().__init__(dn,gameObject,_hx_type,0)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_traits_skill_events_SkillCollectEvent,self.collect)
        def _hx_local_0(e):
            if (e.getGroup() == _hx_type.getGroup()):
                _gthis.collect(e)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_traits_skill_events_SkillGroupCollectEvent,_hx_local_0)

    def isSkillSpeciality(self,trait):
        speciality = Std.downcast(trait,pw_tales_cofdsystem_character_traits_speciality_Speciality)
        if (speciality is None):
            return False
        return (speciality.getSkill() == self)

    def shouldUpdateView(self,event):
        result = super().shouldUpdateView(event)
        if result:
            return result
        traitEvent = Std.downcast(event,pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent)
        if (traitEvent is None):
            return False
        return self.isSkillSpeciality(traitEvent.getTrait())

    def getSpecialities(self):
        return list(filter(self.isSkillSpeciality,self.gameObject.getTraitManager().getTraits().items()))

pw_tales_cofdsystem_character_traits_skill_Skill._hx_class = pw_tales_cofdsystem_character_traits_skill_Skill
_hx_classes["pw.tales.cofdsystem.character.traits.skill.Skill"] = pw_tales_cofdsystem_character_traits_skill_Skill


class pw_tales_cofdsystem_character_traits_skill_events_SkillCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.skill.events.SkillCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_traits_skill_events_SkillCollectEvent._hx_class = pw_tales_cofdsystem_character_traits_skill_events_SkillCollectEvent
_hx_classes["pw.tales.cofdsystem.character.traits.skill.events.SkillCollectEvent"] = pw_tales_cofdsystem_character_traits_skill_events_SkillCollectEvent


class pw_tales_cofdsystem_character_traits_skill_events_SkillGroupCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.skill.events.SkillGroupCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ("group",)
    _hx_fields = ["group"]
    _hx_methods = ["getGroup"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject,group):
        self.group = None
        super().__init__(gameObject)
        self.group = group

    def getGroup(self):
        return self.group

pw_tales_cofdsystem_character_traits_skill_events_SkillGroupCollectEvent._hx_class = pw_tales_cofdsystem_character_traits_skill_events_SkillGroupCollectEvent
_hx_classes["pw.tales.cofdsystem.character.traits.skill.events.SkillGroupCollectEvent"] = pw_tales_cofdsystem_character_traits_skill_events_SkillGroupCollectEvent


class pw_tales_cofdsystem_character_traits_speciality_Specialities:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.speciality.Specialities"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["collect"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_character_traits_speciality_events_SpecialitiesCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_character_traits_speciality_Specialities._hx_class = pw_tales_cofdsystem_character_traits_speciality_Specialities
_hx_classes["pw.tales.cofdsystem.character.traits.speciality.Specialities"] = pw_tales_cofdsystem_character_traits_speciality_Specialities


class pw_tales_cofdsystem_character_traits_speciality_events_SpecialitiesCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.speciality.events.SpecialitiesCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_traits_speciality_events_SpecialitiesCollectEvent._hx_class = pw_tales_cofdsystem_character_traits_speciality_events_SpecialitiesCollectEvent
_hx_classes["pw.tales.cofdsystem.character.traits.speciality.events.SpecialitiesCollectEvent"] = pw_tales_cofdsystem_character_traits_speciality_events_SpecialitiesCollectEvent


class pw_tales_cofdsystem_character_traits_speciality_Speciality(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.speciality.Speciality"
    _hx_is_interface = "False"
    __slots__ = ("name", "skillDn")
    _hx_fields = ["name", "skillDn"]
    _hx_methods = ["getName", "setName", "getSkill", "setSkill"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.skillDn = ""
        self.name = ""
        super().__init__(dn,gameObject,_hx_type)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_traits_speciality_events_SpecialitiesCollectEvent,self.collect)

    def getName(self):
        return self.name

    def setName(self,name):
        self.name = name
        self.notifyUpdated()

    def getSkill(self):
        return self.gameObject.getTraitManager().getTraitByDn(self.skillDn)

    def setSkill(self,skill):
        self.skillDn = skill.getDN()
        self.notifyUpdated()

pw_tales_cofdsystem_character_traits_speciality_Speciality._hx_class = pw_tales_cofdsystem_character_traits_speciality_Speciality
_hx_classes["pw.tales.cofdsystem.character.traits.speciality.Speciality"] = pw_tales_cofdsystem_character_traits_speciality_Speciality


class pw_tales_cofdsystem_character_traits_tilts_Tilt(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.tilts.Tilt"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["onSceneEnd"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.eventBus.addHandler(pw_tales_cofdsystem_scene_events_SceneEndEvent,self.onSceneEnd,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)
        self.eventBus.addHandler(pw_tales_cofdsystem_character_traits_tilts_events_TiltsCollectEvent,self.collect)

    def onSceneEnd(self,event):
        self.gameObject.getTraitManager().removeTrait(self)

pw_tales_cofdsystem_character_traits_tilts_Tilt._hx_class = pw_tales_cofdsystem_character_traits_tilts_Tilt
_hx_classes["pw.tales.cofdsystem.character.traits.tilts.Tilt"] = pw_tales_cofdsystem_character_traits_tilts_Tilt


class pw_tales_cofdsystem_scene_events_SceneEvent:
    _hx_class_name = "pw.tales.cofdsystem.scene.events.SceneEvent"
    _hx_is_interface = "False"
    __slots__ = ("scene",)
    _hx_fields = ["scene"]
    _hx_methods = ["isRelated"]
    _hx_statics = ["START", "END"]
    _hx_interfaces = [pw_tales_cofdsystem_game_object_events_IGameObjectEvent]

    def __init__(self,scene):
        self.scene = scene

    def isRelated(self,gameObject):
        return (gameObject in self.scene.getInitiative().getOrder())

    @staticmethod
    def START(scene):
        return pw_tales_cofdsystem_scene_events_SceneStartEvent(scene)

    @staticmethod
    def END(scene):
        return pw_tales_cofdsystem_scene_events_SceneEndEvent(scene)

pw_tales_cofdsystem_scene_events_SceneEvent._hx_class = pw_tales_cofdsystem_scene_events_SceneEvent
_hx_classes["pw.tales.cofdsystem.scene.events.SceneEvent"] = pw_tales_cofdsystem_scene_events_SceneEvent


class pw_tales_cofdsystem_scene_events_SceneEndEvent(pw_tales_cofdsystem_scene_events_SceneEvent):
    _hx_class_name = "pw.tales.cofdsystem.scene.events.SceneEndEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_events_SceneEvent


    def __init__(self,scene):
        super().__init__(scene)
pw_tales_cofdsystem_scene_events_SceneEndEvent._hx_class = pw_tales_cofdsystem_scene_events_SceneEndEvent
_hx_classes["pw.tales.cofdsystem.scene.events.SceneEndEvent"] = pw_tales_cofdsystem_scene_events_SceneEndEvent


class pw_tales_cofdsystem_character_traits_tilts_events_TiltsCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.tilts.events.TiltsCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_character_traits_tilts_events_TiltsCollectEvent._hx_class = pw_tales_cofdsystem_character_traits_tilts_events_TiltsCollectEvent
_hx_classes["pw.tales.cofdsystem.character.traits.tilts.events.TiltsCollectEvent"] = pw_tales_cofdsystem_character_traits_tilts_events_TiltsCollectEvent


class pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt(pw_tales_cofdsystem_character_traits_tilts_Tilt):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.tilts.ArmWrackTilt"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_tilts_Tilt


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt._hx_class = pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt
_hx_classes["pw.tales.cofdsystem.character.traits.tilts.ArmWrackTilt"] = pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt


class pw_tales_cofdsystem_character_traits_tilts_BlindedTilt(pw_tales_cofdsystem_character_traits_tilts_Tilt):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.tilts.BlindedTilt"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_tilts_Tilt


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_character_traits_tilts_BlindedTilt._hx_class = pw_tales_cofdsystem_character_traits_tilts_BlindedTilt
_hx_classes["pw.tales.cofdsystem.character.traits.tilts.BlindedTilt"] = pw_tales_cofdsystem_character_traits_tilts_BlindedTilt


class pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt(pw_tales_cofdsystem_character_traits_tilts_Tilt):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.tilts.LegWrackTilt"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_tilts_Tilt


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt._hx_class = pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt
_hx_classes["pw.tales.cofdsystem.character.traits.tilts.LegWrackTilt"] = pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt


class pw_tales_cofdsystem_character_traits_tilts_StunnedTilt(pw_tales_cofdsystem_character_traits_tilts_Tilt):
    _hx_class_name = "pw.tales.cofdsystem.character.traits.tilts.StunnedTilt"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_character_traits_tilts_Tilt


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_character_traits_tilts_StunnedTilt._hx_class = pw_tales_cofdsystem_character_traits_tilts_StunnedTilt
_hx_classes["pw.tales.cofdsystem.character.traits.tilts.StunnedTilt"] = pw_tales_cofdsystem_character_traits_tilts_StunnedTilt


class pw_tales_cofdsystem_character_traits_tilts_Tilts:
    _hx_class_name = "pw.tales.cofdsystem.character.traits.tilts.Tilts"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["collect"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_character_traits_tilts_events_TiltsCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_character_traits_tilts_Tilts._hx_class = pw_tales_cofdsystem_character_traits_tilts_Tilts
_hx_classes["pw.tales.cofdsystem.character.traits.tilts.Tilts"] = pw_tales_cofdsystem_character_traits_tilts_Tilts


class pw_tales_cofdsystem_common_EnumHand(pw_tales_cofdsystem_utils_EnumNamed):
    _hx_class_name = "pw.tales.cofdsystem.common.EnumHand"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["VALUES", "HAND", "OFFHAND", "byName"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_EnumNamed


    def __init__(self,name):
        super().__init__(name)
        pw_tales_cofdsystem_common_EnumHand.VALUES.h[name] = self

    @staticmethod
    def byName(name):
        value = pw_tales_cofdsystem_common_EnumHand.VALUES.h.get(name,None)
        if (value is None):
            raise haxe_Exception.thrown("Wrong name")
        return value
pw_tales_cofdsystem_common_EnumHand._hx_class = pw_tales_cofdsystem_common_EnumHand
_hx_classes["pw.tales.cofdsystem.common.EnumHand"] = pw_tales_cofdsystem_common_EnumHand


class pw_tales_cofdsystem_common_EnumRange:
    _hx_class_name = "pw.tales.cofdsystem.common.EnumRange"
    _hx_is_interface = "False"
    __slots__ = ("name", "distance")
    _hx_fields = ["name", "distance"]
    _hx_methods = ["getDistance"]
    _hx_statics = ["__meta__", "VALUES", "CLOSE", "SHORT", "MEDIUM", "LONG", "EXTREME", "measure", "findByName"]

    def __init__(self,name,distance):
        self.name = name
        self.distance = distance
        pw_tales_cofdsystem_common_EnumRange.VALUES.append(self)

    def getDistance(self):
        return self.distance

    @staticmethod
    def measure(value):
        _g = 0
        _g1 = pw_tales_cofdsystem_common_EnumRange.VALUES
        while (_g < len(_g1)):
            range = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if (value < range.getDistance()):
                return range
        return pw_tales_cofdsystem_common_EnumRange.EXTREME

    @staticmethod
    def findByName(name):
        _g = 0
        _g1 = pw_tales_cofdsystem_common_EnumRange.VALUES
        while (_g < len(_g1)):
            range = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if (range.name == name):
                return range
        return None

pw_tales_cofdsystem_common_EnumRange._hx_class = pw_tales_cofdsystem_common_EnumRange
_hx_classes["pw.tales.cofdsystem.common.EnumRange"] = pw_tales_cofdsystem_common_EnumRange


class pw_tales_cofdsystem_common_EnumSide(pw_tales_cofdsystem_utils_EnumNamed):
    _hx_class_name = "pw.tales.cofdsystem.common.EnumSide"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["VALUES", "ACTOR", "TARGET", "byName"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_EnumNamed


    def __init__(self,name):
        super().__init__(name)
        pw_tales_cofdsystem_common_EnumSide.VALUES.h[name] = self

    @staticmethod
    def byName(name):
        value = pw_tales_cofdsystem_common_EnumSide.VALUES.h.get(name,None)
        if (value is None):
            raise haxe_Exception.thrown("Wrong name")
        return value
pw_tales_cofdsystem_common_EnumSide._hx_class = pw_tales_cofdsystem_common_EnumSide
_hx_classes["pw.tales.cofdsystem.common.EnumSide"] = pw_tales_cofdsystem_common_EnumSide


class pw_tales_cofdsystem_damage_Damage:
    _hx_class_name = "pw.tales.cofdsystem.damage.Damage"
    _hx_is_interface = "False"
    __slots__ = ("bashing", "lethal", "aggravated")
    _hx_fields = ["bashing", "lethal", "aggravated"]
    _hx_methods = ["getBashing", "getLethal", "getAggravated", "getTuple", "enusreBashing", "applyGeneralArmor", "applyBallisticArmor", "toString"]

    def __init__(self,bashing,lethal,aggravated):
        self.bashing = bashing
        self.lethal = lethal
        self.aggravated = aggravated

    def getBashing(self):
        return self.bashing

    def getLethal(self):
        return self.lethal

    def getAggravated(self):
        return self.aggravated

    def getTuple(self):
        return [self.bashing, self.lethal, self.aggravated]

    def enusreBashing(self):
        if (((self.bashing == 0) and ((self.lethal == 0))) and ((self.aggravated == 0))):
            self.bashing = 1

    def applyGeneralArmor(self,generalArmor):
        if ((self.aggravated != 0) and ((generalArmor != 0))):
            a = (self.aggravated - generalArmor)
            x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else max(a,0)))
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                None
                tmp = None
            a = (generalArmor - self.aggravated)
            x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else max(a,0)))
            try:
                generalArmor = int(x)
            except BaseException as _g:
                None
                generalArmor = None
            self.aggravated = tmp
        if ((self.lethal != 0) and ((generalArmor != 0))):
            a = (self.lethal - generalArmor)
            x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else max(a,0)))
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                None
                tmp = None
            a = (generalArmor - self.lethal)
            x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else max(a,0)))
            try:
                generalArmor = int(x)
            except BaseException as _g:
                None
                generalArmor = None
            self.lethal = tmp
        if ((self.bashing != 0) and ((generalArmor != 0))):
            a = (self.bashing - generalArmor)
            x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else max(a,0)))
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                None
                tmp = None
            self.bashing = tmp

    def applyBallisticArmor(self,ballisticArmor):
        b = self.lethal
        x = (ballisticArmor if (python_lib_Math.isnan(ballisticArmor)) else (b if (python_lib_Math.isnan(b)) else min(ballisticArmor,b)))
        bashingIncrement = None
        try:
            bashingIncrement = int(x)
        except BaseException as _g:
            None
            bashingIncrement = None
        a = (self.lethal - ballisticArmor)
        x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else max(a,0)))
        tmp = None
        try:
            tmp = int(x)
        except BaseException as _g:
            None
            tmp = None
        self.lethal = tmp
        _hx_local_0 = self
        _hx_local_1 = _hx_local_0.bashing
        _hx_local_0.bashing = (_hx_local_1 + bashingIncrement)
        _hx_local_0.bashing

    def toString(self):
        return (((((("Damage[bashing=" + Std.string(self.bashing)) + ", lethal=") + Std.string(self.lethal)) + ", aggravated=") + Std.string(self.aggravated)) + "]")

pw_tales_cofdsystem_damage_Damage._hx_class = pw_tales_cofdsystem_damage_Damage
_hx_classes["pw.tales.cofdsystem.damage.Damage"] = pw_tales_cofdsystem_damage_Damage


class pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_:
    _hx_class_name = "pw.tales.cofdsystem.damage._DamageType.DamageType_Impl_"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["BASHING", "LETHAL", "AGGRAVATED", "ORDER", "isMoreSevere"]

    @staticmethod
    def isMoreSevere(damageType,otherDamageType):
        return (python_internal_ArrayImpl.indexOf(pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_.ORDER,damageType,None) >= python_internal_ArrayImpl.indexOf(pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_.ORDER,otherDamageType,None))
pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_._hx_class = pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_
_hx_classes["pw.tales.cofdsystem.damage._DamageType.DamageType_Impl_"] = pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_


class pw_tales_cofdsystem_damage_DamageUtil:
    _hx_class_name = "pw.tales.cofdsystem.damage.DamageUtil"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["simpleAbsorb"]
    _hx_statics = ["INSTANCE"]

    def __init__(self):
        pass

    def simpleAbsorb(self,general,ballistic,damage,armor = None):
        if (armor is None):
            armor = True
        damage.applyBallisticArmor(ballistic)
        damage.applyGeneralArmor(general)
        if armor:
            damage.enusreBashing()
        return damage

pw_tales_cofdsystem_damage_DamageUtil._hx_class = pw_tales_cofdsystem_damage_DamageUtil
_hx_classes["pw.tales.cofdsystem.damage.DamageUtil"] = pw_tales_cofdsystem_damage_DamageUtil


class pw_tales_cofdsystem_dices_DiceRoller:
    _hx_class_name = "pw.tales.cofdsystem.dices.DiceRoller"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["d10", "rollChanceDice", "rollDices", "getRepeats", "defineResult", "rollDicePool", "roll"]

    def __init__(self):
        pass

    def d10(self):
        return (1 + int((python_lib_Random.random() * 10)))

    def rollChanceDice(self):
        diceResult = self.d10()
        result = pw_tales_cofdsystem_dices_EnumResult.FAILURE
        successes = 0
        if (diceResult == 1):
            result = pw_tales_cofdsystem_dices_EnumResult.DRAMATIC_FAILURE
        if (diceResult == 10):
            successes = 1
            result = pw_tales_cofdsystem_dices_EnumResult.SUCCESS
        return pw_tales_cofdsystem_dices_RollResponse(result,successes,0,[diceResult])

    def rollDices(self,poolSize):
        results = []
        _g = 0
        while (_g < poolSize):
            _g = (_g + 1)
            result = self.d10()
            results.append(result)
        return results

    def getRepeats(self,diceResults,permutation,stage):
        if (permutation == pw_tales_cofdsystem_dices_EnumExplode.NONE):
            return 0
        if (permutation == pw_tales_cofdsystem_dices_EnumExplode.ROTE_ACTION):
            if (stage > 0):
                return 0
            def _hx_local_1():
                def _hx_local_0(v):
                    return (v < 7)
                return len(list(filter(_hx_local_0,diceResults)))
            return _hx_local_1()
        def _hx_local_3():
            def _hx_local_2(v):
                return (v >= permutation.getExplode())
            return len(list(filter(_hx_local_2,diceResults)))
        return _hx_local_3()

    def defineResult(self,successes,threshold):
        if (successes >= threshold):
            return pw_tales_cofdsystem_dices_EnumResult.EXCEPTIONAL_SUCCESS
        if (successes >= 1):
            return pw_tales_cofdsystem_dices_EnumResult.SUCCESS
        return pw_tales_cofdsystem_dices_EnumResult.FAILURE

    def rollDicePool(self,poolRequest):
        permutation = poolRequest.getExplode()
        results = []
        toRoll = poolRequest.getPoolSize()
        stage = 0
        while (toRoll != 0):
            diceResults = self.rollDices(toRoll)
            toRoll1 = stage
            stage = (stage + 1)
            toRoll = self.getRepeats(diceResults,permutation,toRoll1)
            results = (results + diceResults)
        def _hx_local_0(v):
            return (v >= 8)
        successes = len(list(filter(_hx_local_0,results)))
        return pw_tales_cofdsystem_dices_RollResponse(self.defineResult(successes,poolRequest.getThreshold()),successes,poolRequest.getPoolSize(),results)

    def roll(self,request):
        if (request.getPoolSize() < 1):
            return self.rollChanceDice()
        return self.rollDicePool(request)

pw_tales_cofdsystem_dices_DiceRoller._hx_class = pw_tales_cofdsystem_dices_DiceRoller
_hx_classes["pw.tales.cofdsystem.dices.DiceRoller"] = pw_tales_cofdsystem_dices_DiceRoller


class pw_tales_cofdsystem_dices_EnumExplode:
    _hx_class_name = "pw.tales.cofdsystem.dices.EnumExplode"
    _hx_is_interface = "False"
    __slots__ = ("name", "explode")
    _hx_fields = ["name", "explode"]
    _hx_methods = ["next", "getName", "getExplode", "toString"]
    _hx_statics = ["KEY_VALUE", "VALUES", "NONE", "DEFAULT", "NINE_AGAIN", "EIGHT_AGAIN", "ROTE_ACTION", "findByName"]

    def __init__(self,name,explode = None):
        if (explode is None):
            explode = -1
        self.name = name
        self.explode = explode
        pw_tales_cofdsystem_dices_EnumExplode.KEY_VALUE.h[self.name] = self
        pw_tales_cofdsystem_dices_EnumExplode.VALUES.append(self)

    def next(self):
        i = (python_internal_ArrayImpl.indexOf(pw_tales_cofdsystem_dices_EnumExplode.VALUES,self,None) + 1)
        if (i >= len(pw_tales_cofdsystem_dices_EnumExplode.VALUES)):
            i = 0
        return python_internal_ArrayImpl._get(pw_tales_cofdsystem_dices_EnumExplode.VALUES, i)

    def getName(self):
        return self.name

    def getExplode(self):
        return self.explode

    def toString(self):
        return (((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[dn=") + HxOverrides.stringOrNull(self.name)) + "]")

    @staticmethod
    def findByName(name):
        return pw_tales_cofdsystem_dices_EnumExplode.KEY_VALUE.h.get(name,None)

pw_tales_cofdsystem_dices_EnumExplode._hx_class = pw_tales_cofdsystem_dices_EnumExplode
_hx_classes["pw.tales.cofdsystem.dices.EnumExplode"] = pw_tales_cofdsystem_dices_EnumExplode


class pw_tales_cofdsystem_dices_EnumResult:
    _hx_class_name = "pw.tales.cofdsystem.dices.EnumResult"
    _hx_is_interface = "False"
    __slots__ = ("name",)
    _hx_fields = ["name"]
    _hx_methods = ["getName", "toString"]
    _hx_statics = ["FAILURE", "DRAMATIC_FAILURE", "SUCCESS", "EXCEPTIONAL_SUCCESS", "isSuccess"]

    def __init__(self,name):
        self.name = name

    def getName(self):
        return self.name

    def toString(self):
        return (("EnumResult[" + HxOverrides.stringOrNull(self.name)) + "]")

    @staticmethod
    def isSuccess(result):
        if (result != pw_tales_cofdsystem_dices_EnumResult.SUCCESS):
            return (result == pw_tales_cofdsystem_dices_EnumResult.EXCEPTIONAL_SUCCESS)
        else:
            return True

pw_tales_cofdsystem_dices_EnumResult._hx_class = pw_tales_cofdsystem_dices_EnumResult
_hx_classes["pw.tales.cofdsystem.dices.EnumResult"] = pw_tales_cofdsystem_dices_EnumResult


class pw_tales_cofdsystem_dices_IRollRequest:
    _hx_class_name = "pw.tales.cofdsystem.dices.IRollRequest"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getThreshold", "getExplode", "getPoolSize"]
pw_tales_cofdsystem_dices_IRollRequest._hx_class = pw_tales_cofdsystem_dices_IRollRequest
_hx_classes["pw.tales.cofdsystem.dices.IRollRequest"] = pw_tales_cofdsystem_dices_IRollRequest


class pw_tales_cofdsystem_dices_RollRequest:
    _hx_class_name = "pw.tales.cofdsystem.dices.RollRequest"
    _hx_is_interface = "False"
    __slots__ = ("pool", "explode", "threshold")
    _hx_fields = ["pool", "explode", "threshold"]
    _hx_methods = ["getTraits", "addModifier", "setThreshold", "getThreshold", "setExplode", "getPoolSize", "getExplode"]
    _hx_interfaces = [pw_tales_cofdsystem_dices_IRollRequest]

    def __init__(self,pool):
        self.threshold = 5
        self.explode = pw_tales_cofdsystem_dices_EnumExplode.DEFAULT
        self.pool = pool

    def getTraits(self,gameObject):
        return []

    def addModifier(self,value,modDn = None,gameObject = None):
        pass

    def setThreshold(self,threshold):
        self.threshold = threshold

    def getThreshold(self):
        return self.threshold

    def setExplode(self,permutation):
        self.explode = permutation

    def getPoolSize(self):
        return self.pool.calculate()

    def getExplode(self):
        return self.explode

pw_tales_cofdsystem_dices_RollRequest._hx_class = pw_tales_cofdsystem_dices_RollRequest
_hx_classes["pw.tales.cofdsystem.dices.RollRequest"] = pw_tales_cofdsystem_dices_RollRequest


class pw_tales_cofdsystem_dices_RollResponse:
    _hx_class_name = "pw.tales.cofdsystem.dices.RollResponse"
    _hx_is_interface = "False"
    __slots__ = ("result", "successes", "poolSize", "results")
    _hx_fields = ["result", "successes", "poolSize", "results"]
    _hx_methods = ["setResult", "getResult", "setSuccesses", "getSuccesses", "getPoolSize", "getResults", "toString"]

    def __init__(self,result,successes,poolSize,results):
        self.result = result
        self.successes = successes
        self.poolSize = poolSize
        self.results = results

    def setResult(self,result):
        self.result = result

    def getResult(self):
        return self.result

    def setSuccesses(self,successes):
        self.successes = successes

    def getSuccesses(self):
        return self.successes

    def getPoolSize(self):
        return self.poolSize

    def getResults(self):
        return self.results

    def toString(self):
        return Std.string(_hx_AnonObject({'result': self.result, 'successes': self.successes, 'poolSize': self.poolSize, 'results': self.results}))

pw_tales_cofdsystem_dices_RollResponse._hx_class = pw_tales_cofdsystem_dices_RollResponse
_hx_classes["pw.tales.cofdsystem.dices.RollResponse"] = pw_tales_cofdsystem_dices_RollResponse


class pw_tales_cofdsystem_dices_pool_builder_PBSum(pw_tales_cofdsystem_dices_pool_builder_PBBinary):
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.builder.PBSum"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getHumanReadable"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_dices_pool_builder_PBBinary


    def __init__(self,operand1,operand2):
        def _hx_local_0(operand1,operand2):
            return pw_tales_cofdsystem_utils_math_MathSum(operand1,operand2)
        super().__init__(_hx_local_0,operand1,operand2)

    def getHumanReadable(self):
        return ((("" + HxOverrides.stringOrNull(self.operand1.getHumanReadable())) + " + ") + HxOverrides.stringOrNull(self.operand2.getHumanReadable()))

pw_tales_cofdsystem_dices_pool_builder_PBSum._hx_class = pw_tales_cofdsystem_dices_pool_builder_PBSum
_hx_classes["pw.tales.cofdsystem.dices.pool.builder.PBSum"] = pw_tales_cofdsystem_dices_pool_builder_PBSum


class pw_tales_cofdsystem_dices_pool_math_PoolTrait:
    _hx_class_name = "pw.tales.cofdsystem.dices.pool.math.PoolTrait"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "dn")
    _hx_fields = ["gameObject", "dn"]
    _hx_methods = ["getOperands", "calculate"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_math_IMathOperation]

    def __init__(self,gameObject,dn):
        self.gameObject = gameObject
        self.dn = dn

    def getOperands(self):
        return []

    def calculate(self):
        return self.gameObject.getTraitManager().getValue(self.dn)

pw_tales_cofdsystem_dices_pool_math_PoolTrait._hx_class = pw_tales_cofdsystem_dices_pool_math_PoolTrait
_hx_classes["pw.tales.cofdsystem.dices.pool.math.PoolTrait"] = pw_tales_cofdsystem_dices_pool_math_PoolTrait


class pw_tales_cofdsystem_dices_requests_ABSRollRequest:
    _hx_class_name = "pw.tales.cofdsystem.dices.requests.ABSRollRequest"
    _hx_is_interface = "False"
    __slots__ = ("explode", "threshold")
    _hx_fields = ["explode", "threshold"]
    _hx_methods = ["setThreshold", "getThreshold", "setExplode", "getPoolSize", "getExplode"]
    _hx_interfaces = [pw_tales_cofdsystem_dices_IRollRequest]

    def __init__(self):
        self.threshold = 5
        self.explode = pw_tales_cofdsystem_dices_EnumExplode.DEFAULT

    def setThreshold(self,threshold):
        self.threshold = threshold

    def getThreshold(self):
        return self.threshold

    def setExplode(self,permutation):
        self.explode = permutation

    def getPoolSize(self):
        raise haxe_Exception.thrown(thx_error_NotImplemented(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/dices/requests/ABSRollRequest.hx", 'lineNumber': 30, 'className': "pw.tales.cofdsystem.dices.requests.ABSRollRequest", 'methodName': "getPoolSize"})))

    def getExplode(self):
        return self.explode

pw_tales_cofdsystem_dices_requests_ABSRollRequest._hx_class = pw_tales_cofdsystem_dices_requests_ABSRollRequest
_hx_classes["pw.tales.cofdsystem.dices.requests.ABSRollRequest"] = pw_tales_cofdsystem_dices_requests_ABSRollRequest


class pw_tales_cofdsystem_dices_requests_RollRequestPool(pw_tales_cofdsystem_dices_requests_ABSRollRequest):
    _hx_class_name = "pw.tales.cofdsystem.dices.requests.RollRequestPool"
    _hx_is_interface = "False"
    __slots__ = ("poolSize",)
    _hx_fields = ["poolSize"]
    _hx_methods = ["getPoolSize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_dices_requests_ABSRollRequest


    def __init__(self,poolSize):
        self.poolSize = None
        super().__init__()
        self.poolSize = poolSize

    def getPoolSize(self):
        return self.poolSize

pw_tales_cofdsystem_dices_requests_RollRequestPool._hx_class = pw_tales_cofdsystem_dices_requests_RollRequestPool
_hx_classes["pw.tales.cofdsystem.dices.requests.RollRequestPool"] = pw_tales_cofdsystem_dices_requests_RollRequestPool


class pw_tales_cofdsystem_dices_requests_RollRequestTrait(pw_tales_cofdsystem_dices_requests_ABSRollRequest):
    _hx_class_name = "pw.tales.cofdsystem.dices.requests.RollRequestTrait"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "traits", "modifiers", "ignoreLimit")
    _hx_fields = ["gameObject", "traits", "modifiers", "ignoreLimit"]
    _hx_methods = ["getTraits", "setTraits", "buildPool", "addIgnoreLimit", "addModifier", "getAppliedModifiers", "processModifiers", "getPoolSize"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_dices_requests_ABSRollRequest


    def __init__(self,gameObject,traits):
        self.traits = None
        self.gameObject = None
        self.ignoreLimit = ["resist", "difficulty"]
        self.modifiers = haxe_ds_StringMap()
        super().__init__()
        self.gameObject = gameObject
        self.traits = traits

    def getTraits(self):
        return self.traits

    def setTraits(self,traits):
        self.traits = traits

    def buildPool(self):
        _gthis = self
        def _hx_local_2():
            def _hx_local_0(trait):
                return _gthis.gameObject.getTraitManager().getValue(trait)
            def _hx_local_1(a,b):
                return (a + b)
            return Lambda.fold(list(map(_hx_local_0,self.traits)),_hx_local_1,0)
        return _hx_local_2()

    def addIgnoreLimit(self,source):
        self.ignoreLimit.append(source)

    def addModifier(self,value,source):
        if (value == 0):
            return
        sourceModifiers = self.modifiers.h.get(source,None)
        if (sourceModifiers is not None):
            sourceModifiers.append(value)
        else:
            self.modifiers.h[source] = [value]

    def getAppliedModifiers(self):
        appliedModifiers = haxe_ds_StringMap()
        this1 = self.modifiers
        entry_keys = this1.keys()
        while entry_keys.hasNext():
            key = entry_keys.next()
            def _hx_local_0(a,b):
                return (a + b)
            sourceMod = Lambda.fold(this1.get(key),_hx_local_0,0)
            if (python_internal_ArrayImpl.indexOf(self.ignoreLimit,key,None) == -1):
                x = (sourceMod if (python_lib_Math.isnan(sourceMod)) else (-5 if (python_lib_Math.isnan(-5)) else max(sourceMod,-5)))
                try:
                    sourceMod = int(x)
                except BaseException as _g:
                    None
                    sourceMod = None
                x1 = (sourceMod if (python_lib_Math.isnan(sourceMod)) else (5 if (python_lib_Math.isnan(5)) else min(sourceMod,5)))
                try:
                    sourceMod = int(x1)
                except BaseException as _g1:
                    None
                    sourceMod = None
            appliedModifiers.h[key] = sourceMod
        return appliedModifiers

    def processModifiers(self):
        def _hx_local_1():
            def _hx_local_0(a,b):
                return (a + b)
            return Lambda.fold(self.getAppliedModifiers(),_hx_local_0,0)
        return _hx_local_1()

    def getPoolSize(self):
        mod = self.processModifiers()
        a = (self.buildPool() + mod)
        x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else max(a,0)))
        try:
            return int(x)
        except BaseException as _g:
            None
            return None

pw_tales_cofdsystem_dices_requests_RollRequestTrait._hx_class = pw_tales_cofdsystem_dices_requests_RollRequestTrait
_hx_classes["pw.tales.cofdsystem.dices.requests.RollRequestTrait"] = pw_tales_cofdsystem_dices_requests_RollRequestTrait


class pw_tales_cofdsystem_equipment_events_StrengthReqEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.equipment.events.StrengthReqEvent"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["getValue", "setValue"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject,value):
        self.value = None
        super().__init__(gameObject)
        self.value = value

    def getValue(self):
        return self.value

    def setValue(self,value):
        self.value = value

pw_tales_cofdsystem_equipment_events_StrengthReqEvent._hx_class = pw_tales_cofdsystem_equipment_events_StrengthReqEvent
_hx_classes["pw.tales.cofdsystem.equipment.events.StrengthReqEvent"] = pw_tales_cofdsystem_equipment_events_StrengthReqEvent


class pw_tales_cofdsystem_equipment_traits_EquipmentBonus(pw_tales_cofdsystem_equipment_traits_EquipmentMod):
    _hx_class_name = "pw.tales.cofdsystem.equipment.traits.EquipmentBonus"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_equipment_traits_EquipmentMod


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_equipment_traits_EquipmentBonus._hx_class = pw_tales_cofdsystem_equipment_traits_EquipmentBonus
_hx_classes["pw.tales.cofdsystem.equipment.traits.EquipmentBonus"] = pw_tales_cofdsystem_equipment_traits_EquipmentBonus


class pw_tales_cofdsystem_equipment_traits_Equippable(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.equipment.traits.Equippable"
    _hx_is_interface = "False"
    __slots__ = ("holder",)
    _hx_fields = ["holder"]
    _hx_methods = ["setHolder", "getHolder", "unset"]
    _hx_statics = ["DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.holder = None
        super().__init__(dn,gameObject,_hx_type)

    def setHolder(self,holder):
        self.holder = holder
        self.notifyUpdated()

    def getHolder(self):
        return self.holder

    def unset(self):
        self.holder = None
        self.notifyUpdated()

pw_tales_cofdsystem_equipment_traits_Equippable._hx_class = pw_tales_cofdsystem_equipment_traits_Equippable
_hx_classes["pw.tales.cofdsystem.equipment.traits.Equippable"] = pw_tales_cofdsystem_equipment_traits_Equippable


class pw_tales_cofdsystem_equipment_traits_HoldingHand(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.equipment.traits.HoldingHand"
    _hx_is_interface = "False"
    __slots__ = ("hand",)
    _hx_fields = ["hand"]
    _hx_methods = ["setHand", "getHand", "unset"]
    _hx_statics = ["DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject,_hx_type):
        self.hand = None
        super().__init__(dn,gameObject,_hx_type)

    def setHand(self,hand):
        self.hand = hand
        self.notifyUpdated()

    def getHand(self):
        return self.hand

    def unset(self):
        self.hand = None
        self.notifyUpdated()

pw_tales_cofdsystem_equipment_traits_HoldingHand._hx_class = pw_tales_cofdsystem_equipment_traits_HoldingHand
_hx_classes["pw.tales.cofdsystem.equipment.traits.HoldingHand"] = pw_tales_cofdsystem_equipment_traits_HoldingHand


class pw_tales_cofdsystem_equipment_traits_StrengthReq(pw_tales_cofdsystem_equipment_traits_EquipmentMod):
    _hx_class_name = "pw.tales.cofdsystem.equipment.traits.StrengthReq"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getModifiedValue", "applyMod"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_equipment_traits_EquipmentMod


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionPoolEvent,self.applyMod)

    def getModifiedValue(self):
        event = pw_tales_cofdsystem_equipment_events_StrengthReqEvent(self.gameObject,self.value)
        self.eventBus.post(event)
        return event.getValue()

    def applyMod(self,event):
        holder = self.getHolder()
        action = event.getAction()
        if (holder is None):
            return
        if (not event.isPoolOwner(holder)):
            return
        if (not Std.isOfType(action,pw_tales_cofdsystem_action_attack_AttackAction)):
            return
        strengthTrait = holder.getTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.STRENGTH)
        if (strengthTrait is None):
            return
        value = self.getModifiedValue()
        a = (strengthTrait.getValue() - value)
        x = (a if (python_lib_Math.isnan(a)) else (0 if (python_lib_Math.isnan(0)) else min(a,0)))
        mod = None
        try:
            mod = int(x)
        except BaseException as _g:
            None
            mod = None
        mod1 = (3 * mod)
        if (mod1 != 0):
            request = event.getActionPool().getRequest()
            request.addModifier(mod1,pw_tales_cofdsystem_equipment_traits_StrengthReq.DN)
            request.addIgnoreLimit(pw_tales_cofdsystem_equipment_traits_StrengthReq.DN)

pw_tales_cofdsystem_equipment_traits_StrengthReq._hx_class = pw_tales_cofdsystem_equipment_traits_StrengthReq
_hx_classes["pw.tales.cofdsystem.equipment.traits.StrengthReq"] = pw_tales_cofdsystem_equipment_traits_StrengthReq


class pw_tales_cofdsystem_game_object_GameObject:
    _hx_class_name = "pw.tales.cofdsystem.game_object.GameObject"
    _hx_is_interface = "False"
    __slots__ = ("dn", "system", "traitManager", "events", "state", "version")
    _hx_fields = ["dn", "system", "traitManager", "events", "state", "version"]
    _hx_methods = ["getDN", "getTraitManager", "getTrait", "getTraits", "getSystem", "getEventBus", "getState", "setState", "deactivate", "toString", "toData", "updateWithData"]
    _hx_statics = ["fromData"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_registry_IRecord]

    def __init__(self,dn,system):
        self.events = None
        self.traitManager = None
        self.system = None
        self.dn = None
        self.version = ""
        self.state = pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE
        _gthis = self
        self.dn = dn
        self.system = system
        self.traitManager = pw_tales_cofdsystem_game_object_trait_manager_TraitManager(self)
        def _hx_local_0(event):
            e = Std.downcast(event,pw_tales_cofdsystem_game_object_events_IGameObjectEvent)
            if (e is not None):
                return e.isRelated(_gthis)
            else:
                return False
        self.events = pw_tales_cofdsystem_utils_events_SubEventBus(system.events,_hx_local_0)

    def getDN(self):
        return self.dn

    def getTraitManager(self):
        return self.traitManager

    def getTrait(self,_hx_type,dn = None):
        return self.traitManager.getTrait(_hx_type,dn)

    def getTraits(self):
        return self.getTraitManager().getTraits().items()

    def getSystem(self):
        return self.system

    def getEventBus(self):
        return self.events

    def getState(self):
        return self.state

    def setState(self,state):
        self.state = state

    def deactivate(self):
        self.state = pw_tales_cofdsystem_game_object_GameObjectState.INACTIVE
        self.getTraitManager().deactivate()
        self.events.disable()

    def toString(self):
        return (((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[") + HxOverrides.stringOrNull(self.getDN())) + "]")

    def toData(self):
        return pw_tales_cofdsystem_synchronization_serialization_game_object_GameObjectSerialization(self.system).toData(self)

    def updateWithData(self,data):
        pw_tales_cofdsystem_synchronization_serialization_game_object_GameObjectSerialization(self.system).updateWithData(self,data)

    @staticmethod
    def fromData(system,data):
        return pw_tales_cofdsystem_synchronization_serialization_game_object_GameObjectSerialization(system).fromData(data)

pw_tales_cofdsystem_game_object_GameObject._hx_class = pw_tales_cofdsystem_game_object_GameObject
_hx_classes["pw.tales.cofdsystem.game_object.GameObject"] = pw_tales_cofdsystem_game_object_GameObject

class pw_tales_cofdsystem_game_object_GameObjectState(Enum):
    __slots__ = ()
    _hx_class_name = "pw.tales.cofdsystem.game_object.GameObjectState"
    _hx_constructs = ["ACTIVE", "LOADING", "INACTIVE"]
pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE = pw_tales_cofdsystem_game_object_GameObjectState("ACTIVE", 0, ())
pw_tales_cofdsystem_game_object_GameObjectState.LOADING = pw_tales_cofdsystem_game_object_GameObjectState("LOADING", 1, ())
pw_tales_cofdsystem_game_object_GameObjectState.INACTIVE = pw_tales_cofdsystem_game_object_GameObjectState("INACTIVE", 2, ())
pw_tales_cofdsystem_game_object_GameObjectState._hx_class = pw_tales_cofdsystem_game_object_GameObjectState
_hx_classes["pw.tales.cofdsystem.game_object.GameObjectState"] = pw_tales_cofdsystem_game_object_GameObjectState


class pw_tales_cofdsystem_game_object_TraitTracker:
    _hx_class_name = "pw.tales.cofdsystem.game_object.TraitTracker"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "events", "update", "remove")
    _hx_fields = ["gameObject", "events", "update", "remove"]
    _hx_methods = ["getGameObject", "trackChange", "trackRemove", "getUpdate", "getRemove", "hasChanges", "clear"]

    def __init__(self,gameObject):
        self.remove = pw_tales_cofdsystem_utils_registry_Registry(True,True)
        self.update = pw_tales_cofdsystem_utils_registry_Registry(True,True)
        self.gameObject = gameObject
        self.events = gameObject.getEventBus().createSubBus()
        self.events.addHandler(pw_tales_cofdsystem_game_object_events_traits_TraitPostAttachEvent,self.trackChange,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)
        self.events.addHandler(pw_tales_cofdsystem_game_object_events_traits_TraitPostUpdateEvent,self.trackChange,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)
        self.events.addHandler(pw_tales_cofdsystem_game_object_events_traits_TraitPostRemoveEvent,self.trackRemove,pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL)

    def getGameObject(self):
        return self.gameObject

    def trackChange(self,event):
        trait = event.getTrait()
        gameObject = trait.getGameObject()
        if (gameObject.getState() != pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE):
            return
        if trait.hasChanges():
            self.update.register(trait)
            self.remove.unregister(trait)
        else:
            self.update.unregister(trait)
        gameObject.getSystem().events.post(pw_tales_cofdsystem_game_object_events_tracker_TrackerTrackEvent(self))

    def trackRemove(self,event):
        trait = event.getTrait()
        gameObject = trait.getGameObject()
        if (gameObject.getState() != pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE):
            return
        if (not trait.isNew()):
            self.remove.register(trait)
        self.update.unregister(trait)
        gameObject.getSystem().events.post(pw_tales_cofdsystem_game_object_events_tracker_TrackerTrackEvent(self))

    def getUpdate(self):
        return self.update.items()

    def getRemove(self):
        return self.remove.items()

    def hasChanges(self):
        if (len(self.getUpdate()) <= 0):
            return (len(self.getRemove()) > 0)
        else:
            return True

    def clear(self):
        _g = 0
        _g1 = self.update.items()
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            trait = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            trait.acceptChanges()
        self.update.clear()
        self.remove.clear()
        self.gameObject.getSystem().events.post(pw_tales_cofdsystem_game_object_events_tracker_TrackerClearedEvent(self))

pw_tales_cofdsystem_game_object_TraitTracker._hx_class = pw_tales_cofdsystem_game_object_TraitTracker
_hx_classes["pw.tales.cofdsystem.game_object.TraitTracker"] = pw_tales_cofdsystem_game_object_TraitTracker


class pw_tales_cofdsystem_game_object_events_TraitAddEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.TraitAddEvent"
    _hx_is_interface = "False"
    __slots__ = ("traitType", "cancelled")
    _hx_fields = ["traitType", "cancelled"]
    _hx_methods = ["setCancelled", "isCancelled", "getTraitType"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject,trait):
        self.traitType = None
        self.cancelled = False
        super().__init__(gameObject)
        self.traitType = trait

    def setCancelled(self,cancelled):
        self.cancelled = cancelled

    def isCancelled(self):
        return self.cancelled

    def getTraitType(self):
        return self.traitType

pw_tales_cofdsystem_game_object_events_TraitAddEvent._hx_class = pw_tales_cofdsystem_game_object_events_TraitAddEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.TraitAddEvent"] = pw_tales_cofdsystem_game_object_events_TraitAddEvent


class pw_tales_cofdsystem_game_object_events_TraitRemoveEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.TraitRemoveEvent"
    _hx_is_interface = "False"
    __slots__ = ("trait", "cancelled")
    _hx_fields = ["trait", "cancelled"]
    _hx_methods = ["setCancelled", "isCancelled", "getTrait"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,trait):
        self.trait = None
        self.cancelled = False
        super().__init__(trait.getGameObject())
        self.trait = trait

    def setCancelled(self,cancelled):
        self.cancelled = cancelled

    def isCancelled(self):
        return self.cancelled

    def getTrait(self):
        return self.trait

pw_tales_cofdsystem_game_object_events_TraitRemoveEvent._hx_class = pw_tales_cofdsystem_game_object_events_TraitRemoveEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.TraitRemoveEvent"] = pw_tales_cofdsystem_game_object_events_TraitRemoveEvent


class pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.tracker.TrackerEvent"
    _hx_is_interface = "False"
    __slots__ = ("tracker",)
    _hx_fields = ["tracker"]
    _hx_methods = ["getTracker"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,tracker):
        self.tracker = None
        super().__init__(tracker.getGameObject())
        self.tracker = tracker

    def getTracker(self):
        return self.tracker

pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent._hx_class = pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.tracker.TrackerEvent"] = pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent


class pw_tales_cofdsystem_game_object_events_tracker_TrackerClearedEvent(pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.tracker.TrackerClearedEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent


    def __init__(self,tracker):
        super().__init__(tracker)
pw_tales_cofdsystem_game_object_events_tracker_TrackerClearedEvent._hx_class = pw_tales_cofdsystem_game_object_events_tracker_TrackerClearedEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.tracker.TrackerClearedEvent"] = pw_tales_cofdsystem_game_object_events_tracker_TrackerClearedEvent


class pw_tales_cofdsystem_game_object_events_tracker_TrackerTrackEvent(pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.tracker.TrackerTrackEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_tracker_TrackerEvent


    def __init__(self,tracker):
        super().__init__(tracker)
pw_tales_cofdsystem_game_object_events_tracker_TrackerTrackEvent._hx_class = pw_tales_cofdsystem_game_object_events_tracker_TrackerTrackEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.tracker.TrackerTrackEvent"] = pw_tales_cofdsystem_game_object_events_tracker_TrackerTrackEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitEvent"
    _hx_is_interface = "False"
    __slots__ = ("trait",)
    _hx_fields = ["trait"]
    _hx_methods = ["getTrait"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,trait):
        self.trait = None
        super().__init__(trait.getGameObject())
        self.trait = trait

    def getTrait(self):
        return self.trait

pw_tales_cofdsystem_game_object_events_traits_TraitEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent(pw_tales_cofdsystem_game_object_events_traits_TraitEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPreEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPreEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitCancellablePreEvent"
    _hx_is_interface = "False"
    __slots__ = ("cancelled",)
    _hx_fields = ["cancelled"]
    _hx_methods = ["setCancelled", "isCancelled"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent


    def __init__(self,trait):
        self.cancelled = False
        super().__init__(trait)

    def setCancelled(self,cancelled):
        self.cancelled = cancelled

    def isCancelled(self):
        return self.cancelled

pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitCancellablePreEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent(pw_tales_cofdsystem_game_object_events_traits_TraitEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPostEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPostEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPostChangeEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPostEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPostChangeEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPostAttachEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPostAttachEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPostAttachEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPostAttachEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPostAttachEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPostAttachEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPostDeserializeEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPostDeserializeEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPostDeserializeEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPostDeserializeEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPostDeserializeEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPostDeserializeEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPostRemoveEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPostRemoveEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPostRemoveEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPostRemoveEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPostRemoveEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPostRemoveEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPostUpdateEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPostUpdateEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPostChangeEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPostUpdateEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPostUpdateEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPostUpdateEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPostUpdateEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPreAttachEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPreAttachEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPreEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPreAttachEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPreAttachEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPreAttachEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPreAttachEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPreRemoveEvent(pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPreRemoveEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPreRemoveEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPreRemoveEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPreRemoveEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPreRemoveEvent


class pw_tales_cofdsystem_game_object_events_traits_TraitPreUpdateEvent(pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.events.traits.TraitPreUpdateEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitCancellablePreEvent


    def __init__(self,trait):
        super().__init__(trait)
pw_tales_cofdsystem_game_object_events_traits_TraitPreUpdateEvent._hx_class = pw_tales_cofdsystem_game_object_events_traits_TraitPreUpdateEvent
_hx_classes["pw.tales.cofdsystem.game_object.events.traits.TraitPreUpdateEvent"] = pw_tales_cofdsystem_game_object_events_traits_TraitPreUpdateEvent


class pw_tales_cofdsystem_game_object_health_helper_HealthTraitHelper:
    _hx_class_name = "pw.tales.cofdsystem.game_object.health_helper.HealthTraitHelper"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["get"]

    @staticmethod
    def get(gameObject):
        event = pw_tales_cofdsystem_game_object_health_helper_GetHealthTraitEvent(gameObject)
        gameObject.getEventBus().post(event)
        healthTrait = event.getHealthTrait()
        if (healthTrait is None):
            raise pw_tales_cofdsystem_game_object_health_helper_NoHealthTraitException(gameObject)
        return healthTrait
pw_tales_cofdsystem_game_object_health_helper_HealthTraitHelper._hx_class = pw_tales_cofdsystem_game_object_health_helper_HealthTraitHelper
_hx_classes["pw.tales.cofdsystem.game_object.health_helper.HealthTraitHelper"] = pw_tales_cofdsystem_game_object_health_helper_HealthTraitHelper


class pw_tales_cofdsystem_game_object_health_helper_NoHealthTraitException(pw_tales_cofdsystem_game_object_exceptions_GameObjectException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.health_helper.NoHealthTraitException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


    def __init__(self,gameObject):
        super().__init__(gameObject,(("" + Std.string(gameObject)) + " have no health trait."))
pw_tales_cofdsystem_game_object_health_helper_NoHealthTraitException._hx_class = pw_tales_cofdsystem_game_object_health_helper_NoHealthTraitException
_hx_classes["pw.tales.cofdsystem.game_object.health_helper.NoHealthTraitException"] = pw_tales_cofdsystem_game_object_health_helper_NoHealthTraitException


class pw_tales_cofdsystem_game_object_prefabs_AccessorException(pw_tales_cofdsystem_game_object_exceptions_GameObjectException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.prefabs.AccessorException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


    def __init__(self,gameObject,msg,previous = None):
        super().__init__(gameObject,msg,previous)
pw_tales_cofdsystem_game_object_prefabs_AccessorException._hx_class = pw_tales_cofdsystem_game_object_prefabs_AccessorException
_hx_classes["pw.tales.cofdsystem.game_object.prefabs.AccessorException"] = pw_tales_cofdsystem_game_object_prefabs_AccessorException


class pw_tales_cofdsystem_game_object_prefabs_exceptions_NoTraitAccessorException(pw_tales_cofdsystem_game_object_prefabs_AccessorException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.prefabs.exceptions.NoTraitAccessorException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_prefabs_AccessorException


    def __init__(self,gameObject,_hx_type):
        super().__init__(gameObject,((("" + Std.string(gameObject)) + " doesn't have any traits of type: ") + Std.string(_hx_type)))
pw_tales_cofdsystem_game_object_prefabs_exceptions_NoTraitAccessorException._hx_class = pw_tales_cofdsystem_game_object_prefabs_exceptions_NoTraitAccessorException
_hx_classes["pw.tales.cofdsystem.game_object.prefabs.exceptions.NoTraitAccessorException"] = pw_tales_cofdsystem_game_object_prefabs_exceptions_NoTraitAccessorException


class pw_tales_cofdsystem_game_object_trait_manager_TraitManager:
    _hx_class_name = "pw.tales.cofdsystem.game_object.trait_manager.TraitManager"
    _hx_is_interface = "False"
    __slots__ = ("system", "gameObject", "traits")
    _hx_fields = ["system", "gameObject", "traits"]
    _hx_methods = ["addTrait", "removeTrait", "getTrait", "getTraitByDn", "getValue", "getTraits", "deactivate", "toString"]

    def __init__(self,gameObject):
        self.traits = pw_tales_cofdsystem_utils_registry_Registry()
        self.gameObject = gameObject
        self.system = gameObject.getSystem()

    def addTrait(self,_hx_type,dn = None):
        if (not _hx_type.isMultiInstanced()):
            if (self.getTrait(_hx_type) is not None):
                raise pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitAddException(self.gameObject,_hx_type)
        if (not _hx_type.canAdd(self.gameObject)):
            raise pw_tales_cofdsystem_game_object_trait_manager_exceptions_CreationRejectedException(self.gameObject,_hx_type)
        trait = None
        if (dn is None):
            trait = _hx_type.create(self.gameObject)
        else:
            trait = _hx_type.createWithDN(dn,self.gameObject)
        self.system.events.post(pw_tales_cofdsystem_game_object_events_traits_TraitPreAttachEvent(trait))
        self.traits.register(trait)
        trait.onAttached()
        self.system.events.post(pw_tales_cofdsystem_game_object_events_traits_TraitPostAttachEvent(trait))
        return trait

    def removeTrait(self,trait):
        event = pw_tales_cofdsystem_game_object_events_TraitRemoveEvent(trait)
        self.system.events.post(event)
        if event.isCancelled():
            raise pw_tales_cofdsystem_game_object_trait_manager_exceptions_RemoveRejectedException(trait)
        self.system.events.post(pw_tales_cofdsystem_game_object_events_traits_TraitPreRemoveEvent(trait))
        self.traits.unregister(trait)
        trait.onRemoved()
        self.system.events.post(pw_tales_cofdsystem_game_object_events_traits_TraitPostRemoveEvent(trait))

    def getTrait(self,_hx_type,dn = None):
        if (dn is None):
            if _hx_type.isMultiInstanced():
                raise pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitFetchException(self.gameObject,_hx_type)
            dn = _hx_type.getDN()
        record = self.traits.getRecord(dn)
        if (record is None):
            return None
        if (record.getType() != _hx_type):
            raise pw_tales_cofdsystem_game_object_trait_manager_exceptions_WrongTypeException(self.gameObject,record,_hx_type)
        return record

    def getTraitByDn(self,dn):
        record = self.traits.getRecord(dn)
        if (record is None):
            return None
        return record

    def getValue(self,dn):
        record = self.traits.getRecord(dn)
        if (record is None):
            return 0
        return record.getValue()

    def getTraits(self):
        return self.traits

    def deactivate(self):
        _g = 0
        _g1 = self.traits.items()
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            trait = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            trait.onRemoved()

    def toString(self):
        return (((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[owner=") + HxOverrides.stringOrNull(self.gameObject.getDN())) + "]")

pw_tales_cofdsystem_game_object_trait_manager_TraitManager._hx_class = pw_tales_cofdsystem_game_object_trait_manager_TraitManager
_hx_classes["pw.tales.cofdsystem.game_object.trait_manager.TraitManager"] = pw_tales_cofdsystem_game_object_trait_manager_TraitManager


class pw_tales_cofdsystem_game_object_trait_manager_exceptions_CreationRejectedException(pw_tales_cofdsystem_game_object_exceptions_GameObjectException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.trait_manager.exceptions.CreationRejectedException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


    def __init__(self,gameObject,_hx_type):
        super().__init__(gameObject,(((("Attempt to create " + Std.string(_hx_type)) + " for ") + Std.string(gameObject)) + " is rejected."))
pw_tales_cofdsystem_game_object_trait_manager_exceptions_CreationRejectedException._hx_class = pw_tales_cofdsystem_game_object_trait_manager_exceptions_CreationRejectedException
_hx_classes["pw.tales.cofdsystem.game_object.trait_manager.exceptions.CreationRejectedException"] = pw_tales_cofdsystem_game_object_trait_manager_exceptions_CreationRejectedException


class pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitAddException(pw_tales_cofdsystem_game_object_exceptions_GameObjectException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.trait_manager.exceptions.MITraitAddException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


    def __init__(self,gameObject,_hx_type):
        super().__init__(gameObject,(("Attempting to add " + Std.string(_hx_type)) + " but it is not mutiinstanced and already exist."))
pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitAddException._hx_class = pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitAddException
_hx_classes["pw.tales.cofdsystem.game_object.trait_manager.exceptions.MITraitAddException"] = pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitAddException


class pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitFetchException(pw_tales_cofdsystem_game_object_exceptions_GameObjectException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.trait_manager.exceptions.MITraitFetchException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


    def __init__(self,gameObject,_hx_type):
        super().__init__(gameObject,(("Attempting to get " + Std.string(_hx_type)) + " but it is mutiinstanced and no dn is provided."))
pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitFetchException._hx_class = pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitFetchException
_hx_classes["pw.tales.cofdsystem.game_object.trait_manager.exceptions.MITraitFetchException"] = pw_tales_cofdsystem_game_object_trait_manager_exceptions_MITraitFetchException


class pw_tales_cofdsystem_game_object_trait_manager_exceptions_RemoveRejectedException(pw_tales_cofdsystem_game_object_exceptions_TraitException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.trait_manager.exceptions.RemoveRejectedException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_TraitException


    def __init__(self,trait):
        super().__init__(trait,(("Attempt to remove " + Std.string(trait)) + " is rejected."))
pw_tales_cofdsystem_game_object_trait_manager_exceptions_RemoveRejectedException._hx_class = pw_tales_cofdsystem_game_object_trait_manager_exceptions_RemoveRejectedException
_hx_classes["pw.tales.cofdsystem.game_object.trait_manager.exceptions.RemoveRejectedException"] = pw_tales_cofdsystem_game_object_trait_manager_exceptions_RemoveRejectedException


class pw_tales_cofdsystem_game_object_trait_manager_exceptions_WrongTypeException(pw_tales_cofdsystem_game_object_exceptions_GameObjectException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.trait_manager.exceptions.WrongTypeException"
    _hx_is_interface = "False"
    __slots__ = ("trait", "expected")
    _hx_fields = ["trait", "expected"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_GameObjectException


    def __init__(self,gameObject,trait,expected):
        self.expected = None
        self.trait = None
        super().__init__(gameObject,((((("Attempted to get " + Std.string(expected)) + " with dn ") + HxOverrides.stringOrNull(trait.getDN())) + " ") + ((((("but " + Std.string(trait)) + " has other type (") + Std.string(trait.getType())) + ")"))))
        self.trait = trait
        self.expected = expected

pw_tales_cofdsystem_game_object_trait_manager_exceptions_WrongTypeException._hx_class = pw_tales_cofdsystem_game_object_trait_manager_exceptions_WrongTypeException
_hx_classes["pw.tales.cofdsystem.game_object.trait_manager.exceptions.WrongTypeException"] = pw_tales_cofdsystem_game_object_trait_manager_exceptions_WrongTypeException

class pw_tales_cofdsystem_game_object_traits_TraitVersion(Enum):
    __slots__ = ()
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.TraitVersion"
    _hx_constructs = ["NEW", "VERSION"]

    @staticmethod
    def VERSION(data):
        return pw_tales_cofdsystem_game_object_traits_TraitVersion("VERSION", 1, (data,))
pw_tales_cofdsystem_game_object_traits_TraitVersion.NEW = pw_tales_cofdsystem_game_object_traits_TraitVersion("NEW", 0, ())
pw_tales_cofdsystem_game_object_traits_TraitVersion._hx_class = pw_tales_cofdsystem_game_object_traits_TraitVersion
_hx_classes["pw.tales.cofdsystem.game_object.traits.TraitVersion"] = pw_tales_cofdsystem_game_object_traits_TraitVersion


class pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownType"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isMultiInstanced", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,dn):
        super().__init__(dn)

    def isMultiInstanced(self):
        return True

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait(dn,gameObject)

pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownType._hx_class = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownType
_hx_classes["pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownType"] = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownType


class pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait(pw_tales_cofdsystem_game_object_traits_Trait):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownTrait"
    _hx_is_interface = "False"
    __slots__ = ("data",)
    _hx_fields = ["data"]
    _hx_methods = ["serialize", "deserialize"]
    _hx_statics = ["DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_Trait


    def __init__(self,dn,gameObject):
        self.data = _hx_AnonObject({})
        _gthis = self
        super().__init__(dn,gameObject,pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait.TYPE)
        def _hx_local_0(e):
            e.collect(_gthis)
        self.eventBus.addHandler(pw_tales_cofdsystem_game_object_traits_unknown_trait_events_UnknownTraitsCollectEvent,_hx_local_0)

    def serialize(self):
        return self.data

    def deserialize(self,data):
        self.data = data

pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait._hx_class = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait
_hx_classes["pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownTrait"] = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait


class pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTraits:
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownTraits"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["collect"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_game_object_traits_unknown_trait_events_UnknownTraitsCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTraits._hx_class = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTraits
_hx_classes["pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownTraits"] = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTraits


class pw_tales_cofdsystem_game_object_traits_unknown_trait_events_UnknownTraitsCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.unknown_trait.events.UnknownTraitsCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_game_object_traits_unknown_trait_events_UnknownTraitsCollectEvent._hx_class = pw_tales_cofdsystem_game_object_traits_unknown_trait_events_UnknownTraitsCollectEvent
_hx_classes["pw.tales.cofdsystem.game_object.traits.unknown_trait.events.UnknownTraitsCollectEvent"] = pw_tales_cofdsystem_game_object_traits_unknown_trait_events_UnknownTraitsCollectEvent


class pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent(pw_tales_cofdsystem_game_object_events_traits_TraitPreUpdateEvent):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.value_trait.events.ValueTraitUpdateEvent"
    _hx_is_interface = "False"
    __slots__ = ("newValue",)
    _hx_fields = ["newValue"]
    _hx_methods = ["getNewValue"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_traits_TraitPreUpdateEvent


    def __init__(self,trait,newValue):
        self.newValue = None
        super().__init__(trait)
        self.newValue = newValue

    def getNewValue(self):
        return self.newValue

pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent._hx_class = pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent
_hx_classes["pw.tales.cofdsystem.game_object.traits.value_trait.events.ValueTraitUpdateEvent"] = pw_tales_cofdsystem_game_object_traits_value_trait_events_ValueTraitUpdateEvent


class pw_tales_cofdsystem_game_object_traits_value_trait_exceptions_UpdateRejectedException(pw_tales_cofdsystem_game_object_exceptions_TraitException):
    _hx_class_name = "pw.tales.cofdsystem.game_object.traits.value_trait.exceptions.UpdateRejectedException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_exceptions_TraitException


    def __init__(self,trait,value):
        super().__init__(trait,(((("Attempt to set " + Std.string(trait)) + " to ") + Std.string(value)) + " is rejected."))
pw_tales_cofdsystem_game_object_traits_value_trait_exceptions_UpdateRejectedException._hx_class = pw_tales_cofdsystem_game_object_traits_value_trait_exceptions_UpdateRejectedException
_hx_classes["pw.tales.cofdsystem.game_object.traits.value_trait.exceptions.UpdateRejectedException"] = pw_tales_cofdsystem_game_object_traits_value_trait_exceptions_UpdateRejectedException


class pw_tales_cofdsystem_parser_ParserHelper(parsihax_Parser):
    _hx_class_name = "pw.tales.cofdsystem.parser.ParserHelper"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["find", "inBondaries", "takeWhileNo"]
    _hx_interfaces = []
    _hx_super = parsihax_Parser


    @staticmethod
    def find(parser,stream,i):
        _g = i
        _g1 = len(stream)
        while (_g < _g1):
            v = _g
            _g = (_g + 1)
            if parser[0](stream,v).status:
                return _hx_AnonObject({'status': True, 'index': v, 'furthest': None})
        return _hx_AnonObject({'status': False, 'index': None, 'furthest': i})

    @staticmethod
    def inBondaries(parser,endTerm):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            toProcess = stream
            end = pw_tales_cofdsystem_parser_ParserHelper.find(endTerm,stream,i)
            if end.status:
                toProcess = HxString.substring(stream,0,end.index)
            return parser[0](toProcess,i)
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret

    @staticmethod
    def takeWhileNo(parser):
        def _hx_local_0(stream,i = None):
            if (i is None):
                i = 0
            end = pw_tales_cofdsystem_parser_ParserHelper.find(parser,stream,i)
            if end.status:
                return _hx_AnonObject({'status': True, 'index': end.index, 'value': HxString.substring(stream,i,end.index), 'furthest': -1, 'expected': []})
            return _hx_AnonObject({'status': False, 'index': -1, 'value': None, 'furthest': end.furthest, 'expected': [Std.string(parser)]})
        v = _hx_local_0
        ret = [None]*1
        ret[0] = v
        return ret
pw_tales_cofdsystem_parser_ParserHelper._hx_class = pw_tales_cofdsystem_parser_ParserHelper
_hx_classes["pw.tales.cofdsystem.parser.ParserHelper"] = pw_tales_cofdsystem_parser_ParserHelper


class pw_tales_cofdsystem_parser_exception_ParsingException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.parser.exception.ParsingException"
    _hx_is_interface = "False"
    __slots__ = ("error",)
    _hx_fields = ["error"]
    _hx_methods = ["getError"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,error):
        self.error = None
        super().__init__(error)
        self.error = error

    def getError(self):
        return self.error

pw_tales_cofdsystem_parser_exception_ParsingException._hx_class = pw_tales_cofdsystem_parser_exception_ParsingException
_hx_classes["pw.tales.cofdsystem.parser.exception.ParsingException"] = pw_tales_cofdsystem_parser_exception_ParsingException


class pw_tales_cofdsystem_parser_nodes_INode:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.INode"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getHumanReadable"]
pw_tales_cofdsystem_parser_nodes_INode._hx_class = pw_tales_cofdsystem_parser_nodes_INode
_hx_classes["pw.tales.cofdsystem.parser.nodes.INode"] = pw_tales_cofdsystem_parser_nodes_INode


class pw_tales_cofdsystem_parser_nodes_INodeCheck:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.INodeCheck"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["build"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INode]
pw_tales_cofdsystem_parser_nodes_INodeCheck._hx_class = pw_tales_cofdsystem_parser_nodes_INodeCheck
_hx_classes["pw.tales.cofdsystem.parser.nodes.INodeCheck"] = pw_tales_cofdsystem_parser_nodes_INodeCheck


class pw_tales_cofdsystem_parser_nodes_INodeLevels:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.INodeLevels"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getLevels"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INode]
pw_tales_cofdsystem_parser_nodes_INodeLevels._hx_class = pw_tales_cofdsystem_parser_nodes_INodeLevels
_hx_classes["pw.tales.cofdsystem.parser.nodes.INodeLevels"] = pw_tales_cofdsystem_parser_nodes_INodeLevels


class pw_tales_cofdsystem_parser_nodes_INodePoolBuilder:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.INodePoolBuilder"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["build"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INode]
pw_tales_cofdsystem_parser_nodes_INodePoolBuilder._hx_class = pw_tales_cofdsystem_parser_nodes_INodePoolBuilder
_hx_classes["pw.tales.cofdsystem.parser.nodes.INodePoolBuilder"] = pw_tales_cofdsystem_parser_nodes_INodePoolBuilder


class pw_tales_cofdsystem_parser_nodes_NodeAnd:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeAnd"
    _hx_is_interface = "False"
    __slots__ = ("node1", "node2", "separator")
    _hx_fields = ["node1", "node2", "separator"]
    _hx_methods = ["getHumanReadable", "build", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeCheck]

    def __init__(self,node1,node2,separator = None):
        if (separator is None):
            separator = ", "
        self.node1 = node1
        self.node2 = node2
        self.separator = separator

    def getHumanReadable(self):
        return ((("" + HxOverrides.stringOrNull(self.node1.getHumanReadable())) + HxOverrides.stringOrNull(self.separator)) + HxOverrides.stringOrNull(self.node2.getHumanReadable()))

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathAnd(self.node1.build(gameObject),self.node2.build(gameObject))

    def toString(self):
        return (((("NodeAnd[" + Std.string(self.node1)) + ",") + Std.string(self.node2)) + "]")

pw_tales_cofdsystem_parser_nodes_NodeAnd._hx_class = pw_tales_cofdsystem_parser_nodes_NodeAnd
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeAnd"] = pw_tales_cofdsystem_parser_nodes_NodeAnd


class pw_tales_cofdsystem_parser_nodes_NodeNumber:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeNumber"
    _hx_is_interface = "False"
    __slots__ = ("number",)
    _hx_fields = ["number"]
    _hx_methods = ["getHumanReadable", "getValue", "build", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodePoolBuilder]

    def __init__(self,number):
        self.number = number

    def getHumanReadable(self):
        return Std.string(self.number)

    def getValue(self):
        return self.number

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathValue(self.number)

    def toString(self):
        return (("NodeNumber[" + Std.string(self.number)) + "]")

pw_tales_cofdsystem_parser_nodes_NodeNumber._hx_class = pw_tales_cofdsystem_parser_nodes_NodeNumber
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeNumber"] = pw_tales_cofdsystem_parser_nodes_NodeNumber


class pw_tales_cofdsystem_parser_nodes_NodeDots(pw_tales_cofdsystem_parser_nodes_NodeNumber):
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeDots"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getHumanReadable", "getLevels", "toString"]
    _hx_statics = []
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeLevels]
    _hx_super = pw_tales_cofdsystem_parser_nodes_NodeNumber


    def __init__(self,number):
        super().__init__(number)

    def getHumanReadable(self):
        _g = []
        _g1 = 0
        _g2 = self.number
        while (_g1 < _g2):
            _g1 = (_g1 + 1)
            _g.append("•")
        return "".join([python_Boot.toString1(x1,'') for x1 in _g])

    def getLevels(self):
        return [self.number]

    def toString(self):
        return (("NodeDots[" + Std.string(self.number)) + "]")

pw_tales_cofdsystem_parser_nodes_NodeDots._hx_class = pw_tales_cofdsystem_parser_nodes_NodeDots
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeDots"] = pw_tales_cofdsystem_parser_nodes_NodeDots


class pw_tales_cofdsystem_parser_nodes_NodeDotsOr:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeDotsOr"
    _hx_is_interface = "False"
    __slots__ = ("left", "right")
    _hx_fields = ["left", "right"]
    _hx_methods = ["getHumanReadable", "getLevels", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeLevels]

    def __init__(self,left,right):
        self.left = left
        self.right = right

    def getHumanReadable(self):
        return ((("" + HxOverrides.stringOrNull(self.left.getHumanReadable())) + " или ") + HxOverrides.stringOrNull(self.right.getHumanReadable()))

    def getLevels(self):
        return (self.left.getLevels() + self.right.getLevels())

    def toString(self):
        return (((("NodeDotsOr[" + Std.string(self.left)) + ",") + Std.string(self.right)) + "]")

pw_tales_cofdsystem_parser_nodes_NodeDotsOr._hx_class = pw_tales_cofdsystem_parser_nodes_NodeDotsOr
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeDotsOr"] = pw_tales_cofdsystem_parser_nodes_NodeDotsOr


class pw_tales_cofdsystem_parser_nodes_NodeDotsRange:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeDotsRange"
    _hx_is_interface = "False"
    __slots__ = ("start", "end")
    _hx_fields = ["start", "end"]
    _hx_methods = ["getHumanReadable", "getLevels", "toString"]
    _hx_statics = ["create"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeLevels]

    def __init__(self,start,end):
        self.start = start
        self.end = end

    def getHumanReadable(self):
        return ((("от " + HxOverrides.stringOrNull(self.start.getHumanReadable())) + " до ") + HxOverrides.stringOrNull(self.end.getHumanReadable()))

    def getLevels(self):
        _g = []
        _g1 = self.start.getValue()
        _g2 = (self.end.getValue() + 1)
        while (_g1 < _g2):
            i = _g1
            _g1 = (_g1 + 1)
            _g.append(i)
        return _g

    def toString(self):
        return (((("NodeDotsRange[" + Std.string(self.start)) + ",") + Std.string(self.end)) + "}]")

    @staticmethod
    def create(start,end):
        return pw_tales_cofdsystem_parser_nodes_NodeDotsRange(pw_tales_cofdsystem_parser_nodes_NodeDots(start),pw_tales_cofdsystem_parser_nodes_NodeDots(end))

pw_tales_cofdsystem_parser_nodes_NodeDotsRange._hx_class = pw_tales_cofdsystem_parser_nodes_NodeDotsRange
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeDotsRange"] = pw_tales_cofdsystem_parser_nodes_NodeDotsRange


class pw_tales_cofdsystem_parser_nodes_NodeGroup:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeGroup"
    _hx_is_interface = "False"
    __slots__ = ("node",)
    _hx_fields = ["node"]
    _hx_methods = ["build", "getHumanReadable"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeCheck, pw_tales_cofdsystem_parser_nodes_INode]

    def __init__(self,node):
        self.node = node

    def build(self,gameObject):
        checkNode = pw_tales_cofdsystem_utils_Utility.downcast(self.node,pw_tales_cofdsystem_parser_nodes_INodeCheck)
        if (checkNode is None):
            return pw_tales_cofdsystem_utils_math_MathValue(True)
        return checkNode.build(gameObject)

    def getHumanReadable(self):
        return (("(" + HxOverrides.stringOrNull(self.node.getHumanReadable())) + ")")

pw_tales_cofdsystem_parser_nodes_NodeGroup._hx_class = pw_tales_cofdsystem_parser_nodes_NodeGroup
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeGroup"] = pw_tales_cofdsystem_parser_nodes_NodeGroup


class pw_tales_cofdsystem_parser_nodes_NodeInversion:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeInversion"
    _hx_is_interface = "False"
    __slots__ = ("operand",)
    _hx_fields = ["operand"]
    _hx_methods = ["build", "getHumanReadable"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodePoolBuilder]

    def __init__(self,operand):
        self.operand = operand

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathNegation(self.operand.build(gameObject))

    def getHumanReadable(self):
        return ("" + HxOverrides.stringOrNull(self.operand.getHumanReadable()))

pw_tales_cofdsystem_parser_nodes_NodeInversion._hx_class = pw_tales_cofdsystem_parser_nodes_NodeInversion
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeInversion"] = pw_tales_cofdsystem_parser_nodes_NodeInversion


class pw_tales_cofdsystem_parser_nodes_NodeOr:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeOr"
    _hx_is_interface = "False"
    __slots__ = ("node1", "node2", "separator")
    _hx_fields = ["node1", "node2", "separator"]
    _hx_methods = ["getHumanReadable", "build", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeCheck]

    def __init__(self,node1,node2,separator = None):
        if (separator is None):
            separator = " или "
        self.node1 = node1
        self.node2 = node2
        self.separator = separator

    def getHumanReadable(self):
        return ((("" + HxOverrides.stringOrNull(self.node1.getHumanReadable())) + HxOverrides.stringOrNull(self.separator)) + HxOverrides.stringOrNull(self.node2.getHumanReadable()))

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathOr(self.node1.build(gameObject),self.node2.build(gameObject))

    def toString(self):
        return (((("NodeOr[" + Std.string(self.node1)) + ",") + Std.string(self.node2)) + "]")

pw_tales_cofdsystem_parser_nodes_NodeOr._hx_class = pw_tales_cofdsystem_parser_nodes_NodeOr
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeOr"] = pw_tales_cofdsystem_parser_nodes_NodeOr


class pw_tales_cofdsystem_parser_nodes_NodePoolSum:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodePoolSum"
    _hx_is_interface = "False"
    __slots__ = ("left", "right")
    _hx_fields = ["left", "right"]
    _hx_methods = ["build", "getHumanReadable"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodePoolBuilder]

    def __init__(self,left,right):
        self.left = left
        self.right = right

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathSum(self.left.build(gameObject),self.right.build(gameObject))

    def getHumanReadable(self):
        return ((("" + HxOverrides.stringOrNull(self.left.getHumanReadable())) + " + ") + HxOverrides.stringOrNull(self.right.getHumanReadable()))

pw_tales_cofdsystem_parser_nodes_NodePoolSum._hx_class = pw_tales_cofdsystem_parser_nodes_NodePoolSum
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodePoolSum"] = pw_tales_cofdsystem_parser_nodes_NodePoolSum


class pw_tales_cofdsystem_parser_nodes_NodeString:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeString"
    _hx_is_interface = "False"
    __slots__ = ("string",)
    _hx_fields = ["string"]
    _hx_methods = ["build", "getHumanReadable", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeCheck]

    def __init__(self,string):
        self.string = string

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathValue(True)

    def getHumanReadable(self):
        return self.string

    def toString(self):
        return (("NodeString[\"" + HxOverrides.stringOrNull(self.string)) + "\"]")

pw_tales_cofdsystem_parser_nodes_NodeString._hx_class = pw_tales_cofdsystem_parser_nodes_NodeString
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeString"] = pw_tales_cofdsystem_parser_nodes_NodeString


class pw_tales_cofdsystem_parser_nodes_NodeTrait:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeTrait"
    _hx_is_interface = "False"
    __slots__ = ("dn",)
    _hx_fields = ["dn"]
    _hx_methods = ["getHumanReadable", "getValue", "build", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodePoolBuilder, pw_tales_cofdsystem_parser_nodes_INode]

    def __init__(self,dn):
        self.dn = dn

    def getHumanReadable(self):
        return (("[[" + HxOverrides.stringOrNull(self.dn)) + "]]")

    def getValue(self):
        return self.dn

    def build(self,gameObject):
        return pw_tales_cofdsystem_dices_pool_math_PoolTrait(gameObject,self.dn)

    def toString(self):
        return (("NodeTrait[" + HxOverrides.stringOrNull(self.dn)) + "]")

pw_tales_cofdsystem_parser_nodes_NodeTrait._hx_class = pw_tales_cofdsystem_parser_nodes_NodeTrait
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeTrait"] = pw_tales_cofdsystem_parser_nodes_NodeTrait


class pw_tales_cofdsystem_parser_nodes_NodeTraitRequirement:
    _hx_class_name = "pw.tales.cofdsystem.parser.nodes.NodeTraitRequirement"
    _hx_is_interface = "False"
    __slots__ = ("trait", "value")
    _hx_fields = ["trait", "value"]
    _hx_methods = ["getHumanReadable", "build", "toString"]
    _hx_interfaces = [pw_tales_cofdsystem_parser_nodes_INodeCheck]

    def __init__(self,trait,value):
        self.trait = trait
        self.value = value

    def getHumanReadable(self):
        return ((("" + HxOverrides.stringOrNull(self.trait.getHumanReadable())) + " ") + HxOverrides.stringOrNull(self.value.getHumanReadable()))

    def build(self,gameObject):
        return pw_tales_cofdsystem_utils_math_MathMore(pw_tales_cofdsystem_dices_pool_math_PoolTrait(gameObject,self.trait.getValue()),pw_tales_cofdsystem_utils_math_MathValue((self.value.getValue() - 1)))

    def toString(self):
        return (((("NodeTraitRequirement[trait=" + Std.string(self.trait)) + ",value=") + Std.string(self.value)) + "]")

pw_tales_cofdsystem_parser_nodes_NodeTraitRequirement._hx_class = pw_tales_cofdsystem_parser_nodes_NodeTraitRequirement
_hx_classes["pw.tales.cofdsystem.parser.nodes.NodeTraitRequirement"] = pw_tales_cofdsystem_parser_nodes_NodeTraitRequirement


class HxString:
    _hx_class_name = "HxString"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["split", "charCodeAt", "charAt", "lastIndexOf", "toUpperCase", "toLowerCase", "indexOf", "indexOfImpl", "toString", "substring", "substr"]

    @staticmethod
    def split(s,d):
        if (d == ""):
            return list(s)
        else:
            return s.split(d)

    @staticmethod
    def charCodeAt(s,index):
        if ((((s is None) or ((len(s) == 0))) or ((index < 0))) or ((index >= len(s)))):
            return None
        else:
            return ord(s[index])

    @staticmethod
    def charAt(s,index):
        if ((index < 0) or ((index >= len(s)))):
            return ""
        else:
            return s[index]

    @staticmethod
    def lastIndexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.rfind(_hx_str, 0, len(s))
        elif (_hx_str == ""):
            length = len(s)
            if (startIndex < 0):
                startIndex = (length + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            if (startIndex > length):
                return length
            else:
                return startIndex
        else:
            i = s.rfind(_hx_str, 0, (startIndex + 1))
            startLeft = (max(0,((startIndex + 1) - len(_hx_str))) if ((i == -1)) else (i + 1))
            check = s.find(_hx_str, startLeft, len(s))
            if ((check > i) and ((check <= startIndex))):
                return check
            else:
                return i

    @staticmethod
    def toUpperCase(s):
        return s.upper()

    @staticmethod
    def toLowerCase(s):
        return s.lower()

    @staticmethod
    def indexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.find(_hx_str)
        else:
            return HxString.indexOfImpl(s,_hx_str,startIndex)

    @staticmethod
    def indexOfImpl(s,_hx_str,startIndex):
        if (_hx_str == ""):
            length = len(s)
            if (startIndex < 0):
                startIndex = (length + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            if (startIndex > length):
                return length
            else:
                return startIndex
        return s.find(_hx_str, startIndex)

    @staticmethod
    def toString(s):
        return s

    @staticmethod
    def substring(s,startIndex,endIndex = None):
        if (startIndex < 0):
            startIndex = 0
        if (endIndex is None):
            return s[startIndex:]
        else:
            if (endIndex < 0):
                endIndex = 0
            if (endIndex < startIndex):
                return s[endIndex:startIndex]
            else:
                return s[startIndex:endIndex]

    @staticmethod
    def substr(s,startIndex,_hx_len = None):
        if (_hx_len is None):
            return s[startIndex:]
        else:
            if (_hx_len == 0):
                return ""
            if (startIndex < 0):
                startIndex = (len(s) + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            return s[startIndex:(startIndex + _hx_len)]
HxString._hx_class = HxString
_hx_classes["HxString"] = HxString


class python_Boot:
    _hx_class_name = "python.Boot"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["keywords", "toString1", "fields", "simpleField", "hasField", "field", "getInstanceFields", "getSuperClass", "getClassFields", "prefixLength", "unhandleKeywords"]

    @staticmethod
    def toString1(o,s):
        if (o is None):
            return "null"
        if isinstance(o,str):
            return o
        if (s is None):
            s = ""
        if (len(s) >= 5):
            return "<...>"
        if isinstance(o,bool):
            if o:
                return "true"
            else:
                return "false"
        if (isinstance(o,int) and (not isinstance(o,bool))):
            return str(o)
        if isinstance(o,float):
            try:
                if (o == int(o)):
                    return str(Math.floor((o + 0.5)))
                else:
                    return str(o)
            except BaseException as _g:
                None
                return str(o)
        if isinstance(o,list):
            o1 = o
            l = len(o1)
            st = "["
            s = (("null" if s is None else s) + "\t")
            _g = 0
            _g1 = l
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                prefix = ""
                if (i > 0):
                    prefix = ","
                st = (("null" if st is None else st) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1((o1[i] if i >= 0 and i < len(o1) else None),s))))))
            st = (("null" if st is None else st) + "]")
            return st
        try:
            if hasattr(o,"toString"):
                return o.toString()
        except BaseException as _g:
            None
        if hasattr(o,"__class__"):
            if isinstance(o,_hx_AnonObject):
                toStr = None
                try:
                    fields = python_Boot.fields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (("{ " + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " }")
                except BaseException as _g:
                    None
                    return "{ ... }"
                if (toStr is None):
                    return "{ ... }"
                else:
                    return toStr
            if isinstance(o,Enum):
                o1 = o
                l = len(o1.params)
                hasParams = (l > 0)
                if hasParams:
                    paramsStr = ""
                    _g = 0
                    _g1 = l
                    while (_g < _g1):
                        i = _g
                        _g = (_g + 1)
                        prefix = ""
                        if (i > 0):
                            prefix = ","
                        paramsStr = (("null" if paramsStr is None else paramsStr) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1(o1.params[i],s))))))
                    return (((HxOverrides.stringOrNull(o1.tag) + "(") + ("null" if paramsStr is None else paramsStr)) + ")")
                else:
                    return o1.tag
            if hasattr(o,"_hx_class_name"):
                if (o.__class__.__name__ != "type"):
                    fields = python_Boot.getInstanceFields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (((HxOverrides.stringOrNull(o._hx_class_name) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    return toStr
                else:
                    fields = python_Boot.getClassFields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (((("#" + HxOverrides.stringOrNull(o._hx_class_name)) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    return toStr
            if ((type(o) == type) and (o == str)):
                return "#String"
            if ((type(o) == type) and (o == list)):
                return "#Array"
            if callable(o):
                return "function"
            try:
                if hasattr(o,"__repr__"):
                    return o.__repr__()
            except BaseException as _g:
                None
            if hasattr(o,"__str__"):
                return o.__str__([])
            if hasattr(o,"__name__"):
                return o.__name__
            return "???"
        else:
            return str(o)

    @staticmethod
    def fields(o):
        a = []
        if (o is not None):
            if hasattr(o,"_hx_fields"):
                fields = o._hx_fields
                if (fields is not None):
                    return list(fields)
            if isinstance(o,_hx_AnonObject):
                d = o.__dict__
                keys = d.keys()
                handler = python_Boot.unhandleKeywords
                for k in keys:
                    if (k != '_hx_disable_getattr'):
                        a.append(handler(k))
            elif hasattr(o,"__dict__"):
                d = o.__dict__
                keys1 = d.keys()
                for k in keys1:
                    a.append(k)
        return a

    @staticmethod
    def simpleField(o,field):
        if (field is None):
            return None
        field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
        if hasattr(o,field1):
            return getattr(o,field1)
        else:
            return None

    @staticmethod
    def hasField(o,field):
        if isinstance(o,_hx_AnonObject):
            return o._hx_hasattr(field)
        return hasattr(o,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)))

    @staticmethod
    def field(o,field):
        if (field is None):
            return None
        if isinstance(o,str):
            _hx_local_0 = len(field)
            if (_hx_local_0 == 10):
                if (field == "charCodeAt"):
                    return python_internal_MethodClosure(o,HxString.charCodeAt)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 11):
                if (field == "lastIndexOf"):
                    return python_internal_MethodClosure(o,HxString.lastIndexOf)
                elif (field == "toLowerCase"):
                    return python_internal_MethodClosure(o,HxString.toLowerCase)
                elif (field == "toUpperCase"):
                    return python_internal_MethodClosure(o,HxString.toUpperCase)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 9):
                if (field == "substring"):
                    return python_internal_MethodClosure(o,HxString.substring)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 5):
                if (field == "split"):
                    return python_internal_MethodClosure(o,HxString.split)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 7):
                if (field == "indexOf"):
                    return python_internal_MethodClosure(o,HxString.indexOf)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 8):
                if (field == "toString"):
                    return python_internal_MethodClosure(o,HxString.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 6):
                if (field == "charAt"):
                    return python_internal_MethodClosure(o,HxString.charAt)
                elif (field == "length"):
                    return len(o)
                elif (field == "substr"):
                    return python_internal_MethodClosure(o,HxString.substr)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        elif isinstance(o,list):
            _hx_local_1 = len(field)
            if (_hx_local_1 == 11):
                if (field == "lastIndexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.lastIndexOf)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 4):
                if (field == "copy"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.copy)
                elif (field == "join"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.join)
                elif (field == "push"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.push)
                elif (field == "sort"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.sort)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 5):
                if (field == "shift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.shift)
                elif (field == "slice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.slice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 7):
                if (field == "indexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.indexOf)
                elif (field == "reverse"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.reverse)
                elif (field == "unshift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.unshift)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 3):
                if (field == "map"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.map)
                elif (field == "pop"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.pop)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 8):
                if (field == "contains"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.contains)
                elif (field == "iterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.iterator)
                elif (field == "toString"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 16):
                if (field == "keyValueIterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.keyValueIterator)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 6):
                if (field == "concat"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.concat)
                elif (field == "filter"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.filter)
                elif (field == "insert"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.insert)
                elif (field == "length"):
                    return len(o)
                elif (field == "remove"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.remove)
                elif (field == "splice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.splice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        else:
            field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
            if hasattr(o,field1):
                return getattr(o,field1)
            else:
                return None

    @staticmethod
    def getInstanceFields(c):
        f = (list(c._hx_fields) if (hasattr(c,"_hx_fields")) else [])
        if hasattr(c,"_hx_methods"):
            f = (f + c._hx_methods)
        sc = python_Boot.getSuperClass(c)
        if (sc is None):
            return f
        else:
            scArr = python_Boot.getInstanceFields(sc)
            scMap = set(scArr)
            _g = 0
            while (_g < len(f)):
                f1 = (f[_g] if _g >= 0 and _g < len(f) else None)
                _g = (_g + 1)
                if (not (f1 in scMap)):
                    scArr.append(f1)
            return scArr

    @staticmethod
    def getSuperClass(c):
        if (c is None):
            return None
        try:
            if hasattr(c,"_hx_super"):
                return c._hx_super
            return None
        except BaseException as _g:
            None
        return None

    @staticmethod
    def getClassFields(c):
        if hasattr(c,"_hx_statics"):
            x = c._hx_statics
            return list(x)
        else:
            return []

    @staticmethod
    def unhandleKeywords(name):
        if (HxString.substr(name,0,python_Boot.prefixLength) == "_hx_"):
            real = HxString.substr(name,python_Boot.prefixLength,None)
            if (real in python_Boot.keywords):
                return real
        return name
python_Boot._hx_class = python_Boot
_hx_classes["python.Boot"] = python_Boot


class pw_tales_cofdsystem_parser_parsers_DotsLevelsParser:
    _hx_class_name = "pw.tales.cofdsystem.parser.parsers.DotsLevelsParser"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["parse"]
    _hx_statics = ["__meta__", "OR_LITERAL", "FROM_LITER", "TO_LITERAL", "NUMBER_LITERAL", "FULL_PARSER", "DOTS", "ARRAY1", "DOTS_RANGES", "ARRAY2", "DOTS_OR"]

    def __init__(self):
        pass

    def parse(self,data):
        result = pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.FULL_PARSER[0](data)
        if (not result.status):
            _this = result.expected
            raise haxe_Exception.thrown(("Parsing error: " + HxOverrides.stringOrNull(((("[" + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in _this]))) + "]")))))
        return result.value

pw_tales_cofdsystem_parser_parsers_DotsLevelsParser._hx_class = pw_tales_cofdsystem_parser_parsers_DotsLevelsParser
_hx_classes["pw.tales.cofdsystem.parser.parsers.DotsLevelsParser"] = pw_tales_cofdsystem_parser_parsers_DotsLevelsParser


class pw_tales_cofdsystem_parser_parsers_ParserPool:
    _hx_class_name = "pw.tales.cofdsystem.parser.parsers.ParserPool"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["parse"]
    _hx_statics = ["FULL_PARSER", "PLUS_LITERAL", "MINUS_LITERAL", "TRAIT", "NUMBER", "ARRAY2", "PLUS", "ARRAY3", "MINUS"]

    def __init__(self):
        pass

    def parse(self,data):
        result = pw_tales_cofdsystem_parser_parsers_ParserPool.FULL_PARSER[0](data)
        if (not result.status):
            _this = result.expected
            raise pw_tales_cofdsystem_parser_exception_ParsingException((("[" + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in _this]))) + "]"))
        return result.value

pw_tales_cofdsystem_parser_parsers_ParserPool._hx_class = pw_tales_cofdsystem_parser_parsers_ParserPool
_hx_classes["pw.tales.cofdsystem.parser.parsers.ParserPool"] = pw_tales_cofdsystem_parser_parsers_ParserPool


class pw_tales_cofdsystem_parser_parsers_RequirementsParser(parsihax_Parser):
    _hx_class_name = "pw.tales.cofdsystem.parser.parsers.RequirementsParser"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["parse"]
    _hx_statics = ["AND_LITERAL", "OR_LITERAL", "LB_GROUP", "RB_GROUP", "LB_STRING", "RB_STRING", "STATEMENT_END", "FULL_PARSER", "STATEMENT", "TRAIT_VALUE", "TRAIT_DN", "ARRAY1", "TRAIT_STATEMENT", "STRING_STATEMENT", "ARRAY2", "AND", "ARRAY3", "OR", "ARRAY4", "GROUP"]
    _hx_interfaces = []
    _hx_super = parsihax_Parser


    def __init__(self):
        pass

    def parse(self,data):
        result = pw_tales_cofdsystem_parser_parsers_RequirementsParser.FULL_PARSER[0](data)
        if (not result.status):
            raise haxe_Exception.thrown(parsihax_ParseUtil.formatError(result,data))
        return result.value

pw_tales_cofdsystem_parser_parsers_RequirementsParser._hx_class = pw_tales_cofdsystem_parser_parsers_RequirementsParser
_hx_classes["pw.tales.cofdsystem.parser.parsers.RequirementsParser"] = pw_tales_cofdsystem_parser_parsers_RequirementsParser


class pw_tales_cofdsystem_scene_Scene:
    _hx_class_name = "pw.tales.cofdsystem.scene.Scene"
    _hx_is_interface = "False"
    __slots__ = ("dn", "system", "initiative", "turns")
    _hx_fields = ["dn", "system", "initiative", "turns"]
    _hx_methods = ["setUp", "add", "remove", "getSystem", "getInitiative", "getTurns", "getDN", "begin", "end", "toString"]
    _hx_statics = ["create"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_registry_IRecord]

    def __init__(self,system):
        self.dn = thx_Uuid.create()
        self.system = system
        self.initiative = None
        self.turns = None

    def setUp(self):
        self.initiative = pw_tales_cofdsystem_scene_initiative_Initiative(self.system,self)
        self.turns = pw_tales_cofdsystem_scene_turns_Turns(self.system,self,self.initiative)
        return self

    def add(self,gameObject):
        self.initiative.add(gameObject)

    def remove(self,gameObject):
        self.initiative.remove(gameObject)
        self.turns.remove(gameObject)

    def getSystem(self):
        return self.system

    def getInitiative(self):
        return self.initiative

    def getTurns(self):
        return self.turns

    def getDN(self):
        return self.dn

    def begin(self):
        self.system.events.post(pw_tales_cofdsystem_scene_events_SceneEvent.START(self))

    def end(self):
        self.system.events.post(pw_tales_cofdsystem_scene_events_SceneEvent.END(self))

    def toString(self):
        return (((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[") + HxOverrides.stringOrNull(self.dn)) + "}]")

    @staticmethod
    def create(system):
        return pw_tales_cofdsystem_scene_Scene(system).setUp()

pw_tales_cofdsystem_scene_Scene._hx_class = pw_tales_cofdsystem_scene_Scene
_hx_classes["pw.tales.cofdsystem.scene.Scene"] = pw_tales_cofdsystem_scene_Scene


class pw_tales_cofdsystem_scene_events_SceneStartEvent(pw_tales_cofdsystem_scene_events_SceneEvent):
    _hx_class_name = "pw.tales.cofdsystem.scene.events.SceneStartEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_events_SceneEvent


    def __init__(self,scene):
        super().__init__(scene)
pw_tales_cofdsystem_scene_events_SceneStartEvent._hx_class = pw_tales_cofdsystem_scene_events_SceneStartEvent
_hx_classes["pw.tales.cofdsystem.scene.events.SceneStartEvent"] = pw_tales_cofdsystem_scene_events_SceneStartEvent


class pw_tales_cofdsystem_scene_initiative_Initiative:
    _hx_class_name = "pw.tales.cofdsystem.scene.initiative.Initiative"
    _hx_is_interface = "False"
    __slots__ = ("system", "scene", "order", "rollResults")
    _hx_fields = ["system", "scene", "order", "rollResults"]
    _hx_methods = ["getOrder", "getInitiative", "add", "remove", "update"]

    def __init__(self,system,scene):
        self.rollResults = haxe_ds_ObjectMap()
        self.order = []
        self.scene = scene
        self.system = system

    def getOrder(self):
        return self.order

    def getInitiative(self,gameObject):
        rollResult = self.rollResults.h.get(gameObject,None)
        if (rollResult is None):
            raise pw_tales_cofdsystem_scene_initiative_exceptions_ParticipantNotFoundException(gameObject.getDN())
        event = pw_tales_cofdsystem_scene_initiative_events_InitiativeModifiersEvent(gameObject,self)
        self.system.events.post(event)
        return (rollResult + event.getModifier())

    def add(self,gameObject):
        if (python_internal_ArrayImpl.indexOf(self.order,gameObject,None) != -1):
            raise pw_tales_cofdsystem_scene_initiative_exceptions_AddedAgainException(gameObject,self)
        self.order.append(gameObject)
        rollResult = self.system.dices.d10()
        self.rollResults.set(gameObject,rollResult)
        self.update()

    def remove(self,gameObject):
        python_internal_ArrayImpl.remove(self.order,gameObject)
        self.rollResults.remove(gameObject)
        self.update()

    def update(self):
        _gthis = self
        def _hx_local_0(a,b):
            initiativeA = _gthis.getInitiative(a)
            return (_gthis.getInitiative(b) - initiativeA)
        self.order.sort(key= python_lib_Functools.cmp_to_key(_hx_local_0))
        self.system.events.post(pw_tales_cofdsystem_scene_initiative_events_InitiativeUpdateEvent(self))

pw_tales_cofdsystem_scene_initiative_Initiative._hx_class = pw_tales_cofdsystem_scene_initiative_Initiative
_hx_classes["pw.tales.cofdsystem.scene.initiative.Initiative"] = pw_tales_cofdsystem_scene_initiative_Initiative


class pw_tales_cofdsystem_scene_initiative_events_InitiativeUpdateEvent(pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent):
    _hx_class_name = "pw.tales.cofdsystem.scene.initiative.events.InitiativeUpdateEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_initiative_events_InitiativeEvent


    def __init__(self,initiative):
        super().__init__(initiative)
pw_tales_cofdsystem_scene_initiative_events_InitiativeUpdateEvent._hx_class = pw_tales_cofdsystem_scene_initiative_events_InitiativeUpdateEvent
_hx_classes["pw.tales.cofdsystem.scene.initiative.events.InitiativeUpdateEvent"] = pw_tales_cofdsystem_scene_initiative_events_InitiativeUpdateEvent


class pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.scene.initiative.exceptions.InitiativeException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,message,previous = None,native = None):
        super().__init__(message,previous,native)
pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException._hx_class = pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException
_hx_classes["pw.tales.cofdsystem.scene.initiative.exceptions.InitiativeException"] = pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException


class pw_tales_cofdsystem_scene_initiative_exceptions_AddedAgainException(pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException):
    _hx_class_name = "pw.tales.cofdsystem.scene.initiative.exceptions.AddedAgainException"
    _hx_is_interface = "False"
    __slots__ = ("gameObject", "turnOrder")
    _hx_fields = ["gameObject", "turnOrder"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException


    def __init__(self,gameObject,initiative):
        self.turnOrder = None
        self.gameObject = None
        super().__init__((("" + Std.string(gameObject)) + " is already in initiative."))
        self.gameObject = gameObject
        self.turnOrder = initiative

pw_tales_cofdsystem_scene_initiative_exceptions_AddedAgainException._hx_class = pw_tales_cofdsystem_scene_initiative_exceptions_AddedAgainException
_hx_classes["pw.tales.cofdsystem.scene.initiative.exceptions.AddedAgainException"] = pw_tales_cofdsystem_scene_initiative_exceptions_AddedAgainException


class pw_tales_cofdsystem_scene_initiative_exceptions_ParticipantNotFoundException(pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException):
    _hx_class_name = "pw.tales.cofdsystem.scene.initiative.exceptions.ParticipantNotFoundException"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_initiative_exceptions_InitiativeException


    def __init__(self,dn):
        super().__init__((("" + ("null" if dn is None else dn)) + " is not found in initiative."))
pw_tales_cofdsystem_scene_initiative_exceptions_ParticipantNotFoundException._hx_class = pw_tales_cofdsystem_scene_initiative_exceptions_ParticipantNotFoundException
_hx_classes["pw.tales.cofdsystem.scene.initiative.exceptions.ParticipantNotFoundException"] = pw_tales_cofdsystem_scene_initiative_exceptions_ParticipantNotFoundException


class pw_tales_cofdsystem_scene_turns_Turns:
    _hx_class_name = "pw.tales.cofdsystem.scene.turns.Turns"
    _hx_is_interface = "False"
    __slots__ = ("system", "scene", "initiative", "turns")
    _hx_fields = ["system", "scene", "initiative", "turns"]
    _hx_methods = ["add", "remove", "nextRound", "start", "nextTurn", "getScene", "getTurn"]

    def __init__(self,system,scene,initiative):
        self.turns = []
        self.scene = scene
        self.system = system
        self.initiative = initiative

    def add(self,gameObject):
        self.turns.append(gameObject)

    def remove(self,gameObject):
        python_internal_ArrayImpl.remove(self.turns,gameObject)

    def nextRound(self):
        self.turns = list(self.initiative.getOrder())

    def start(self):
        self.nextTurn()

    def nextTurn(self):
        self.system.events.post(pw_tales_cofdsystem_scene_turns_events_TurnEvent.END(self,self.getTurn()))
        _this = self.turns
        if (len(_this) != 0):
            _this.pop(0)
        if (self.getTurn() is None):
            self.nextRound()
        self.system.events.post(pw_tales_cofdsystem_scene_turns_events_TurnEvent.START(self,self.getTurn()))

    def getScene(self):
        return self.scene

    def getTurn(self):
        return (self.turns[0] if 0 < len(self.turns) else None)

pw_tales_cofdsystem_scene_turns_Turns._hx_class = pw_tales_cofdsystem_scene_turns_Turns
_hx_classes["pw.tales.cofdsystem.scene.turns.Turns"] = pw_tales_cofdsystem_scene_turns_Turns


class pw_tales_cofdsystem_scene_turns_events_TurnsEvent:
    _hx_class_name = "pw.tales.cofdsystem.scene.turns.events.TurnsEvent"
    _hx_is_interface = "False"
    __slots__ = ("intitiative",)
    _hx_fields = ["intitiative"]
    _hx_methods = ["getInitiative"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_events_IEvent]

    def __init__(self,intitiative):
        self.intitiative = intitiative

    def getInitiative(self):
        return self.intitiative

pw_tales_cofdsystem_scene_turns_events_TurnsEvent._hx_class = pw_tales_cofdsystem_scene_turns_events_TurnsEvent
_hx_classes["pw.tales.cofdsystem.scene.turns.events.TurnsEvent"] = pw_tales_cofdsystem_scene_turns_events_TurnsEvent


class pw_tales_cofdsystem_scene_turns_events_TurnEvent(pw_tales_cofdsystem_scene_turns_events_TurnsEvent):
    _hx_class_name = "pw.tales.cofdsystem.scene.turns.events.TurnEvent"
    _hx_is_interface = "False"
    __slots__ = ("gameObject",)
    _hx_fields = ["gameObject"]
    _hx_methods = ["getCharacter", "isRelated"]
    _hx_statics = ["START", "END"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_turns_events_TurnsEvent


    def __init__(self,intitiative,gameObject):
        self.gameObject = None
        super().__init__(intitiative)
        self.gameObject = gameObject

    def getCharacter(self):
        return self.gameObject

    def isRelated(self,character):
        return (self.gameObject == self.gameObject)

    @staticmethod
    def START(intitiative,gameObject):
        return pw_tales_cofdsystem_scene_turns_events_TurnStartEvent(intitiative,gameObject)

    @staticmethod
    def END(intitiative,gameObject):
        return pw_tales_cofdsystem_scene_turns_events_TurnEndEvent(intitiative,gameObject)

pw_tales_cofdsystem_scene_turns_events_TurnEvent._hx_class = pw_tales_cofdsystem_scene_turns_events_TurnEvent
_hx_classes["pw.tales.cofdsystem.scene.turns.events.TurnEvent"] = pw_tales_cofdsystem_scene_turns_events_TurnEvent


class pw_tales_cofdsystem_scene_turns_events_TurnEndEvent(pw_tales_cofdsystem_scene_turns_events_TurnEvent):
    _hx_class_name = "pw.tales.cofdsystem.scene.turns.events.TurnEndEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_turns_events_TurnEvent


    def __init__(self,intitiative,gameObject):
        super().__init__(intitiative,gameObject)
pw_tales_cofdsystem_scene_turns_events_TurnEndEvent._hx_class = pw_tales_cofdsystem_scene_turns_events_TurnEndEvent
_hx_classes["pw.tales.cofdsystem.scene.turns.events.TurnEndEvent"] = pw_tales_cofdsystem_scene_turns_events_TurnEndEvent


class pw_tales_cofdsystem_scene_turns_events_TurnStartEvent(pw_tales_cofdsystem_scene_turns_events_TurnEvent):
    _hx_class_name = "pw.tales.cofdsystem.scene.turns.events.TurnStartEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_scene_turns_events_TurnEvent


    def __init__(self,intitiative,gameObject):
        super().__init__(intitiative,gameObject)
pw_tales_cofdsystem_scene_turns_events_TurnStartEvent._hx_class = pw_tales_cofdsystem_scene_turns_events_TurnStartEvent
_hx_classes["pw.tales.cofdsystem.scene.turns.events.TurnStartEvent"] = pw_tales_cofdsystem_scene_turns_events_TurnStartEvent


class pw_tales_cofdsystem_synchronization_api_APIStorage:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.api.APIStorage"
    _hx_is_interface = "False"
    _hx_methods = ["createHttp"]

    def createHttp(self,url):
        return sys_Http(url)

pw_tales_cofdsystem_synchronization_api_APIStorage._hx_class = pw_tales_cofdsystem_synchronization_api_APIStorage
_hx_classes["pw.tales.cofdsystem.synchronization.api.APIStorage"] = pw_tales_cofdsystem_synchronization_api_APIStorage


class pw_tales_cofdsystem_synchronization_api_GameObjectStorage(pw_tales_cofdsystem_synchronization_api_APIStorage):
    _hx_class_name = "pw.tales.cofdsystem.synchronization.api.GameObjectStorage"
    _hx_is_interface = "False"
    _hx_fields = ["host", "system", "clientToken", "serverToken"]
    _hx_methods = ["onGameObject", "onUpdated", "onError", "setClientToken", "setServerToken", "handleResponse", "addTokenToRequest", "prepareRequest", "create", "read", "update"]
    _hx_statics = ["GAME_OBJECT", "UPDATED", "ERROR", "createForClient", "createForServer"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_synchronization_api_APIStorage


    def __init__(self,host,system):
        self.serverToken = None
        self.clientToken = None
        self.host = host
        self.system = system

    def onGameObject(self,gameObject):
        pass

    def onUpdated(self,version):
        pass

    def onError(self,data,context):
        pass

    def setClientToken(self,token):
        self.clientToken = token

    def setServerToken(self,token):
        self.serverToken = token

    def handleResponse(self,serializedData,context):
        if (serializedData is None):
            raise haxe_Exception.thrown("No data")
        data = python_lib_Json.loads(serializedData,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        if (Reflect.field(data,"type") == pw_tales_cofdsystem_synchronization_api_GameObjectStorage.GAME_OBJECT):
            goData = Reflect.field(data,"game_object")
            gameObject = None
            if Reflect.field(context,"gameObject"):
                gameObject = Reflect.field(context,"gameObject")
                gameObject.updateWithData(goData)
            else:
                gameObject = pw_tales_cofdsystem_game_object_GameObject.fromData(self.system,goData)
            self.onGameObject(gameObject)
            return
        if (Reflect.field(data,"type") == pw_tales_cofdsystem_synchronization_api_GameObjectStorage.UPDATED):
            Reflect.field(context,"gameObject").version = Reflect.field(data,"version")
            self.onUpdated(Reflect.field(data,"version"))
            return
        self.onError(data,context)

    def addTokenToRequest(self,request):
        if (self.serverToken is not None):
            request.addHeader("Server-Token",self.serverToken)
            return
        if (self.clientToken is not None):
            request.addHeader("Client-Token",self.clientToken)
            return
        raise haxe_Exception.thrown("No server or client token set, use factory methods instead of constructor")

    def prepareRequest(self,url,context = None):
        _gthis = self
        if (context is None):
            context = _hx_AnonObject({})
        request = self.createHttp(url)
        request.addHeader("Content-Type","application/json")
        self.addTokenToRequest(request)
        def _hx_local_0(data):
            _gthis.handleResponse(data,context)
        request.onData = _hx_local_0
        def _hx_local_1(error):
            _gthis.handleResponse(request.get_responseData(),context)
        request.onError = _hx_local_1
        return request

    def create(self,dn,traitTypes = None):
        http = self.prepareRequest(((("" + HxOverrides.stringOrNull(self.host)) + "/game_objects/") + ("null" if dn is None else dn)),_hx_AnonObject({'dn': dn, 'traitTypes': traitTypes}))
        data = _hx_AnonObject({})
        if (traitTypes is not None):
            data = _hx_AnonObject({'traitTypes': traitTypes})
        http.setPostData(haxe_format_JsonPrinter.print(data,None,None))
        http.request(True)

    def read(self,dn):
        self.prepareRequest(((("" + HxOverrides.stringOrNull(self.host)) + "/game_objects/") + ("null" if dn is None else dn)),_hx_AnonObject({'dn': dn})).request()

    def update(self,gameObject,update = None,remove = None):
        if (update is None):
            update = []
        if (remove is None):
            remove = []
        http = self.prepareRequest((((("" + HxOverrides.stringOrNull(self.host)) + "/game_objects/") + HxOverrides.stringOrNull(gameObject.getDN())) + "/update"),_hx_AnonObject({'gameObject': gameObject}))
        gameObject1 = gameObject.version
        _g = []
        _g1 = 0
        while (_g1 < len(update)):
            def _hx_local_1():
                nonlocal _g1
                _hx_local_0 = _g1
                _g1 = (_g1 + 1)
                return _hx_local_0
            trait = python_internal_ArrayImpl._get(update, _hx_local_1())
            x = trait.serialize()
            _g.append(x)
        http.setPostData(haxe_format_JsonPrinter.print(_hx_AnonObject({'version': gameObject1, 'update': _g, 'remove': remove}),None,None))
        http.request(True)

    @staticmethod
    def createForClient(host,system,token):
        storage = pw_tales_cofdsystem_synchronization_api_GameObjectStorage(host,system)
        storage.setClientToken(token)
        return storage

    @staticmethod
    def createForServer(host,system,token):
        storage = pw_tales_cofdsystem_synchronization_api_GameObjectStorage(host,system)
        storage.setServerToken(token)
        return storage

pw_tales_cofdsystem_synchronization_api_GameObjectStorage._hx_class = pw_tales_cofdsystem_synchronization_api_GameObjectStorage
_hx_classes["pw.tales.cofdsystem.synchronization.api.GameObjectStorage"] = pw_tales_cofdsystem_synchronization_api_GameObjectStorage


class pw_tales_cofdsystem_synchronization_api_SystemStorage(pw_tales_cofdsystem_synchronization_api_APIStorage):
    _hx_class_name = "pw.tales.cofdsystem.synchronization.api.SystemStorage"
    _hx_is_interface = "False"
    _hx_fields = ["host"]
    _hx_methods = ["onSuccess", "handleResponse", "update"]
    _hx_statics = ["ROUTE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_synchronization_api_APIStorage


    def __init__(self,host):
        self.host = host

    def onSuccess(self):
        pass

    def handleResponse(self,system,serializedData):
        system.updateWithData(python_lib_Json.loads(serializedData,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon}))))
        self.onSuccess()

    def update(self,system):
        _gthis = self
        http = self.createHttp((("" + HxOverrides.stringOrNull(self.host)) + "/system"))
        def _hx_local_0(serializedData):
            _gthis.handleResponse(system,serializedData)
        http.onData = _hx_local_0
        def _hx_local_1(error):
            raise haxe_Exception.thrown(("HttpException " + ("null" if error is None else error)))
        http.onError = _hx_local_1
        http.request()

pw_tales_cofdsystem_synchronization_api_SystemStorage._hx_class = pw_tales_cofdsystem_synchronization_api_SystemStorage
_hx_classes["pw.tales.cofdsystem.synchronization.api.SystemStorage"] = pw_tales_cofdsystem_synchronization_api_SystemStorage


class pw_tales_cofdsystem_synchronization_serialization_Serialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.Serialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["createNewObj", "updateWithData", "fromData", "toData", "update", "deserialize", "serialize"]

    def createNewObj(self,data):
        raise haxe_Exception.thrown("Not Implemented")

    def updateWithData(self,obj,data):
        raise haxe_Exception.thrown("Not Implemented")

    def fromData(self,data):
        return self.updateWithData(self.createNewObj(data),data)

    def toData(self,obj):
        raise haxe_Exception.thrown("Not Implemented")

    def update(self,obj,serializedData):
        return self.updateWithData(obj,python_lib_Json.loads(serializedData,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon}))))

    def deserialize(self,serializedData):
        return self.fromData(python_lib_Json.loads(serializedData,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon}))))

    def serialize(self,obj):
        return haxe_format_JsonPrinter.print(self.toData(obj),None,None)

pw_tales_cofdsystem_synchronization_serialization_Serialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_Serialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.Serialization"] = pw_tales_cofdsystem_synchronization_serialization_Serialization


class pw_tales_cofdsystem_synchronization_serialization_game_object_GameObjectSerialization(pw_tales_cofdsystem_synchronization_serialization_Serialization):
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.game_object.GameObjectSerialization"
    _hx_is_interface = "False"
    __slots__ = ("system",)
    _hx_fields = ["system"]
    _hx_methods = ["ensureTrait", "getRemovedTraits", "createNewObj", "updateWithData", "toData"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_synchronization_serialization_Serialization


    def __init__(self,system):
        self.system = system

    def ensureTrait(self,manager,_hx_type,dn):
        trait = manager.getTrait(_hx_type,dn)
        if (trait is not None):
            return trait
        return manager.addTrait(_hx_type,dn)

    def getRemovedTraits(self,gameObject,data):
        oldTraits = gameObject.getTraitManager().getTraits().items()
        _g = []
        _g1 = 0
        _g2 = data.traits
        while (_g1 < len(_g2)):
            def _hx_local_1():
                nonlocal _g1
                _hx_local_0 = _g1
                _g1 = (_g1 + 1)
                return _hx_local_0
            trait = python_internal_ArrayImpl._get(_g2, _hx_local_1())
            x = Reflect.field(trait,"dn")
            _g.append(x)
        newDNs = _g
        def _hx_local_3():
            def _hx_local_2(v):
                return (not (v.getDN() in newDNs))
            return list(filter(_hx_local_2,oldTraits))
        return _hx_local_3()

    def createNewObj(self,data):
        return pw_tales_cofdsystem_game_object_GameObject(data.dn,self.system)

    def updateWithData(self,gameObject,data):
        gameObject.setState(pw_tales_cofdsystem_game_object_GameObjectState.LOADING)
        gameObject.version = data.version
        traits = data.traits
        manager = gameObject.getTraitManager()
        removedTraits = self.getRemovedTraits(gameObject,data)
        _g = 0
        while (_g < len(removedTraits)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            trait = python_internal_ArrayImpl._get(removedTraits, _hx_local_1())
            manager.removeTrait(trait)
        logger = pw_tales_cofdsystem_utils_logger_LoggerManager.getLogger()
        _g = 0
        while (_g < len(traits)):
            trait_data = (traits[_g] if _g >= 0 and _g < len(traits) else None)
            _g = (_g + 1)
            _hx_type = self.system.traits.getRecord(Reflect.field(trait_data,"type"))
            if (_hx_type is None):
                _hx_type = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait.TYPE
                logger.warning(((("Unable to identify trait type for data: " + HxOverrides.stringOrNull(haxe_format_JsonPrinter.print(trait_data,None,None))) + " fallback to ") + Std.string(_hx_type)))
            trait = self.ensureTrait(manager,_hx_type,Reflect.field(trait_data,"dn"))
            try:
                trait.deserialize(trait_data)
            except BaseException as _g1:
                _g2 = haxe_Exception.caught(_g1)
                if Std.isOfType(_g2,pw_tales_cofdsystem_utils_serialization_DeserializationException):
                    logger.warning((((((("Unable to create " + Std.string(trait.getType())) + " from data ") + HxOverrides.stringOrNull(haxe_format_JsonPrinter.print(trait_data,None,None))) + " because: ") + HxOverrides.stringOrNull(_g2.get_message())) + "."))
                    manager.removeTrait(trait)
                    trait = manager.addTrait(pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait.TYPE)
                    trait.deserialize(trait_data)
                else:
                    raise _g1
        gameObject.setState(pw_tales_cofdsystem_game_object_GameObjectState.ACTIVE)
        return gameObject

    def toData(self,gameObject):
        data = _hx_AnonObject({'version': gameObject.version, 'dn': gameObject.getDN(), 'traits': []})
        _g = 0
        _g1 = gameObject.getTraitManager().getTraits().items()
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            trait = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            _this = data.traits
            x = trait.serialize()
            _this.append(x)
        return data

pw_tales_cofdsystem_synchronization_serialization_game_object_GameObjectSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_game_object_GameObjectSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.game_object.GameObjectSerialization"] = pw_tales_cofdsystem_synchronization_serialization_game_object_GameObjectSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.IPartSerialization"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["update"]
pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.IPartSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_parts_AbilitySerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.parts.AbilitySerialization"
    _hx_is_interface = "False"
    __slots__ = ("requirementsParser", "levelsParser")
    _hx_fields = ["requirementsParser", "levelsParser"]
    _hx_methods = ["update"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization]

    def __init__(self):
        self.levelsParser = pw_tales_cofdsystem_parser_parsers_DotsLevelsParser()
        self.requirementsParser = pw_tales_cofdsystem_parser_parsers_RequirementsParser()

    def update(self,system,data):
        abilities = Reflect.field(data,"abilities")
        logger = pw_tales_cofdsystem_utils_logger_LoggerManager.getLogger()
        _g = 0
        _g1 = python_Boot.fields(abilities)
        while (_g < len(_g1)):
            dn = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            record = Reflect.field(abilities,dn)
            abilityType = system.traits.getRecord(dn)
            if (abilityType is None):
                abilityType = pw_tales_cofdsystem_character_traits_merits_MeritType(dn)
                system.traits.register(abilityType)
            if (record.name is not None):
                abilityType.setName(record.name)
            requirementsArray = record.requirements
            _g2 = 0
            while (_g2 < len(requirementsArray)):
                def _hx_local_2():
                    nonlocal _g2
                    _hx_local_1 = _g2
                    _g2 = (_g2 + 1)
                    return _hx_local_1
                requirementsRaw = python_internal_ArrayImpl._get(requirementsArray, _hx_local_2())
                abilityType.addRequirements(self.requirementsParser.parse(requirementsRaw))
            try:
                if (record.levels is not None):
                    abilityType.setLevels(self.levelsParser.parse(record.levels))
            except BaseException as _g3:
                _g4 = haxe_Exception.caught(_g3)
                if Std.isOfType(_g4,pw_tales_cofdsystem_parser_exception_ParsingException):
                    logger.warning(((("Error occured while parsing requitements for " + ("null" if dn is None else dn)) + ": ") + HxOverrides.stringOrNull(_g4.getError())))
                else:
                    raise _g3

pw_tales_cofdsystem_synchronization_serialization_system_parts_AbilitySerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_parts_AbilitySerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.parts.AbilitySerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_parts_AbilitySerialization


class pw_tales_cofdsystem_synchronization_serialization_system_parts_ConditionSerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.parts.ConditionSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["update"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization]

    def __init__(self):
        pass

    def update(self,system,data):
        conditions = Reflect.field(data,"conditions")
        _g = 0
        _g1 = python_Boot.fields(conditions)
        while (_g < len(_g1)):
            dn = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            record = Reflect.field(conditions,dn)
            _hx_type = system.traits.getRecord(dn)
            if (_hx_type is None):
                _hx_type = pw_tales_cofdsystem_game_object_traits_TraitType(dn)
                system.traits.register(_hx_type)
            _hx_type.setName(record.name)

pw_tales_cofdsystem_synchronization_serialization_system_parts_ConditionSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_parts_ConditionSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.parts.ConditionSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_parts_ConditionSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_parts_TiltSerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.parts.TiltSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["update"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization]

    def __init__(self):
        pass

    def update(self,system,data):
        tilts = Reflect.field(data,"tilts")
        _g = 0
        _g1 = python_Boot.fields(tilts)
        while (_g < len(_g1)):
            dn = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            record = Reflect.field(tilts,dn)
            _hx_type = system.traits.getRecord(dn)
            if (_hx_type is None):
                def _hx_local_1(dn,gameObject,_hx_type):
                    return pw_tales_cofdsystem_character_traits_tilts_Tilt(dn,gameObject,_hx_type)
                _hx_type = pw_tales_cofdsystem_game_object_traits_TraitType.createType(dn,_hx_local_1)
                system.traits.register(_hx_type)
            _hx_type.setName(record.name)

pw_tales_cofdsystem_synchronization_serialization_system_parts_TiltSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_parts_TiltSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.parts.TiltSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_parts_TiltSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_parts_ArmorSerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.parts.ArmorSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["update"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization]

    def __init__(self):
        pass

    def update(self,system,data):
        armors = Reflect.field(data,"armor")
        _g = 0
        _g1 = python_Boot.fields(armors)
        while (_g < len(_g1)):
            dn = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            record = Reflect.field(armors,dn)
            system.armors.register(pw_tales_cofdsystem_armor_prefabs_ArmorPrefab(record.name,record.ballistic_armor,record.general_armor,record.defense,record.speed,record.strength,dn))

pw_tales_cofdsystem_synchronization_serialization_system_parts_ArmorSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_parts_ArmorSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.parts.ArmorSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_parts_ArmorSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_parts_MeleeSerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.parts.MeleeSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["update"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization]

    def __init__(self):
        pass

    def update(self,system,data):
        melee_weapons = Reflect.field(data,"melee_weapons")
        _g = 0
        _g1 = python_Boot.fields(melee_weapons)
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            dn = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            record = Reflect.field(melee_weapons,dn)
            tags = []
            _g2 = 0
            _g3 = record.tags
            while (_g2 < len(_g3)):
                def _hx_local_3():
                    nonlocal _g2
                    _hx_local_2 = _g2
                    _g2 = (_g2 + 1)
                    return _hx_local_2
                tagDN = python_internal_ArrayImpl._get(_g3, _hx_local_3())
                tag = system.traits.getRecord(tagDN)
                if (tag is not None):
                    tags.append(tag)
            system.weapons.register(pw_tales_cofdsystem_weapon_melee_prefabs_MeleeWeaponPrefab(record.name,record.initiative,record.damage,record.strength,record.size,tags,record.dn))

pw_tales_cofdsystem_synchronization_serialization_system_parts_MeleeSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_parts_MeleeSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.parts.MeleeSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_parts_MeleeSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_parts_RangedSerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.parts.RangedSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["update"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization]

    def __init__(self):
        pass

    def update(self,system,data):
        rangedWeapons = Reflect.field(data,"ranged_weapons")
        _g = 0
        _g1 = python_Boot.fields(rangedWeapons)
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            dn = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            record = Reflect.field(rangedWeapons,dn)
            tags = []
            _g2 = 0
            _g3 = record.tags
            while (_g2 < len(_g3)):
                def _hx_local_3():
                    nonlocal _g2
                    _hx_local_2 = _g2
                    _g2 = (_g2 + 1)
                    return _hx_local_2
                tagDN = python_internal_ArrayImpl._get(_g3, _hx_local_3())
                tag = system.traits.getRecord(tagDN)
                if (tag is not None):
                    tags.append(tag)
            system.weapons.register(pw_tales_cofdsystem_weapon_ranged_prefabs_RangedWeaponPrefab(record.name,record.initiative,record.damage,Reflect.field(data,"strength"),record.size,tags,record.dn))

pw_tales_cofdsystem_synchronization_serialization_system_parts_RangedSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_parts_RangedSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.parts.RangedSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_parts_RangedSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_parts_TagSerialization:
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.parts.TagSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["update"]
    _hx_statics = ["INSTANCE"]
    _hx_interfaces = [pw_tales_cofdsystem_synchronization_serialization_system_IPartSerialization]

    def __init__(self):
        pass

    def update(self,system,data):
        weaponTag = Reflect.field(data,"weapon_tags")
        _g = 0
        _g1 = python_Boot.fields(weaponTag)
        while (_g < len(_g1)):
            dn = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            record = Reflect.field(weaponTag,dn)
            _hx_type = system.traits.getRecord(dn)
            if (_hx_type is None):
                _hx_type = pw_tales_cofdsystem_game_object_traits_TraitType(dn)
                system.traits.register(_hx_type)
            _hx_type.setName(record.name)

pw_tales_cofdsystem_synchronization_serialization_system_parts_TagSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_parts_TagSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.parts.TagSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_parts_TagSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization(pw_tales_cofdsystem_synchronization_serialization_Serialization):
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.SystemSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["createNewObj", "updateWithData", "toData"]
    _hx_statics = ["INSTANCE", "HANDLERS"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_synchronization_serialization_Serialization


    def __init__(self):
        pass

    def createNewObj(self,data):
        return pw_tales_cofdsystem_CofDSystem()

    def updateWithData(self,obj,data):
        remoteVersion = data.version
        if (pw_tales_cofdsystem_CofDSystem.VERSION_CHECK and ((remoteVersion != pw_tales_cofdsystem_CofDSystem.VERSION))):
            raise pw_tales_cofdsystem_synchronization_serialization_system_exceptions_VersionMissmatchException(pw_tales_cofdsystem_CofDSystem.VERSION,remoteVersion)
        _g = 0
        _g1 = pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization.HANDLERS
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            handler = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            handler.update(obj,data)
        return obj

    def toData(self,obj):
        raise haxe_Exception.thrown("Not Implemented")

pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.SystemSerialization"] = pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization


class pw_tales_cofdsystem_synchronization_serialization_system_exceptions_VersionMissmatchException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.synchronization.serialization.system.exceptions.VersionMissmatchException"
    _hx_is_interface = "False"
    __slots__ = ("currentVersion", "remoteVersion")
    _hx_fields = ["currentVersion", "remoteVersion"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,currentVersion,remoteVersion):
        self.remoteVersion = None
        self.currentVersion = None
        super().__init__((((("Version missmatch: " + ("null" if remoteVersion is None else remoteVersion)) + " (remote) != ") + ("null" if currentVersion is None else currentVersion)) + " (our)"))
        self.currentVersion = currentVersion
        self.remoteVersion = remoteVersion

pw_tales_cofdsystem_synchronization_serialization_system_exceptions_VersionMissmatchException._hx_class = pw_tales_cofdsystem_synchronization_serialization_system_exceptions_VersionMissmatchException
_hx_classes["pw.tales.cofdsystem.synchronization.serialization.system.exceptions.VersionMissmatchException"] = pw_tales_cofdsystem_synchronization_serialization_system_exceptions_VersionMissmatchException


class pw_tales_cofdsystem_utils_Utility:
    _hx_class_name = "pw.tales.cofdsystem.utils.Utility"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["values", "items", "sortedItems", "replace", "downcast", "getClassName"]

    @staticmethod
    def values(_hx_map):
        _g = []
        item = _hx_map.keyValueIterator()
        while item.hasNext():
            x = item.next().value
            _g.append(x)
        return _g

    @staticmethod
    def items(_hx_map):
        _g = []
        item = _hx_map.keyValueIterator()
        while item.hasNext():
            item1 = item.next()
            _g.append(item1)
        return _g

    @staticmethod
    def sortedItems(_hx_map):
        _g = []
        item = _hx_map.keyValueIterator()
        while item.hasNext():
            item1 = item.next()
            _g.append(item1)
        def _hx_local_0(a,b):
            return (b.value - a.value)
        _g.sort(key= python_lib_Functools.cmp_to_key(_hx_local_0))
        return _g

    @staticmethod
    def replace(array,value,replaceWith):
        _g = []
        _g1 = 0
        while (_g1 < len(array)):
            arrayValue = (array[_g1] if _g1 >= 0 and _g1 < len(array) else None)
            _g1 = (_g1 + 1)
            if HxOverrides.eq(arrayValue,value):
                _g.append(replaceWith)
            else:
                _g.append(arrayValue)
        return _g

    @staticmethod
    def downcast(value,c):
        return Std.downcast(value,c)

    @staticmethod
    def getClassName(clazz):
        parts = Type.getClassName(clazz).split(".")
        return python_internal_ArrayImpl._get(parts, (len(parts) - 1))
pw_tales_cofdsystem_utils_Utility._hx_class = pw_tales_cofdsystem_utils_Utility
_hx_classes["pw.tales.cofdsystem.utils.Utility"] = pw_tales_cofdsystem_utils_Utility


class pw_tales_cofdsystem_utils_events_EventBus:
    _hx_class_name = "pw.tales.cofdsystem.utils.events.EventBus"
    _hx_is_interface = "False"
    __slots__ = ("handlers",)
    _hx_fields = ["handlers"]
    _hx_methods = ["createSubBus", "post", "addHandler", "addHandlerRecord", "removeHandlerRecord"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_events_IEventBus]

    def __init__(self):
        self.handlers = []

    def createSubBus(self):
        return pw_tales_cofdsystem_utils_events_SubEventBus(self)

    def post(self,event):
        def _hx_local_0(value):
            return (pw_tales_cofdsystem_utils_Utility.downcast(event,value.type) is not None)
        filteredHandlers = list(filter(_hx_local_0,self.handlers))
        _g = 0
        while (_g < len(filteredHandlers)):
            def _hx_local_2():
                nonlocal _g
                _hx_local_1 = _g
                _g = (_g + 1)
                return _hx_local_1
            handler = python_internal_ArrayImpl._get(filteredHandlers, _hx_local_2())
            handler.handlerFunction(event)

    def addHandler(self,_hx_type,handler,priority = None):
        if (priority is None):
            priority = pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL
        record = pw_tales_cofdsystem_utils_events_EventHandlerRecord(_hx_type,handler,priority)
        self.addHandlerRecord(record)
        return record

    def addHandlerRecord(self,record):
        self.handlers.append(record)
        def _hx_local_0(a,b):
            return pw_tales_cofdsystem_utils_events_HandlerPriority.comparator(a.priority,b.priority)
        self.handlers.sort(key= python_lib_Functools.cmp_to_key(_hx_local_0))

    def removeHandlerRecord(self,record):
        python_internal_ArrayImpl.remove(self.handlers,record)

pw_tales_cofdsystem_utils_events_EventBus._hx_class = pw_tales_cofdsystem_utils_events_EventBus
_hx_classes["pw.tales.cofdsystem.utils.events.EventBus"] = pw_tales_cofdsystem_utils_events_EventBus


class pw_tales_cofdsystem_utils_events_EventHandlerRecord:
    _hx_class_name = "pw.tales.cofdsystem.utils.events.EventHandlerRecord"
    _hx_is_interface = "False"
    __slots__ = ("type", "handlerFunction", "priority")
    _hx_fields = ["type", "handlerFunction", "priority"]
    _hx_methods = ["toString"]

    def __init__(self,_hx_type,handlerFunction,priority):
        self.type = _hx_type
        self.handlerFunction = handlerFunction
        self.priority = priority

    def toString(self):
        return (((((("" + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(Type.getClass(self)))) + "[") + HxOverrides.stringOrNull(pw_tales_cofdsystem_utils_Utility.getClassName(self.type))) + ",") + Std.string(self.priority)) + "]")

pw_tales_cofdsystem_utils_events_EventHandlerRecord._hx_class = pw_tales_cofdsystem_utils_events_EventHandlerRecord
_hx_classes["pw.tales.cofdsystem.utils.events.EventHandlerRecord"] = pw_tales_cofdsystem_utils_events_EventHandlerRecord


class pw_tales_cofdsystem_utils_logger_ILogger:
    _hx_class_name = "pw.tales.cofdsystem.utils.logger.ILogger"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["info", "warning", "error"]
pw_tales_cofdsystem_utils_logger_ILogger._hx_class = pw_tales_cofdsystem_utils_logger_ILogger
_hx_classes["pw.tales.cofdsystem.utils.logger.ILogger"] = pw_tales_cofdsystem_utils_logger_ILogger


class pw_tales_cofdsystem_utils_logger_ABCLogger:
    _hx_class_name = "pw.tales.cofdsystem.utils.logger.ABCLogger"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["info", "warning", "error"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_logger_ILogger]

    def __init__(self):
        pass

    def info(self,text):
        raise haxe_Exception.thrown(thx_error_NotImplemented(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/utils/logger/ABCLogger.hx", 'lineNumber': 11, 'className': "pw.tales.cofdsystem.utils.logger.ABCLogger", 'methodName': "info"})))

    def warning(self,text):
        raise haxe_Exception.thrown(thx_error_NotImplemented(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/utils/logger/ABCLogger.hx", 'lineNumber': 14, 'className': "pw.tales.cofdsystem.utils.logger.ABCLogger", 'methodName': "warning"})))

    def error(self,text):
        raise haxe_Exception.thrown(thx_error_NotImplemented(_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/utils/logger/ABCLogger.hx", 'lineNumber': 17, 'className': "pw.tales.cofdsystem.utils.logger.ABCLogger", 'methodName': "error"})))

pw_tales_cofdsystem_utils_logger_ABCLogger._hx_class = pw_tales_cofdsystem_utils_logger_ABCLogger
_hx_classes["pw.tales.cofdsystem.utils.logger.ABCLogger"] = pw_tales_cofdsystem_utils_logger_ABCLogger


class pw_tales_cofdsystem_utils_logger_TraceLogger:
    _hx_class_name = "pw.tales.cofdsystem.utils.logger.TraceLogger"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_methods = ["info", "warning", "error"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_logger_ILogger]

    def __init__(self):
        pass

    def info(self,text):
        print(str(text))

    def warning(self,text):
        print(str(text))

    def error(self,text):
        print(str(text))

pw_tales_cofdsystem_utils_logger_TraceLogger._hx_class = pw_tales_cofdsystem_utils_logger_TraceLogger
_hx_classes["pw.tales.cofdsystem.utils.logger.TraceLogger"] = pw_tales_cofdsystem_utils_logger_TraceLogger


class pw_tales_cofdsystem_utils_logger_LoggerManager:
    _hx_class_name = "pw.tales.cofdsystem.utils.logger.LoggerManager"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["LOGGER", "getLogger", "setLogger"]

    @staticmethod
    def getLogger():
        return pw_tales_cofdsystem_utils_logger_LoggerManager.LOGGER

    @staticmethod
    def setLogger(logger):
        pw_tales_cofdsystem_utils_logger_LoggerManager.LOGGER = logger
pw_tales_cofdsystem_utils_logger_LoggerManager._hx_class = pw_tales_cofdsystem_utils_logger_LoggerManager
_hx_classes["pw.tales.cofdsystem.utils.logger.LoggerManager"] = pw_tales_cofdsystem_utils_logger_LoggerManager


class pw_tales_cofdsystem_utils_math_MathAnd(pw_tales_cofdsystem_utils_math_MathBinaryOperation):
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathAnd"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["calculate"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_math_MathBinaryOperation


    def __init__(self,operand1,operand2):
        super().__init__(operand1,operand2)

    def calculate(self):
        if self.operand1.calculate():
            return self.operand2.calculate()
        else:
            return False

pw_tales_cofdsystem_utils_math_MathAnd._hx_class = pw_tales_cofdsystem_utils_math_MathAnd
_hx_classes["pw.tales.cofdsystem.utils.math.MathAnd"] = pw_tales_cofdsystem_utils_math_MathAnd


class pw_tales_cofdsystem_utils_math_MathMax(pw_tales_cofdsystem_utils_math_MathBinaryOperation):
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathMax"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["calculate"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_math_MathBinaryOperation


    def __init__(self,operand1,operand2):
        super().__init__(operand1,operand2)

    def calculate(self):
        a = self.operand1.calculate()
        b = self.operand2.calculate()
        x = (a if (python_lib_Math.isnan(a)) else (b if (python_lib_Math.isnan(b)) else max(a,b)))
        try:
            return int(x)
        except BaseException as _g:
            None
            return None

pw_tales_cofdsystem_utils_math_MathMax._hx_class = pw_tales_cofdsystem_utils_math_MathMax
_hx_classes["pw.tales.cofdsystem.utils.math.MathMax"] = pw_tales_cofdsystem_utils_math_MathMax


class pw_tales_cofdsystem_utils_math_MathMore:
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathMore"
    _hx_is_interface = "False"
    __slots__ = ("operand1", "operand2")
    _hx_fields = ["operand1", "operand2"]
    _hx_methods = ["getOperands", "calculate"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_math_IMathOperation]

    def __init__(self,arg1,arg2):
        self.operand1 = arg1
        self.operand2 = arg2

    def getOperands(self):
        return [self.operand1, self.operand2]

    def calculate(self):
        return (self.operand1.calculate() > self.operand2.calculate())

pw_tales_cofdsystem_utils_math_MathMore._hx_class = pw_tales_cofdsystem_utils_math_MathMore
_hx_classes["pw.tales.cofdsystem.utils.math.MathMore"] = pw_tales_cofdsystem_utils_math_MathMore


class pw_tales_cofdsystem_utils_math_MathUnaryOperation:
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathUnaryOperation"
    _hx_is_interface = "False"
    __slots__ = ("operand",)
    _hx_fields = ["operand"]
    _hx_methods = ["getOperands", "calculate"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_math_IMathOperation]

    def __init__(self,operand):
        self.operand = operand

    def getOperands(self):
        return [self.operand]

    def calculate(self):
        raise haxe_Exception.thrown("Unimplemented")

pw_tales_cofdsystem_utils_math_MathUnaryOperation._hx_class = pw_tales_cofdsystem_utils_math_MathUnaryOperation
_hx_classes["pw.tales.cofdsystem.utils.math.MathUnaryOperation"] = pw_tales_cofdsystem_utils_math_MathUnaryOperation


class pw_tales_cofdsystem_utils_math_MathNegation(pw_tales_cofdsystem_utils_math_MathUnaryOperation):
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathNegation"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["calculate"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_math_MathUnaryOperation


    def __init__(self,operand):
        super().__init__(operand)

    def calculate(self):
        return -self.operand.calculate()

pw_tales_cofdsystem_utils_math_MathNegation._hx_class = pw_tales_cofdsystem_utils_math_MathNegation
_hx_classes["pw.tales.cofdsystem.utils.math.MathNegation"] = pw_tales_cofdsystem_utils_math_MathNegation


class pw_tales_cofdsystem_utils_math_MathOr(pw_tales_cofdsystem_utils_math_MathBinaryOperation):
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathOr"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["calculate"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_math_MathBinaryOperation


    def __init__(self,operand1,operand2):
        super().__init__(operand1,operand2)

    def calculate(self):
        if (not self.operand1.calculate()):
            return self.operand2.calculate()
        else:
            return True

pw_tales_cofdsystem_utils_math_MathOr._hx_class = pw_tales_cofdsystem_utils_math_MathOr
_hx_classes["pw.tales.cofdsystem.utils.math.MathOr"] = pw_tales_cofdsystem_utils_math_MathOr


class pw_tales_cofdsystem_utils_math_MathSubtraction(pw_tales_cofdsystem_utils_math_MathBinaryOperation):
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathSubtraction"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["calculate"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_math_MathBinaryOperation


    def __init__(self,operand1,operand2):
        super().__init__(operand1,operand2)

    def calculate(self):
        return (self.operand1.calculate() - self.operand2.calculate())

pw_tales_cofdsystem_utils_math_MathSubtraction._hx_class = pw_tales_cofdsystem_utils_math_MathSubtraction
_hx_classes["pw.tales.cofdsystem.utils.math.MathSubtraction"] = pw_tales_cofdsystem_utils_math_MathSubtraction


class pw_tales_cofdsystem_utils_math_MathSum(pw_tales_cofdsystem_utils_math_MathBinaryOperation):
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathSum"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["calculate"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_utils_math_MathBinaryOperation


    def __init__(self,operand1,operand2):
        super().__init__(operand1,operand2)

    def calculate(self):
        return (self.operand1.calculate() + self.operand2.calculate())

pw_tales_cofdsystem_utils_math_MathSum._hx_class = pw_tales_cofdsystem_utils_math_MathSum
_hx_classes["pw.tales.cofdsystem.utils.math.MathSum"] = pw_tales_cofdsystem_utils_math_MathSum


class pw_tales_cofdsystem_utils_math_MathValue:
    _hx_class_name = "pw.tales.cofdsystem.utils.math.MathValue"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["getValue", "setValue", "getOperands", "calculate"]
    _hx_interfaces = [pw_tales_cofdsystem_utils_math_IMathOperation]

    def __init__(self,value):
        self.value = value

    def getValue(self):
        return self.value

    def setValue(self,value):
        self.value = value

    def getOperands(self):
        return []

    def calculate(self):
        return self.value

pw_tales_cofdsystem_utils_math_MathValue._hx_class = pw_tales_cofdsystem_utils_math_MathValue
_hx_classes["pw.tales.cofdsystem.utils.math.MathValue"] = pw_tales_cofdsystem_utils_math_MathValue


class pw_tales_cofdsystem_utils_registry_exceptions_OverwriteForbiddenException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.utils.registry.exceptions.OverwriteForbiddenException"
    _hx_is_interface = "False"
    __slots__ = ("dn", "record", "newRecord")
    _hx_fields = ["dn", "record", "newRecord"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,dn,record,newRecord):
        self.newRecord = None
        self.record = None
        self.dn = None
        super().__init__((((("Attempted to overwrite " + Std.string(record)) + " with ") + Std.string(newRecord)) + ", which is forbidden."))
        self.dn = dn
        self.record = record
        self.newRecord = newRecord

pw_tales_cofdsystem_utils_registry_exceptions_OverwriteForbiddenException._hx_class = pw_tales_cofdsystem_utils_registry_exceptions_OverwriteForbiddenException
_hx_classes["pw.tales.cofdsystem.utils.registry.exceptions.OverwriteForbiddenException"] = pw_tales_cofdsystem_utils_registry_exceptions_OverwriteForbiddenException


class pw_tales_cofdsystem_utils_serialization_AnnotationSerialization:
    _hx_class_name = "pw.tales.cofdsystem.utils.serialization.AnnotationSerialization"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["SERIALIZE_ANNOTATION", "OPTIONAL_ANNOTATION", "apply", "gatherMetadata", "getSerializeKey", "parseAnnotations", "serialize", "deserialize"]

    @staticmethod
    def apply(base,ext):
        _g = 0
        _g1 = python_Boot.fields(ext)
        while (_g < len(_g1)):
            f = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            value = Reflect.field(ext,f)
            setattr(base,(("_hx_" + f) if ((f in python_Boot.keywords)) else (("_hx_" + f) if (((((len(f) > 2) and ((ord(f[0]) == 95))) and ((ord(f[1]) == 95))) and ((ord(f[(len(f) - 1)]) != 95)))) else f)),value)
        return base

    @staticmethod
    def gatherMetadata(o):
        clazz = Type.getClass(o)
        metadata = _hx_AnonObject({})
        while (clazz is not None):
            metadata = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.apply(metadata,haxe_rtti_Meta.getFields(clazz))
            clazz = Type.getSuperClass(clazz)
        return metadata

    @staticmethod
    def getSerializeKey(field,annotations):
        serializeKey = field
        args = Reflect.field(annotations,pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.SERIALIZE_ANNOTATION)
        if (len(args) > 0):
            serializeKey = (args[0] if 0 < len(args) else None)
        return serializeKey

    @staticmethod
    def parseAnnotations(field,annotations):
        if (not python_Boot.hasField(annotations,pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.SERIALIZE_ANNOTATION)):
            return None
        return _hx_AnonObject({'serializeKey': pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.getSerializeKey(field,annotations), 'optional': python_Boot.hasField(annotations,pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.OPTIONAL_ANNOTATION)})

    @staticmethod
    def serialize(object):
        metadata = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.gatherMetadata(object)
        access = object
        data = _hx_AnonObject({})
        _g_keys = python_Boot.fields(metadata)
        _g_index = 0
        while (_g_index < len(_g_keys)):
            key = _g_index
            _g_index = (_g_index + 1)
            key1 = (_g_keys[key] if key >= 0 and key < len(_g_keys) else None)
            options = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.parseAnnotations(key1,Reflect.field(metadata,key1))
            if (options is not None):
                serializeKey = options.serializeKey
                serialzeValue = Reflect.field(access,key1)
                setattr(data,(("_hx_" + serializeKey) if ((serializeKey in python_Boot.keywords)) else (("_hx_" + serializeKey) if (((((len(serializeKey) > 2) and ((ord(serializeKey[0]) == 95))) and ((ord(serializeKey[1]) == 95))) and ((ord(serializeKey[(len(serializeKey) - 1)]) != 95)))) else serializeKey)),serialzeValue)
        return data

    @staticmethod
    def deserialize(object,data):
        metadata = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.gatherMetadata(object)
        _g_keys = python_Boot.fields(metadata)
        _g_index = 0
        while (_g_index < len(_g_keys)):
            key = _g_index
            _g_index = (_g_index + 1)
            key1 = (_g_keys[key] if key >= 0 and key < len(_g_keys) else None)
            options = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.parseAnnotations(key1,Reflect.field(metadata,key1))
            if (options is None):
                continue
            serializeKey = options.serializeKey
            if python_Boot.hasField(data,serializeKey):
                value = Reflect.field(data,serializeKey)
                setattr(object,(("_hx_" + key1) if ((key1 in python_Boot.keywords)) else (("_hx_" + key1) if (((((len(key1) > 2) and ((ord(key1[0]) == 95))) and ((ord(key1[1]) == 95))) and ((ord(key1[(len(key1) - 1)]) != 95)))) else key1)),value)
            elif (not options.optional):
                raise pw_tales_cofdsystem_utils_serialization_DeserializationException(data,key1)
        return data
pw_tales_cofdsystem_utils_serialization_AnnotationSerialization._hx_class = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization
_hx_classes["pw.tales.cofdsystem.utils.serialization.AnnotationSerialization"] = pw_tales_cofdsystem_utils_serialization_AnnotationSerialization


class pw_tales_cofdsystem_utils_serialization_DeserializationException(pw_tales_cofdsystem_exceptions_CofDSystemException):
    _hx_class_name = "pw.tales.cofdsystem.utils.serialization.DeserializationException"
    _hx_is_interface = "False"
    __slots__ = ("data", "field")
    _hx_fields = ["data", "field"]
    _hx_methods = ["getData", "getField"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_exceptions_CofDSystemException


    def __init__(self,data,field):
        self.field = None
        self.data = None
        super().__init__((((("Field \"" + ("null" if field is None else field)) + "\" not found in ") + Std.string(data)) + "."))
        self.data = data
        self.field = field

    def getData(self):
        return self.data

    def getField(self):
        return self.field

pw_tales_cofdsystem_utils_serialization_DeserializationException._hx_class = pw_tales_cofdsystem_utils_serialization_DeserializationException
_hx_classes["pw.tales.cofdsystem.utils.serialization.DeserializationException"] = pw_tales_cofdsystem_utils_serialization_DeserializationException


class pw_tales_cofdsystem_weapon_IWeapon:
    _hx_class_name = "pw.tales.cofdsystem.weapon.IWeapon"
    _hx_is_interface = "True"
    __slots__ = ()
    _hx_methods = ["getInitiativeMod", "getDamageMod", "getWeaponTags"]
pw_tales_cofdsystem_weapon_IWeapon._hx_class = pw_tales_cofdsystem_weapon_IWeapon
_hx_classes["pw.tales.cofdsystem.weapon.IWeapon"] = pw_tales_cofdsystem_weapon_IWeapon


class pw_tales_cofdsystem_weapon_Weapon(pw_tales_cofdsystem_equipment_Equipment):
    _hx_class_name = "pw.tales.cofdsystem.weapon.Weapon"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getInitiativeMod", "getDamageMod", "getWeaponTags", "getHand", "unsetEquipper", "setEquipper", "ensureHoldingHand"]
    _hx_statics = []
    _hx_interfaces = [pw_tales_cofdsystem_weapon_IWeapon]
    _hx_super = pw_tales_cofdsystem_equipment_Equipment


    def __init__(self,gameObject):
        super().__init__(gameObject)

    def getInitiativeMod(self):
        return self.getInt(pw_tales_cofdsystem_weapon_traits_InitiativeMod.TYPE)

    def getDamageMod(self):
        return self.getInt(pw_tales_cofdsystem_weapon_traits_DamageMod.TYPE)

    def getWeaponTags(self):
        def _hx_local_1():
            def _hx_local_0(tag):
                return tag.getType()
            return list(map(_hx_local_0,pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTags.collect(self.gameObject)))
        return _hx_local_1()

    def getHand(self):
        try:
            return self.ensureHoldingHand().getHand()
        except BaseException as _g:
            return None

    def unsetEquipper(self):
        super().unsetHolder()
        try:
            self.ensureHoldingHand().unset()
        except BaseException as _g:
            pass

    def setEquipper(self,gameObject,hand):
        super().setHolder(gameObject)
        try:
            self.ensureHoldingHand().setHand(hand)
        except BaseException as _g:
            pass

    def ensureHoldingHand(self):
        return self.getTrait(pw_tales_cofdsystem_equipment_traits_HoldingHand.TYPE)

pw_tales_cofdsystem_weapon_Weapon._hx_class = pw_tales_cofdsystem_weapon_Weapon
_hx_classes["pw.tales.cofdsystem.weapon.Weapon"] = pw_tales_cofdsystem_weapon_Weapon


class pw_tales_cofdsystem_weapon_actions_PickAction(pw_tales_cofdsystem_action_NoRollAction):
    _hx_class_name = "pw.tales.cofdsystem.weapon.actions.PickAction"
    _hx_is_interface = "False"
    __slots__ = ("weapon", "hand")
    _hx_fields = ["weapon", "hand"]
    _hx_methods = ["perform"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_action_NoRollAction


    def __init__(self,actor,hand,weapon,system):
        self.hand = None
        self.weapon = None
        super().__init__(actor,pw_tales_cofdsystem_action_EnumTime.INSTANT,system)
        self.weapon = weapon
        self.hand = hand

    def perform(self):
        self.actor.getTrait(pw_tales_cofdsystem_character_traits_HeldWeapon.TYPE).setHand(self.hand,self.weapon)

pw_tales_cofdsystem_weapon_actions_PickAction._hx_class = pw_tales_cofdsystem_weapon_actions_PickAction
_hx_classes["pw.tales.cofdsystem.weapon.actions.PickAction"] = pw_tales_cofdsystem_weapon_actions_PickAction


class pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab(pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab):
    _hx_class_name = "pw.tales.cofdsystem.weapon.prefabs.WeaponPrefab"
    _hx_is_interface = "False"
    __slots__ = ("name", "initiative", "damage", "strength", "size", "tags")
    _hx_fields = ["name", "initiative", "damage", "strength", "size", "tags"]
    _hx_methods = ["getName", "getDisplayName", "getInitiativeMod", "getDamageMod", "getStrengthReq", "getSize", "getWeaponTags", "setUpGameObject", "createWeapon"]
    _hx_statics = []
    _hx_interfaces = [pw_tales_cofdsystem_weapon_IWeapon]
    _hx_super = pw_tales_cofdsystem_equipment_prefabs_EquipmentPrefab


    def __init__(self,name,initiative,damage,strength,size,tags,dn):
        self.tags = []
        self.size = 0
        self.strength = 0
        self.damage = 0
        self.initiative = 0
        self.name = None
        super().__init__(dn)
        if (name is not None):
            self.name = name
        if (initiative is not None):
            self.initiative = initiative
        if (damage is not None):
            self.damage = damage
        if (strength is not None):
            self.strength = strength
        if (size is not None):
            self.size = size
        if (tags is not None):
            self.tags = tags

    def getName(self):
        return self.name

    def getDisplayName(self):
        if (self.name is not None):
            return self.name
        return self.dn

    def getInitiativeMod(self):
        return self.initiative

    def getDamageMod(self):
        return self.damage

    def getStrengthReq(self):
        return self.strength

    def getSize(self):
        return self.size

    def getWeaponTags(self):
        return self.tags

    def setUpGameObject(self,gameObject):
        super().setUpGameObject(gameObject)
        manager = gameObject.getTraitManager()
        manager.addTrait(pw_tales_cofdsystem_weapon_traits_InitiativeMod.TYPE).setValue(self.getInitiativeMod())
        manager.addTrait(pw_tales_cofdsystem_weapon_traits_DamageMod.TYPE).setValue(self.getDamageMod())
        manager.addTrait(pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.TYPE).setValue(self.size)
        manager.addTrait(pw_tales_cofdsystem_equipment_traits_StrengthReq.TYPE).setValue(self.strength)
        manager.addTrait(pw_tales_cofdsystem_weapon_traits_LethalDamage.TYPE)
        manager.addTrait(pw_tales_cofdsystem_equipment_traits_HoldingHand.TYPE)
        _g = 0
        _g1 = self.getWeaponTags()
        while (_g < len(_g1)):
            def _hx_local_1():
                nonlocal _g
                _hx_local_0 = _g
                _g = (_g + 1)
                return _hx_local_0
            tag = python_internal_ArrayImpl._get(_g1, _hx_local_1())
            manager.addTrait(tag)

    def createWeapon(self,system):
        return pw_tales_cofdsystem_weapon_Weapon(self.createGameObject(system))

pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab._hx_class = pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab
_hx_classes["pw.tales.cofdsystem.weapon.prefabs.WeaponPrefab"] = pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab


class pw_tales_cofdsystem_weapon_traits_WeaponTrait(pw_tales_cofdsystem_equipment_traits_EquipmentTrait):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.WeaponTrait"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["isHolderPool", "isActionWithWeapon", "isHolderAttack", "isHolderDefence"]
    _hx_statics = ["PRIORITY"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_equipment_traits_EquipmentTrait


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)

    def isHolderPool(self,pool):
        holder = self.getHolder()
        return (pool.getGameObject() == holder)

    def isActionWithWeapon(self,attack):
        weapon = attack.getWeapon()
        if (weapon is None):
            return False
        return (weapon.getGameObject() == self.gameObject)

    def isHolderAttack(self,action):
        attack = pw_tales_cofdsystem_utils_Utility.downcast(action,pw_tales_cofdsystem_action_attack_AttackAction)
        if (attack is None):
            return False
        if (action.getActor() != self.getHolder()):
            return False
        if (not self.isActionWithWeapon(attack)):
            return False
        return True

    def isHolderDefence(self,action):
        attack = pw_tales_cofdsystem_utils_Utility.downcast(action,pw_tales_cofdsystem_action_attack_AttackAction)
        if (attack is None):
            return False
        if (attack.getTarget() != self.getHolder()):
            return False
        return True

pw_tales_cofdsystem_weapon_traits_WeaponTrait._hx_class = pw_tales_cofdsystem_weapon_traits_WeaponTrait
_hx_classes["pw.tales.cofdsystem.weapon.traits.WeaponTrait"] = pw_tales_cofdsystem_weapon_traits_WeaponTrait


class pw_tales_cofdsystem_weapon_traits_WeaponMod(pw_tales_cofdsystem_weapon_traits_WeaponTrait):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.WeaponMod"
    _hx_is_interface = "False"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["setValue", "getValue"]
    _hx_statics = ["__meta__"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_WeaponTrait


    def __init__(self,dn,gameObject,_hx_type):
        self.value = 0
        super().__init__(dn,gameObject,_hx_type)

    def setValue(self,value):
        self.value = value
        self.notifyUpdated()

    def getValue(self):
        return self.value

pw_tales_cofdsystem_weapon_traits_WeaponMod._hx_class = pw_tales_cofdsystem_weapon_traits_WeaponMod
_hx_classes["pw.tales.cofdsystem.weapon.traits.WeaponMod"] = pw_tales_cofdsystem_weapon_traits_WeaponMod


class pw_tales_cofdsystem_weapon_traits_DamageMod(pw_tales_cofdsystem_weapon_traits_WeaponMod):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.DamageMod"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["applyDamage"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_WeaponMod


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_attack_events_AttackSuccesesEvent,self.applyDamage)

    def applyDamage(self,event):
        if self.isHolderAttack(event.getAction()):
            return
        event.setDamageSucceses((event.getDamageSucceses() + self.getValue()))

pw_tales_cofdsystem_weapon_traits_DamageMod._hx_class = pw_tales_cofdsystem_weapon_traits_DamageMod
_hx_classes["pw.tales.cofdsystem.weapon.traits.DamageMod"] = pw_tales_cofdsystem_weapon_traits_DamageMod


class pw_tales_cofdsystem_weapon_traits_InitiativeMod(pw_tales_cofdsystem_weapon_traits_WeaponMod):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.InitiativeMod"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_WeaponMod


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_weapon_traits_InitiativeMod._hx_class = pw_tales_cofdsystem_weapon_traits_InitiativeMod
_hx_classes["pw.tales.cofdsystem.weapon.traits.InitiativeMod"] = pw_tales_cofdsystem_weapon_traits_InitiativeMod


class pw_tales_cofdsystem_weapon_traits_LethalDamage(pw_tales_cofdsystem_weapon_traits_WeaponTrait):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.LethalDamage"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["makeLethal"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_WeaponTrait


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_attack_events_AttackDamageGetTypeEvent,self.makeLethal)

    def makeLethal(self,event):
        if (not self.isHolderAttack(event.getAction())):
            return
        event.setDamageType("LETHAL")

pw_tales_cofdsystem_weapon_traits_LethalDamage._hx_class = pw_tales_cofdsystem_weapon_traits_LethalDamage
_hx_classes["pw.tales.cofdsystem.weapon.traits.LethalDamage"] = pw_tales_cofdsystem_weapon_traits_LethalDamage


class pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag(pw_tales_cofdsystem_weapon_traits_WeaponTrait):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.WeaponTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_WeaponTrait


    def __init__(self,dn,gameObject,_hx_type):
        _gthis = self
        super().__init__(dn,gameObject,_hx_type)
        def _hx_local_0(e):
            e.collect(_gthis)
        self.eventBus.addHandler(pw_tales_cofdsystem_weapon_traits_weapon_tags_events_WeaponTagsCollectEvent,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.WeaponTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_events_WeaponTagsCollectEvent(pw_tales_cofdsystem_game_object_events_CollectEvent):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.events.WeaponTagsCollectEvent"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_CollectEvent


    def __init__(self,gameObject):
        super().__init__(gameObject)
pw_tales_cofdsystem_weapon_traits_weapon_tags_events_WeaponTagsCollectEvent._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_events_WeaponTagsCollectEvent
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.events.WeaponTagsCollectEvent"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_events_WeaponTagsCollectEvent


class pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.AccurateTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["applyBonus"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.applyBonus)

    def applyBonus(self,e):
        action = e.getAction()
        pool = e.getActionPool()
        if (not self.isHolderPool(pool)):
            return
        if (not self.isHolderAttack(action)):
            return
        pool.getRequest().addModifier(1,pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag.DN)

pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.AccurateTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.BrawlTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["changeTraits"]
    _hx_statics = ["__meta__", "DN", "TYPE", "PRIORITY"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.changeTraits,pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag.PRIORITY)

    def changeTraits(self,e):
        action = e.getAction()
        pool = e.getActionPool()
        if (not self.isHolderPool(pool)):
            return
        if (not self.isHolderAttack(action)):
            return
        oldTraits = pool.getRequest().getTraits()
        value = pw_tales_cofdsystem_character_traits_skill_Skills.WEAPONRY.getDN()
        replaceWith = pw_tales_cofdsystem_character_traits_skill_Skills.BRAWL.getDN()
        _g = []
        _g1 = 0
        while (_g1 < len(oldTraits)):
            arrayValue = (oldTraits[_g1] if _g1 >= 0 and _g1 < len(oldTraits) else None)
            _g1 = (_g1 + 1)
            if (arrayValue == value):
                _g.append(replaceWith)
            else:
                _g.append(arrayValue)
        pool.getRequest().setTraits(_g)

pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.BrawlTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.ConcealedTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getShieldMod", "isOtherShieldBetter", "applyBonus"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionPoolEvent,self.applyBonus)

    def getShieldMod(self):
        size = self.gameObject.getTrait(pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.TYPE)
        if (size is None):
            return 0
        return size.getValue()

    def isOtherShieldBetter(self,value):
        return False

    def applyBonus(self,e):
        action = e.getAction()
        pool = e.getActionPool()
        request = pool.getRequest()
        if (not self.isHolderPool(pool)):
            return
        if (not self.isHolderDefence(action)):
            return
        value = self.getShieldMod()
        if self.isOtherShieldBetter(value):
            return
        request.addModifier(value,self.getDN())

pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.ConcealedTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.ExplodeTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["applyExplode", "getExplode"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.applyExplode)

    def applyExplode(self,e):
        action = e.getAction()
        if (not self.isHolderPool(e.getActionPool())):
            return
        if (not self.isHolderAttack(action)):
            return
        explode = self.getExplode()
        e.getActionPool().getRequest().setExplode(explode)

    def getExplode(self):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "src/pw/tales/cofdsystem/weapon/traits/weapon_tags/ExplodeTag.hx", 'lineNumber': 41, 'className': "pw.tales.cofdsystem.weapon.traits.weapon_tags.ExplodeTag", 'methodName': "getExplode"}))

pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.ExplodeTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.EightAgainTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getExplode"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)

    def getExplode(self):
        return pw_tales_cofdsystem_dices_EnumExplode.EIGHT_AGAIN

pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.EightAgainTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.FinesseTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["replaceStrWithDex"]
    _hx_statics = ["__meta__", "DN", "TYPE", "PRIORITY"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.replaceStrWithDex,pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag.PRIORITY)

    def replaceStrWithDex(self,event):
        action = event.getAction()
        pool = event.getActionPool()
        if (not self.isHolderPool(pool)):
            return
        if (not self.isHolderAttack(action)):
            return
        oldTraits = pool.getRequest().getTraits()
        value = pw_tales_cofdsystem_character_traits_attribute_Attributes.STRENGTH.getDN()
        replaceWith = pw_tales_cofdsystem_character_traits_attribute_Attributes.DEXTERITY.getDN()
        _g = []
        _g1 = 0
        while (_g1 < len(oldTraits)):
            arrayValue = (oldTraits[_g1] if _g1 >= 0 and _g1 < len(oldTraits) else None)
            _g1 = (_g1 + 1)
            if (arrayValue == value):
                _g.append(replaceWith)
            else:
                _g.append(arrayValue)
        pool.getRequest().setTraits(_g)

pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.FinesseTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.GrappleTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.GrappleTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.GuardTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["applyBonus"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionPoolEvent,self.applyBonus)

    def applyBonus(self,e):
        action = e.getAction()
        pool = e.getActionPool()
        request = pool.getRequest()
        if (not self.isHolderPool(pool)):
            return
        if (not self.isHolderDefence(action)):
            return
        request.addModifier(1,self.getDN())

pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.GuardTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.MercyTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["makeBashing"]
    _hx_statics = ["__meta__", "DN", "TYPE", "PRIORITY"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_attack_events_AttackDamageGetTypeEvent,self.makeBashing,pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag.PRIORITY)

    def makeBashing(self,e):
        if (not self.isHolderAttack(e.getAction())):
            return
        e.setDamageType("BASHING")

pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.MercyTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.NineAgainTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["getExplode"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_ExplodeTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)

    def getExplode(self):
        return pw_tales_cofdsystem_dices_EnumExplode.NINE_AGAIN

pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.NineAgainTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.ReachTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["checkTargetHasReach", "applyBonuses"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionPoolEvent,self.applyBonuses)

    def checkTargetHasReach(self,attack):
        heldWeapon = attack.getCompetition().getActor().getTrait(pw_tales_cofdsystem_character_traits_HeldWeapon.TYPE)
        main = heldWeapon.getMainHand()
        off = heldWeapon.getOffHand()
        tags = []
        if (main is not None):
            tags = (tags + main.getWeaponTags())
        if (off is not None):
            tags = (tags + off.getWeaponTags())
        return (pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag.TYPE in tags)

    def applyBonuses(self,e):
        action = e.getAction()
        pool = e.getActionPool()
        if (not self.isHolderPool(pool)):
            return
        if (not self.isHolderDefence(action)):
            return
        if self.checkTargetHasReach(pw_tales_cofdsystem_utils_Utility.downcast(action,pw_tales_cofdsystem_action_attack_AttackAction)):
            return
        pool.getRequest().addModifier(1,pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag.DN)

pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.ReachTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.StunTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.StunTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.TwoHandedTag"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["checkBothHandOccupied", "increaseStrengthReq"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.eventBus.addHandler(pw_tales_cofdsystem_equipment_events_StrengthReqEvent,self.increaseStrengthReq)

    def checkBothHandOccupied(self):
        holder = self.getHolder()
        if (holder is None):
            return False
        heldWeapon = holder.getTrait(pw_tales_cofdsystem_character_traits_HeldWeapon.TYPE)
        if (heldWeapon is None):
            return False
        if (heldWeapon.getMainHand() is not None):
            return (heldWeapon.getOffHand() is not None)
        else:
            return False

    def increaseStrengthReq(self,e):
        if (not self.checkBothHandOccupied()):
            return
        e.setValue((e.getValue() + 1))

pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.TwoHandedTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTags:
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.WeaponTags"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["collect"]

    @staticmethod
    def collect(gameObject):
        event = pw_tales_cofdsystem_weapon_traits_weapon_tags_events_WeaponTagsCollectEvent(gameObject)
        gameObject.getEventBus().post(event)
        return event.getCollected()
pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTags._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTags
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.WeaponTags"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTags


class pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTag(pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.piercing.PiercingTag"
    _hx_is_interface = "False"
    __slots__ = ("piercingType",)
    _hx_fields = ["piercingType"]
    _hx_methods = ["applyPiercing"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_weapon_tags_WeaponTag


    def __init__(self,gameObject,_hx_type):
        self.piercingType = None
        super().__init__(_hx_type.getDN(),gameObject,_hx_type)
        self.piercingType = _hx_type
        self.holderEventBus.addHandler(pw_tales_cofdsystem_armor_traits_armor_rating_events_AttackArmorGetEvent,self.applyPiercing)

    def applyPiercing(self,event):
        if (not self.isHolderAttack(event.getAction())):
            return
        general = event.getGeneral()
        ballistic = event.getBallistic()
        piercing = self.piercingType.getLevel()
        ballistic = (ballistic - piercing)
        if (ballistic < 0):
            piercing = ballistic
            ballistic = 0
        else:
            piercing = (piercing - event.getBallistic())
        x = Reflect.field(Math,"fabs")(piercing)
        try:
            piercing = int(x)
        except BaseException as _g:
            None
            piercing = None
        general = (general - piercing)
        if (general < 0):
            general = 0
        event.setGeneral(general)
        event.setBallistic(ballistic)

pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTag._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTag
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.piercing.PiercingTag"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTag


class pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTagType(pw_tales_cofdsystem_game_object_traits_TraitType):
    _hx_class_name = "pw.tales.cofdsystem.weapon.traits.weapon_tags.piercing.PiercingTagType"
    _hx_is_interface = "False"
    __slots__ = ("level",)
    _hx_fields = ["level"]
    _hx_methods = ["getLevel", "createWithDN"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_traits_TraitType


    def __init__(self,level):
        self.level = None
        super().__init__((("piercing_(" + Std.string(level)) + ")_(weapon_tag)"))
        self.level = level

    def getLevel(self):
        return self.level

    def createWithDN(self,dn,gameObject):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTag(gameObject,self)

pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTagType._hx_class = pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTagType
_hx_classes["pw.tales.cofdsystem.weapon.traits.weapon_tags.piercing.PiercingTagType"] = pw_tales_cofdsystem_weapon_traits_weapon_tags_piercing_PiercingTagType


class pw_tales_cofdsystem_weapon_melee_prefabs_MeleeWeaponPrefab(pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab):
    _hx_class_name = "pw.tales.cofdsystem.weapon_melee.prefabs.MeleeWeaponPrefab"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setUpGameObject"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab


    def __init__(self,name,initiative,damage,strength,size,tags,dn):
        super().__init__(name,initiative,damage,strength,size,tags,dn)

    def setUpGameObject(self,weaponGameObject):
        super().setUpGameObject(weaponGameObject)
        weaponGameObject.getTraitManager().addTrait(pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon.TYPE)

pw_tales_cofdsystem_weapon_melee_prefabs_MeleeWeaponPrefab._hx_class = pw_tales_cofdsystem_weapon_melee_prefabs_MeleeWeaponPrefab
_hx_classes["pw.tales.cofdsystem.weapon_melee.prefabs.MeleeWeaponPrefab"] = pw_tales_cofdsystem_weapon_melee_prefabs_MeleeWeaponPrefab


class pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon(pw_tales_cofdsystem_weapon_traits_WeaponTrait):
    _hx_class_name = "pw.tales.cofdsystem.weapon_melee.traits.MeleeWeapon"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["changeTraits"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_WeaponTrait


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.changeTraits,pw_tales_cofdsystem_weapon_traits_WeaponTrait.PRIORITY)

    def changeTraits(self,event):
        action = event.getAction()
        if (not self.isHolderPool(event.getActionPool())):
            return
        if (not self.isHolderAttack(action)):
            return
        event.getActionPool().getRequest().setTraits([pw_tales_cofdsystem_character_traits_attribute_Attributes.STRENGTH.getDN(), pw_tales_cofdsystem_character_traits_skill_Skills.WEAPONRY.getDN()])

pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon._hx_class = pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon
_hx_classes["pw.tales.cofdsystem.weapon_melee.traits.MeleeWeapon"] = pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon


class pw_tales_cofdsystem_weapon_ranged_events_RangedWeaponDefenceEvent(pw_tales_cofdsystem_game_object_events_GameObjectEvent):
    _hx_class_name = "pw.tales.cofdsystem.weapon_ranged.events.RangedWeaponDefenceEvent"
    _hx_is_interface = "False"
    __slots__ = ("canApply",)
    _hx_fields = ["canApply"]
    _hx_methods = ["getCanApply", "setCanApply"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_game_object_events_GameObjectEvent


    def __init__(self,gameObject):
        self.canApply = False
        super().__init__(gameObject)

    def getCanApply(self):
        return self.canApply

    def setCanApply(self,canApply):
        self.canApply = canApply

pw_tales_cofdsystem_weapon_ranged_events_RangedWeaponDefenceEvent._hx_class = pw_tales_cofdsystem_weapon_ranged_events_RangedWeaponDefenceEvent
_hx_classes["pw.tales.cofdsystem.weapon_ranged.events.RangedWeaponDefenceEvent"] = pw_tales_cofdsystem_weapon_ranged_events_RangedWeaponDefenceEvent


class pw_tales_cofdsystem_weapon_ranged_prefabs_RangedWeaponPrefab(pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab):
    _hx_class_name = "pw.tales.cofdsystem.weapon_ranged.prefabs.RangedWeaponPrefab"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["setUpGameObject"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_prefabs_WeaponPrefab


    def __init__(self,name,initiative,damage,strength,size,tags,dn):
        super().__init__(name,initiative,damage,strength,size,tags,dn)

    def setUpGameObject(self,weaponGameObject):
        super().setUpGameObject(weaponGameObject)
        weaponGameObject.getTraitManager().addTrait(pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon.TYPE)

pw_tales_cofdsystem_weapon_ranged_prefabs_RangedWeaponPrefab._hx_class = pw_tales_cofdsystem_weapon_ranged_prefabs_RangedWeaponPrefab
_hx_classes["pw.tales.cofdsystem.weapon_ranged.prefabs.RangedWeaponPrefab"] = pw_tales_cofdsystem_weapon_ranged_prefabs_RangedWeaponPrefab


class pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon(pw_tales_cofdsystem_weapon_traits_WeaponTrait):
    _hx_class_name = "pw.tales.cofdsystem.weapon_ranged.traits.RangedWeapon"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canApplyDefence", "changeTraits"]
    _hx_statics = ["__meta__", "DN", "TYPE"]
    _hx_interfaces = []
    _hx_super = pw_tales_cofdsystem_weapon_traits_WeaponTrait


    def __init__(self,dn,gameObject,_hx_type):
        super().__init__(dn,gameObject,_hx_type)
        self.holderEventBus.addHandler(pw_tales_cofdsystem_action_events_pool_ActionBuildPoolEvent,self.changeTraits,pw_tales_cofdsystem_weapon_traits_WeaponTrait.PRIORITY)

    def canApplyDefence(self,gameObject):
        event = pw_tales_cofdsystem_weapon_ranged_events_RangedWeaponDefenceEvent(gameObject)
        self.gameObject.getSystem().events.post(event)
        return event.getCanApply()

    def changeTraits(self,event):
        action = event.getAction()
        if (not self.isHolderPool(event.getActionPool())):
            return
        if (not self.isHolderAttack(action)):
            return
        competition = pw_tales_cofdsystem_utils_Utility.downcast(action,pw_tales_cofdsystem_action_attack_AttackAction).getCompetition()
        tmp = competition.getActorPool().getRequest()
        tmp1 = pw_tales_cofdsystem_character_traits_attribute_Attributes.DEXTERITY.getDN()
        tmp2 = pw_tales_cofdsystem_character_traits_skill_Skills.SHOOTING.getDN()
        tmp.setTraits([tmp1, tmp2])
        targetPool = competition.getTargetPool()
        if (not self.canApplyDefence(targetPool.getGameObject())):
            targetPool.getRequest().setTraits([])

pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon._hx_class = pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon
_hx_classes["pw.tales.cofdsystem.weapon_ranged.traits.RangedWeapon"] = pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon


class python_HaxeIterator:
    _hx_class_name = "python.HaxeIterator"
    _hx_is_interface = "False"
    __slots__ = ("it", "x", "has", "checked")
    _hx_fields = ["it", "x", "has", "checked"]
    _hx_methods = ["next", "hasNext"]

    def __init__(self,it):
        self.checked = False
        self.has = False
        self.x = None
        self.it = it

    def next(self):
        if (not self.checked):
            self.hasNext()
        self.checked = False
        return self.x

    def hasNext(self):
        if (not self.checked):
            try:
                self.x = self.it.__next__()
                self.has = True
            except BaseException as _g:
                None
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),StopIteration):
                    self.has = False
                    self.x = None
                else:
                    raise _g
            self.checked = True
        return self.has

python_HaxeIterator._hx_class = python_HaxeIterator
_hx_classes["python.HaxeIterator"] = python_HaxeIterator


class python__KwArgs_KwArgs_Impl_:
    _hx_class_name = "python._KwArgs.KwArgs_Impl_"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["fromT"]

    @staticmethod
    def fromT(d):
        return python_Lib.anonAsDict(d)
python__KwArgs_KwArgs_Impl_._hx_class = python__KwArgs_KwArgs_Impl_
_hx_classes["python._KwArgs.KwArgs_Impl_"] = python__KwArgs_KwArgs_Impl_


class python_Lib:
    _hx_class_name = "python.Lib"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["dictToAnon", "anonToDict", "anonAsDict"]

    @staticmethod
    def dictToAnon(v):
        return _hx_AnonObject(v.copy())

    @staticmethod
    def anonToDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__.copy()
        else:
            return None

    @staticmethod
    def anonAsDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__
        else:
            return None
python_Lib._hx_class = python_Lib
_hx_classes["python.Lib"] = python_Lib


class python_internal_ArrayImpl:
    _hx_class_name = "python.internal.ArrayImpl"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["concat", "copy", "iterator", "keyValueIterator", "indexOf", "lastIndexOf", "join", "toString", "pop", "push", "unshift", "remove", "contains", "shift", "slice", "sort", "splice", "map", "filter", "insert", "reverse", "_get", "_set"]

    @staticmethod
    def concat(a1,a2):
        return (a1 + a2)

    @staticmethod
    def copy(x):
        return list(x)

    @staticmethod
    def iterator(x):
        return python_HaxeIterator(x.__iter__())

    @staticmethod
    def keyValueIterator(x):
        return haxe_iterators_ArrayKeyValueIterator(x)

    @staticmethod
    def indexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (0 if ((fromIndex is None)) else ((_hx_len + fromIndex) if ((fromIndex < 0)) else fromIndex))
        if (l < 0):
            l = 0
        _g = l
        while (_g < _hx_len):
            i = _g
            _g = (_g + 1)
            if HxOverrides.eq(a[i],x):
                return i
        return -1

    @staticmethod
    def lastIndexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (_hx_len if ((fromIndex is None)) else (((_hx_len + fromIndex) + 1) if ((fromIndex < 0)) else (fromIndex + 1)))
        if (l > _hx_len):
            l = _hx_len
        while True:
            l = (l - 1)
            tmp = l
            if (not ((tmp > -1))):
                break
            if HxOverrides.eq(a[l],x):
                return l
        return -1

    @staticmethod
    def join(x,sep):
        return sep.join([python_Boot.toString1(x1,'') for x1 in x])

    @staticmethod
    def toString(x):
        return (("[" + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in x]))) + "]")

    @staticmethod
    def pop(x):
        if (len(x) == 0):
            return None
        else:
            return x.pop()

    @staticmethod
    def push(x,e):
        x.append(e)
        return len(x)

    @staticmethod
    def unshift(x,e):
        x.insert(0, e)

    @staticmethod
    def remove(x,e):
        try:
            x.remove(e)
            return True
        except BaseException as _g:
            None
            return False

    @staticmethod
    def contains(x,e):
        return (e in x)

    @staticmethod
    def shift(x):
        if (len(x) == 0):
            return None
        return x.pop(0)

    @staticmethod
    def slice(x,pos,end = None):
        return x[pos:end]

    @staticmethod
    def sort(x,f):
        x.sort(key= python_lib_Functools.cmp_to_key(f))

    @staticmethod
    def splice(x,pos,_hx_len):
        if (pos < 0):
            pos = (len(x) + pos)
        if (pos < 0):
            pos = 0
        res = x[pos:(pos + _hx_len)]
        del x[pos:(pos + _hx_len)]
        return res

    @staticmethod
    def map(x,f):
        return list(map(f,x))

    @staticmethod
    def filter(x,f):
        return list(filter(f,x))

    @staticmethod
    def insert(a,pos,x):
        a.insert(pos, x)

    @staticmethod
    def reverse(a):
        a.reverse()

    @staticmethod
    def _get(x,idx):
        if ((idx > -1) and ((idx < len(x)))):
            return x[idx]
        else:
            return None

    @staticmethod
    def _set(x,idx,v):
        l = len(x)
        while (l < idx):
            x.append(None)
            l = (l + 1)
        if (l == idx):
            x.append(v)
        else:
            x[idx] = v
        return v
python_internal_ArrayImpl._hx_class = python_internal_ArrayImpl
_hx_classes["python.internal.ArrayImpl"] = python_internal_ArrayImpl


class HxOverrides:
    _hx_class_name = "HxOverrides"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["iterator", "eq", "stringOrNull", "modf", "mod", "mapKwArgs"]

    @staticmethod
    def iterator(x):
        if isinstance(x,list):
            return haxe_iterators_ArrayIterator(x)
        return x.iterator()

    @staticmethod
    def eq(a,b):
        if (isinstance(a,list) or isinstance(b,list)):
            return a is b
        return (a == b)

    @staticmethod
    def stringOrNull(s):
        if (s is None):
            return "null"
        else:
            return s

    @staticmethod
    def modf(a,b):
        if (b == 0.0):
            return float('nan')
        elif (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def mod(a,b):
        if (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def mapKwArgs(a,v):
        a1 = _hx_AnonObject(python_Lib.anonToDict(a))
        k = python_HaxeIterator(iter(v.keys()))
        while k.hasNext():
            k1 = k.next()
            val = v.get(k1)
            if a1._hx_hasattr(k1):
                setattr(a1,val,getattr(a1,k1))
                delattr(a1,k1)
        return a1
HxOverrides._hx_class = HxOverrides
_hx_classes["HxOverrides"] = HxOverrides


class python_internal_MethodClosure:
    _hx_class_name = "python.internal.MethodClosure"
    _hx_is_interface = "False"
    __slots__ = ("obj", "func")
    _hx_fields = ["obj", "func"]
    _hx_methods = ["__call__"]

    def __init__(self,obj,func):
        self.obj = obj
        self.func = func

    def __call__(self,*args):
        return self.func(self.obj,*args)

python_internal_MethodClosure._hx_class = python_internal_MethodClosure
_hx_classes["python.internal.MethodClosure"] = python_internal_MethodClosure


class sys_net_Socket:
    _hx_class_name = "sys.net.Socket"
    _hx_is_interface = "False"
    __slots__ = ("_hx___s", "input", "output")
    _hx_fields = ["__s", "input", "output"]
    _hx_methods = ["__initSocket", "close", "connect", "shutdown", "setTimeout", "fileno"]

    def __init__(self):
        self.output = None
        self.input = None
        self._hx___s = None
        self._hx___initSocket()
        self.input = sys_net__Socket_SocketInput(self._hx___s)
        self.output = sys_net__Socket_SocketOutput(self._hx___s)

    def _hx___initSocket(self):
        self._hx___s = python_lib_socket_Socket()

    def close(self):
        self._hx___s.close()

    def connect(self,host,port):
        host_str = host.toString()
        self._hx___s.connect((host_str, port))

    def shutdown(self,read,write):
        self._hx___s.shutdown((python_lib_Socket.SHUT_RDWR if ((read and write)) else (python_lib_Socket.SHUT_RD if read else python_lib_Socket.SHUT_WR)))

    def setTimeout(self,timeout):
        self._hx___s.settimeout(timeout)

    def fileno(self):
        return self._hx___s.fileno()

sys_net_Socket._hx_class = sys_net_Socket
_hx_classes["sys.net.Socket"] = sys_net_Socket


class python_net_SslSocket(sys_net_Socket):
    _hx_class_name = "python.net.SslSocket"
    _hx_is_interface = "False"
    __slots__ = ("hostName",)
    _hx_fields = ["hostName"]
    _hx_methods = ["__initSocket", "connect"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = sys_net_Socket


    def __init__(self):
        self.hostName = None
        super().__init__()

    def _hx___initSocket(self):
        context = python_lib_Ssl.create_default_context(python_lib_ssl_Purpose.SERVER_AUTH)
        context.options = (context.options | ((python_lib_Ssl.OP_NO_TLSv1 | python_lib_Ssl.OP_NO_TLSv1_1)))
        self._hx___s = python_lib_socket_Socket()
        self._hx___s = context.wrap_socket(self._hx___s,False,True,True,self.hostName)

    def connect(self,host,port):
        self.hostName = host.host
        super().connect(host,port)

python_net_SslSocket._hx_class = python_net_SslSocket
_hx_classes["python.net.SslSocket"] = python_net_SslSocket


class sys_Http(haxe_http_HttpBase):
    _hx_class_name = "sys.Http"
    _hx_is_interface = "False"
    __slots__ = ("noShutdown", "cnxTimeout", "responseHeaders", "chunk_size", "chunk_buf", "file")
    _hx_fields = ["noShutdown", "cnxTimeout", "responseHeaders", "chunk_size", "chunk_buf", "file"]
    _hx_methods = ["request", "customRequest", "writeBody", "readHttpResponse", "readChunk"]
    _hx_statics = ["PROXY"]
    _hx_interfaces = []
    _hx_super = haxe_http_HttpBase


    def __init__(self,url):
        self.file = None
        self.chunk_buf = None
        self.chunk_size = None
        self.responseHeaders = None
        self.noShutdown = None
        self.cnxTimeout = 10
        super().__init__(url)

    def request(self,post = None):
        _gthis = self
        output = haxe_io_BytesOutput()
        old = self.onError
        err = False
        def _hx_local_0(e):
            nonlocal err
            _gthis.responseBytes = output.getBytes()
            err = True
            _gthis.onError = old
            _gthis.onError(e)
        self.onError = _hx_local_0
        post = ((post or ((self.postBytes is not None))) or ((self.postData is not None)))
        self.customRequest(post,output)
        if (not err):
            self.success(output.getBytes())

    def customRequest(self,post,api,sock = None,method = None):
        self.responseAsString = None
        self.responseBytes = None
        url_regexp = EReg("^(https?://)?([a-zA-Z\\.0-9_-]+)(:[0-9]+)?(.*)$","")
        url_regexp.matchObj = python_lib_Re.search(url_regexp.pattern,self.url)
        if (url_regexp.matchObj is None):
            self.onError("Invalid URL")
            return
        secure = (url_regexp.matchObj.group(1) == "https://")
        if (sock is None):
            if secure:
                sock = python_net_SslSocket()
            else:
                sock = sys_net_Socket()
            sock.setTimeout(self.cnxTimeout)
        host = url_regexp.matchObj.group(2)
        portString = url_regexp.matchObj.group(3)
        request = url_regexp.matchObj.group(4)
        if ((("" if ((0 >= len(request))) else request[0])) != "/"):
            request = ("/" + ("null" if request is None else request))
        port = ((443 if secure else 80) if (((portString is None) or ((portString == "")))) else Std.parseInt(HxString.substr(portString,1,(len(portString) - 1))))
        multipart = (self.file is not None)
        boundary = None
        uri = None
        if multipart:
            post = True
            boundary = (((Std.string(int((python_lib_Random.random() * 1000))) + Std.string(int((python_lib_Random.random() * 1000)))) + Std.string(int((python_lib_Random.random() * 1000)))) + Std.string(int((python_lib_Random.random() * 1000))))
            while (len(boundary) < 38):
                boundary = ("-" + ("null" if boundary is None else boundary))
            b_b = python_lib_io_StringIO()
            _g = 0
            _g1 = self.params
            while (_g < len(_g1)):
                p = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                b_b.write("--")
                b_b.write(Std.string(boundary))
                b_b.write("\r\n")
                b_b.write("Content-Disposition: form-data; name=\"")
                b_b.write(Std.string(p.name))
                b_b.write("\"")
                b_b.write("\r\n")
                b_b.write("\r\n")
                b_b.write(Std.string(p.value))
                b_b.write("\r\n")
            b_b.write("--")
            b_b.write(Std.string(boundary))
            b_b.write("\r\n")
            b_b.write("Content-Disposition: form-data; name=\"")
            b_b.write(Std.string(self.file.param))
            b_b.write("\"; filename=\"")
            b_b.write(Std.string(self.file.filename))
            b_b.write("\"")
            b_b.write("\r\n")
            b_b.write(Std.string(((("Content-Type: " + HxOverrides.stringOrNull(self.file.mimeType)) + "\r\n") + "\r\n")))
            uri = b_b.getvalue()
        else:
            _g = 0
            _g1 = self.params
            while (_g < len(_g1)):
                p = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                if (uri is None):
                    uri = ""
                else:
                    uri = (("null" if uri is None else uri) + "&")
                uri = (("null" if uri is None else uri) + HxOverrides.stringOrNull((((HxOverrides.stringOrNull(python_lib_urllib_Parse.quote(p.name,"")) + "=") + HxOverrides.stringOrNull(python_lib_urllib_Parse.quote(("" + HxOverrides.stringOrNull(p.value)),""))))))
        b = haxe_io_BytesOutput()
        if (method is not None):
            b.writeString(method)
            b.writeString(" ")
        elif post:
            b.writeString("POST ")
        else:
            b.writeString("GET ")
        if (sys_Http.PROXY is not None):
            b.writeString("http://")
            b.writeString(host)
            if (port != 80):
                b.writeString(":")
                b.writeString(("" + Std.string(port)))
        b.writeString(request)
        if ((not post) and ((uri is not None))):
            if (HxString.indexOfImpl(request,"?",0) >= 0):
                b.writeString("&")
            else:
                b.writeString("?")
            b.writeString(uri)
        b.writeString(((" HTTP/1.1\r\nHost: " + ("null" if host is None else host)) + "\r\n"))
        if (self.postData is not None):
            self.postBytes = haxe_io_Bytes.ofString(self.postData)
            self.postData = None
        if (self.postBytes is not None):
            b.writeString((("Content-Length: " + Std.string(self.postBytes.length)) + "\r\n"))
        elif (post and ((uri is not None))):
            def _hx_local_4(h):
                return (h.name == "Content-Type")
            if (multipart or (not Lambda.exists(self.headers,_hx_local_4))):
                b.writeString("Content-Type: ")
                if multipart:
                    b.writeString("multipart/form-data")
                    b.writeString("; boundary=")
                    b.writeString(boundary)
                else:
                    b.writeString("application/x-www-form-urlencoded")
                b.writeString("\r\n")
            if multipart:
                b.writeString((("Content-Length: " + Std.string(((((len(uri) + self.file.size) + len(boundary)) + 6)))) + "\r\n"))
            else:
                b.writeString((("Content-Length: " + Std.string(len(uri))) + "\r\n"))
        b.writeString("Connection: close\r\n")
        _g = 0
        _g1 = self.headers
        while (_g < len(_g1)):
            h = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            b.writeString(h.name)
            b.writeString(": ")
            b.writeString(h.value)
            b.writeString("\r\n")
        b.writeString("\r\n")
        if (self.postBytes is not None):
            b.writeFullBytes(self.postBytes,0,self.postBytes.length)
        elif (post and ((uri is not None))):
            b.writeString(uri)
        try:
            if (sys_Http.PROXY is not None):
                sock.connect(sys_net_Host(sys_Http.PROXY.host),sys_Http.PROXY.port)
            else:
                sock.connect(sys_net_Host(host),port)
            if multipart:
                self.writeBody(b,self.file.io,self.file.size,boundary,sock)
            else:
                self.writeBody(b,None,0,None,sock)
            self.readHttpResponse(api,sock)
            sock.close()
        except BaseException as _g:
            None
            _g1 = haxe_Exception.caught(_g).unwrap()
            try:
                sock.close()
            except BaseException as _g:
                pass
            self.onError(Std.string(_g1))

    def writeBody(self,body,fileInput,fileSize,boundary,sock):
        if (body is not None):
            _hx_bytes = body.getBytes()
            sock.output.writeFullBytes(_hx_bytes,0,_hx_bytes.length)
        if (boundary is not None):
            buf = haxe_io_Bytes.alloc(4096)
            while (fileSize > 0):
                size = (4096 if ((fileSize > 4096)) else fileSize)
                _hx_len = 0
                try:
                    _hx_len = fileInput.readBytes(buf,0,size)
                except BaseException as _g:
                    None
                    if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                        break
                    else:
                        raise _g
                sock.output.writeFullBytes(buf,0,_hx_len)
                fileSize = (fileSize - _hx_len)
            sock.output.writeString("\r\n")
            sock.output.writeString("--")
            sock.output.writeString(boundary)
            sock.output.writeString("--")

    def readHttpResponse(self,api,sock):
        b = haxe_io_BytesBuffer()
        k = 4
        s = haxe_io_Bytes.alloc(4)
        sock.setTimeout(self.cnxTimeout)
        while True:
            p = sock.input.readBytes(s,0,k)
            while (p != k):
                p = (p + sock.input.readBytes(s,p,(k - p)))
            if ((k < 0) or ((k > s.length))):
                raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
            b.b.extend(s.b[0:k])
            k1 = k
            if (k1 == 1):
                c = s.b[0]
                if (c == 10):
                    break
                if (c == 13):
                    k = 3
                else:
                    k = 4
            elif (k1 == 2):
                c1 = s.b[1]
                if (c1 == 10):
                    if (s.b[0] == 13):
                        break
                    k = 4
                elif (c1 == 13):
                    k = 3
                else:
                    k = 4
            elif (k1 == 3):
                c2 = s.b[2]
                if (c2 == 10):
                    if (s.b[1] != 13):
                        k = 4
                    elif (s.b[0] != 10):
                        k = 2
                    else:
                        break
                elif (c2 == 13):
                    if ((s.b[1] != 10) or ((s.b[0] != 13))):
                        k = 1
                    else:
                        k = 3
                else:
                    k = 4
            elif (k1 == 4):
                c3 = s.b[3]
                if (c3 == 10):
                    if (s.b[2] != 13):
                        continue
                    elif ((s.b[1] != 10) or ((s.b[0] != 13))):
                        k = 2
                    else:
                        break
                elif (c3 == 13):
                    if ((s.b[2] != 10) or ((s.b[1] != 13))):
                        k = 3
                    else:
                        k = 1
            else:
                pass
        headers = b.getBytes().toString().split("\r\n")
        status = Std.parseInt(python_internal_ArrayImpl._get((None if ((len(headers) == 0)) else headers.pop(0)).split(" "), 1))
        if ((status == 0) or ((status is None))):
            raise haxe_Exception.thrown("Response status error")
        if (len(headers) != 0):
            headers.pop()
        if (len(headers) != 0):
            headers.pop()
        self.responseHeaders = haxe_ds_StringMap()
        size = None
        chunked = False
        _g = 0
        while (_g < len(headers)):
            def _hx_local_2():
                nonlocal _g
                _hx_local_1 = _g
                _g = (_g + 1)
                return _hx_local_1
            hline = python_internal_ArrayImpl._get(headers, _hx_local_2())
            a = hline.split(": ")
            hname = (None if ((len(a) == 0)) else a.pop(0))
            hval = ((a[0] if 0 < len(a) else None) if ((len(a) == 1)) else ": ".join([python_Boot.toString1(x1,'') for x1 in a]))
            hval = StringTools.ltrim(StringTools.rtrim(hval))
            self.responseHeaders.h[hname] = hval
            _g1 = hname.lower()
            _hx_local_3 = len(_g1)
            if (_hx_local_3 == 17):
                if (_g1 == "transfer-encoding"):
                    chunked = (hval.lower() == "chunked")
            elif (_hx_local_3 == 14):
                if (_g1 == "content-length"):
                    size = Std.parseInt(hval)
            else:
                pass
        self.onStatus(status)
        chunk_re = EReg("^([0-9A-Fa-f]+)[ ]*\r\n","m")
        self.chunk_size = None
        self.chunk_buf = None
        buf = haxe_io_Bytes.alloc(1024)
        if chunked:
            try:
                while self.readChunk(chunk_re,api,buf,sock.input.readBytes(buf,0,1024)):
                    pass
            except BaseException as _g:
                None
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                    raise haxe_Exception.thrown("Transfer aborted")
                else:
                    raise _g
        elif (size is None):
            if (not self.noShutdown):
                sock.shutdown(False,True)
            try:
                while True:
                    _hx_len = sock.input.readBytes(buf,0,1024)
                    if (_hx_len == 0):
                        break
                    api.writeBytes(buf,0,_hx_len)
            except BaseException as _g:
                None
                if (not Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof)):
                    raise _g
        else:
            api.prepare(size)
            try:
                while (size > 0):
                    _hx_len = sock.input.readBytes(buf,0,(1024 if ((size > 1024)) else size))
                    api.writeBytes(buf,0,_hx_len)
                    size = (size - _hx_len)
            except BaseException as _g:
                None
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                    raise haxe_Exception.thrown("Transfer aborted")
                else:
                    raise _g
        if (chunked and (((self.chunk_size is not None) or ((self.chunk_buf is not None))))):
            raise haxe_Exception.thrown("Invalid chunk")
        if ((status < 200) or ((status >= 400))):
            raise haxe_Exception.thrown(("Http Error #" + Std.string(status)))
        api.close()

    def readChunk(self,chunk_re,api,buf,_hx_len):
        if (self.chunk_size is None):
            if (self.chunk_buf is not None):
                b = haxe_io_BytesBuffer()
                b.b.extend(self.chunk_buf.b)
                if ((_hx_len < 0) or ((_hx_len > buf.length))):
                    raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
                b.b.extend(buf.b[0:_hx_len])
                buf = b.getBytes()
                _hx_len = (_hx_len + self.chunk_buf.length)
                self.chunk_buf = None
            s = buf.toString()
            chunk_re.matchObj = python_lib_Re.search(chunk_re.pattern,s)
            if (chunk_re.matchObj is not None):
                chunk_re.matchObj.start()
                p_len = (chunk_re.matchObj.end() - chunk_re.matchObj.start())
                if (p_len <= _hx_len):
                    self.chunk_size = Std.parseInt(("0x" + HxOverrides.stringOrNull(chunk_re.matchObj.group(1))))
                    if (self.chunk_size == 0):
                        self.chunk_size = None
                        self.chunk_buf = None
                        return False
                    _hx_len = (_hx_len - p_len)
                    return self.readChunk(chunk_re,api,buf.sub(p_len,_hx_len),_hx_len)
            if (_hx_len > 10):
                self.onError("Invalid chunk")
                return False
            self.chunk_buf = buf.sub(0,_hx_len)
            return True
        if (self.chunk_size > _hx_len):
            _hx_local_2 = self
            _hx_local_3 = _hx_local_2.chunk_size
            _hx_local_2.chunk_size = (_hx_local_3 - _hx_len)
            _hx_local_2.chunk_size
            api.writeBytes(buf,0,_hx_len)
            return True
        end = (self.chunk_size + 2)
        if (_hx_len >= end):
            if (self.chunk_size > 0):
                api.writeBytes(buf,0,self.chunk_size)
            _hx_len = (_hx_len - end)
            self.chunk_size = None
            if (_hx_len == 0):
                return True
            return self.readChunk(chunk_re,api,buf.sub(end,_hx_len),_hx_len)
        if (self.chunk_size > 0):
            api.writeBytes(buf,0,self.chunk_size)
        _hx_local_5 = self
        _hx_local_6 = _hx_local_5.chunk_size
        _hx_local_5.chunk_size = (_hx_local_6 - _hx_len)
        _hx_local_5.chunk_size
        return True

sys_Http._hx_class = sys_Http
_hx_classes["sys.Http"] = sys_Http


class sys_net_Host:
    _hx_class_name = "sys.net.Host"
    _hx_is_interface = "False"
    __slots__ = ("host", "name")
    _hx_fields = ["host", "name"]
    _hx_methods = ["toString"]

    def __init__(self,name):
        self.host = name
        self.name = name

    def toString(self):
        return self.name

sys_net_Host._hx_class = sys_net_Host
_hx_classes["sys.net.Host"] = sys_net_Host


class sys_net__Socket_SocketInput(haxe_io_Input):
    _hx_class_name = "sys.net._Socket.SocketInput"
    _hx_is_interface = "False"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = ["readByte", "readBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Input


    def __init__(self,s):
        self._hx___s = s

    def readByte(self):
        r = None
        try:
            r = self._hx___s.recv(1,0)
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g
        if (len(r) == 0):
            raise haxe_Exception.thrown(haxe_io_Eof())
        return r[0]

    def readBytes(self,buf,pos,_hx_len):
        r = None
        data = buf.b
        try:
            r = self._hx___s.recv(_hx_len,0)
            _g = pos
            _g1 = (pos + len(r))
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                data.__setitem__(i,r[(i - pos)])
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g
        if (len(r) == 0):
            raise haxe_Exception.thrown(haxe_io_Eof())
        return len(r)

sys_net__Socket_SocketInput._hx_class = sys_net__Socket_SocketInput
_hx_classes["sys.net._Socket.SocketInput"] = sys_net__Socket_SocketInput


class sys_net__Socket_SocketOutput(haxe_io_Output):
    _hx_class_name = "sys.net._Socket.SocketOutput"
    _hx_is_interface = "False"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = ["writeByte", "writeBytes", "close"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self,s):
        self._hx___s = s

    def writeByte(self,c):
        try:
            self._hx___s.send(bytes([c]),0)
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g

    def writeBytes(self,buf,pos,_hx_len):
        try:
            payload = buf.b[pos:pos+_hx_len]
            return self._hx___s.send(payload,0)
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g

    def close(self):
        super().close()
        if (self._hx___s is not None):
            self._hx___s.close()

sys_net__Socket_SocketOutput._hx_class = sys_net__Socket_SocketOutput
_hx_classes["sys.net._Socket.SocketOutput"] = sys_net__Socket_SocketOutput


class thx_Error:
    _hx_class_name = "thx.Error"
    _hx_is_interface = "False"
    __slots__ = ("message", "pos", "stackItems")
    _hx_fields = ["message", "pos", "stackItems"]
    _hx_methods = ["toString", "getPosition", "stackToString"]
    _hx_statics = ["fromDynamic"]

    def __init__(self,message,stack = None,pos = None):
        self.message = message
        if (None is stack):
            try:
                stack = haxe__CallStack_CallStack_Impl_.exceptionStack()
            except BaseException as _g:
                None
                stack = []
            if (len(stack) == 0):
                try:
                    stack = haxe__CallStack_CallStack_Impl_.callStack()
                except BaseException as _g:
                    None
                    stack = []
        self.stackItems = stack
        self.pos = pos

    def toString(self):
        return ((((HxOverrides.stringOrNull(self.message) + "\nfrom: ") + HxOverrides.stringOrNull(self.getPosition())) + "\n\n") + HxOverrides.stringOrNull(self.stackToString()))

    def getPosition(self):
        return ((((HxOverrides.stringOrNull(self.pos.className) + ".") + HxOverrides.stringOrNull(self.pos.methodName)) + "() at ") + Std.string(self.pos.lineNumber))

    def stackToString(self):
        return haxe__CallStack_CallStack_Impl_.toString(self.stackItems)

    @staticmethod
    def fromDynamic(err,pos = None):
        if Std.isOfType(err,thx_Error):
            return err
        return thx_error_ErrorWrapper(("" + Std.string(err)),err,None,pos)

thx_Error._hx_class = thx_Error
_hx_classes["thx.Error"] = thx_Error


class thx_Uuid:
    _hx_class_name = "thx.Uuid"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["random", "srandom", "create", "isValid"]

    @staticmethod
    def random(_hx_max):
        return Math.floor((python_lib_Random.random() * _hx_max))

    @staticmethod
    def srandom():
        index = Math.floor((python_lib_Random.random() * 16))
        if ((index < 0) or ((index >= len("0123456789abcdef")))):
            return ""
        else:
            return "0123456789abcdef"[index]

    @staticmethod
    def create():
        s = []
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 0, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 1, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 2, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 3, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 4, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 5, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 6, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 7, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        python_internal_ArrayImpl._set(s, 8, "-")
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 9, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 10, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 11, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 12, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        python_internal_ArrayImpl._set(s, 13, "-")
        python_internal_ArrayImpl._set(s, 14, "4")
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 15, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 16, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 17, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        python_internal_ArrayImpl._set(s, 18, "-")
        index = Math.floor((python_lib_Random.random() * 3))
        python_internal_ArrayImpl._set(s, 19, ("" if (((index < 0) or ((index >= len("89AB"))))) else "89AB"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 20, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 21, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 22, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        python_internal_ArrayImpl._set(s, 23, "-")
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 24, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 25, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 26, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 27, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 28, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 29, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 30, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 31, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 32, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 33, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 34, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        index = Math.floor((python_lib_Random.random() * 16))
        python_internal_ArrayImpl._set(s, 35, ("" if (((index < 0) or ((index >= len("0123456789abcdef"))))) else "0123456789abcdef"[index]))
        return "".join([python_Boot.toString1(x1,'') for x1 in s])

    @staticmethod
    def isValid(uuid):
        _this = EReg("^[0123456789abcdef]{8}-[0123456789abcdef]{4}-4[0123456789abcdef]{3}-[89ab][0123456789abcdef]{3}-[0123456789abcdef]{12}$","i")
        _this.matchObj = python_lib_Re.search(_this.pattern,uuid)
        return (_this.matchObj is not None)
thx_Uuid._hx_class = thx_Uuid
_hx_classes["thx.Uuid"] = thx_Uuid


class thx_error_AbstractMethod(thx_Error):
    _hx_class_name = "thx.error.AbstractMethod"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = thx_Error


    def __init__(self,posInfo = None):
        super().__init__((((("method " + HxOverrides.stringOrNull(posInfo.className)) + ".") + HxOverrides.stringOrNull(posInfo.methodName)) + "() is abstract"),None,posInfo)
thx_error_AbstractMethod._hx_class = thx_error_AbstractMethod
_hx_classes["thx.error.AbstractMethod"] = thx_error_AbstractMethod


class thx_error_ErrorWrapper(thx_Error):
    _hx_class_name = "thx.error.ErrorWrapper"
    _hx_is_interface = "False"
    __slots__ = ("innerError",)
    _hx_fields = ["innerError"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = thx_Error


    def __init__(self,message,innerError,stack = None,pos = None):
        self.innerError = None
        super().__init__(message,stack,pos)
        self.innerError = innerError

thx_error_ErrorWrapper._hx_class = thx_error_ErrorWrapper
_hx_classes["thx.error.ErrorWrapper"] = thx_error_ErrorWrapper


class thx_error_NotImplemented(thx_Error):
    _hx_class_name = "thx.error.NotImplemented"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = thx_Error


    def __init__(self,posInfo = None):
        super().__init__((((("method " + HxOverrides.stringOrNull(posInfo.className)) + ".") + HxOverrides.stringOrNull(posInfo.methodName)) + "() needs to be implemented"),None,posInfo)
thx_error_NotImplemented._hx_class = thx_error_NotImplemented
_hx_classes["thx.error.NotImplemented"] = thx_error_NotImplemented


class thx_semver__Version_Version_Impl_:
    _hx_class_name = "thx.semver._Version.Version_Impl_"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["VERSION", "stringToVersion", "arrayToVersion", "_new", "nextMajor", "nextMinor", "nextPatch", "nextPre", "nextBuild", "withPre", "withBuild", "satisfies", "toString", "equals", "different", "greaterThan", "greaterThanOrEqual", "lessThan", "lessThanOrEqual", "get_major", "get_minor", "get_patch", "get_pre", "get_hasPre", "get_build", "get_hasBuild", "identifiersToString", "parseIdentifiers", "parseIdentifier", "equalsIdentifiers", "greaterThanIdentifiers", "nextIdentifiers", "SANITIZER", "sanitize"]
    major = None
    minor = None
    patch = None
    pre = None
    hasPre = None
    build = None
    hasBuild = None

    @staticmethod
    def stringToVersion(s):
        _this = thx_semver__Version_Version_Impl_.VERSION
        _this.matchObj = python_lib_Re.search(_this.pattern,s)
        if (_this.matchObj is None):
            raise haxe_Exception.thrown((("Invalid SemVer format for \"" + ("null" if s is None else s)) + "\""))
        return _hx_AnonObject({'version': [Std.parseInt(thx_semver__Version_Version_Impl_.VERSION.matchObj.group(1)), Std.parseInt(thx_semver__Version_Version_Impl_.VERSION.matchObj.group(2)), Std.parseInt(thx_semver__Version_Version_Impl_.VERSION.matchObj.group(3))], 'pre': thx_semver__Version_Version_Impl_.parseIdentifiers(thx_semver__Version_Version_Impl_.VERSION.matchObj.group(4)), 'build': thx_semver__Version_Version_Impl_.parseIdentifiers(thx_semver__Version_Version_Impl_.VERSION.matchObj.group(5))})

    @staticmethod
    def arrayToVersion(a):
        def _hx_local_0(v):
            if (v < 0):
                return -v
            else:
                return v
        a = (list(map(_hx_local_0,([] if ((None is a)) else a))) + [0, 0, 0])[0:3]
        return _hx_AnonObject({'version': [(a[0] if 0 < len(a) else None), (a[1] if 1 < len(a) else None), (a[2] if 2 < len(a) else None)], 'pre': [], 'build': []})

    @staticmethod
    def _new(major,minor,patch,pre,build):
        return _hx_AnonObject({'version': [major, minor, patch], 'pre': pre, 'build': build})

    @staticmethod
    def nextMajor(this1):
        return _hx_AnonObject({'version': [(python_internal_ArrayImpl._get(this1.version, 0) + 1), 0, 0], 'pre': [], 'build': []})

    @staticmethod
    def nextMinor(this1):
        return _hx_AnonObject({'version': [python_internal_ArrayImpl._get(this1.version, 0), (python_internal_ArrayImpl._get(this1.version, 1) + 1), 0], 'pre': [], 'build': []})

    @staticmethod
    def nextPatch(this1):
        return _hx_AnonObject({'version': [python_internal_ArrayImpl._get(this1.version, 0), python_internal_ArrayImpl._get(this1.version, 1), (python_internal_ArrayImpl._get(this1.version, 2) + 1)], 'pre': [], 'build': []})

    @staticmethod
    def nextPre(this1):
        return _hx_AnonObject({'version': [python_internal_ArrayImpl._get(this1.version, 0), python_internal_ArrayImpl._get(this1.version, 1), python_internal_ArrayImpl._get(this1.version, 2)], 'pre': thx_semver__Version_Version_Impl_.nextIdentifiers(this1.pre), 'build': []})

    @staticmethod
    def nextBuild(this1):
        return _hx_AnonObject({'version': [python_internal_ArrayImpl._get(this1.version, 0), python_internal_ArrayImpl._get(this1.version, 1), python_internal_ArrayImpl._get(this1.version, 2)], 'pre': this1.pre, 'build': thx_semver__Version_Version_Impl_.nextIdentifiers(this1.build)})

    @staticmethod
    def withPre(this1,pre,build = None):
        return _hx_AnonObject({'version': [python_internal_ArrayImpl._get(this1.version, 0), python_internal_ArrayImpl._get(this1.version, 1), python_internal_ArrayImpl._get(this1.version, 2)], 'pre': thx_semver__Version_Version_Impl_.parseIdentifiers(pre), 'build': thx_semver__Version_Version_Impl_.parseIdentifiers(build)})

    @staticmethod
    def withBuild(this1,build):
        return _hx_AnonObject({'version': [python_internal_ArrayImpl._get(this1.version, 0), python_internal_ArrayImpl._get(this1.version, 1), python_internal_ArrayImpl._get(this1.version, 2)], 'pre': this1.pre, 'build': thx_semver__Version_Version_Impl_.parseIdentifiers(build)})

    @staticmethod
    def satisfies(this1,rule):
        return thx_semver__VersionRule_VersionRule_Impl_.isSatisfiedBy(rule,this1)

    @staticmethod
    def toString(this1):
        _this = this1.version
        v = ".".join([python_Boot.toString1(x1,'') for x1 in _this])
        if (len(this1.pre) > 0):
            v = (("null" if v is None else v) + HxOverrides.stringOrNull((("-" + HxOverrides.stringOrNull(thx_semver__Version_Version_Impl_.identifiersToString(this1.pre))))))
        if (len(this1.build) > 0):
            v = (("null" if v is None else v) + HxOverrides.stringOrNull((("+" + HxOverrides.stringOrNull(thx_semver__Version_Version_Impl_.identifiersToString(this1.build))))))
        return v

    @staticmethod
    def equals(this1,other):
        if (((python_internal_ArrayImpl._get(this1.version, 0) != python_internal_ArrayImpl._get(other.version, 0)) or ((python_internal_ArrayImpl._get(this1.version, 1) != python_internal_ArrayImpl._get(other.version, 1)))) or ((python_internal_ArrayImpl._get(this1.version, 2) != python_internal_ArrayImpl._get(other.version, 2)))):
            return False
        return thx_semver__Version_Version_Impl_.equalsIdentifiers(this1.pre,other.pre)

    @staticmethod
    def different(this1,other):
        return (not thx_semver__Version_Version_Impl_.equals(other,this1))

    @staticmethod
    def greaterThan(this1,other):
        if ((len(this1.pre) > 0) and ((len(other.pre) > 0))):
            if (((python_internal_ArrayImpl._get(this1.version, 0) == python_internal_ArrayImpl._get(other.version, 0)) and ((python_internal_ArrayImpl._get(this1.version, 1) == python_internal_ArrayImpl._get(other.version, 1)))) and ((python_internal_ArrayImpl._get(this1.version, 2) == python_internal_ArrayImpl._get(other.version, 2)))):
                return thx_semver__Version_Version_Impl_.greaterThanIdentifiers(this1.pre,other.pre)
            else:
                return False
        elif (len(other.pre) > 0):
            if (python_internal_ArrayImpl._get(this1.version, 0) != python_internal_ArrayImpl._get(other.version, 0)):
                return (python_internal_ArrayImpl._get(this1.version, 0) > python_internal_ArrayImpl._get(other.version, 0))
            if (python_internal_ArrayImpl._get(this1.version, 1) != python_internal_ArrayImpl._get(other.version, 1)):
                return (python_internal_ArrayImpl._get(this1.version, 1) > python_internal_ArrayImpl._get(other.version, 1))
            if (python_internal_ArrayImpl._get(this1.version, 2) != python_internal_ArrayImpl._get(other.version, 2)):
                return (python_internal_ArrayImpl._get(this1.version, 2) > python_internal_ArrayImpl._get(other.version, 2))
            if (len(this1.pre) > 0):
                return thx_semver__Version_Version_Impl_.greaterThanIdentifiers(this1.pre,other.pre)
            else:
                return True
        elif (len(this1.pre) <= 0):
            if (python_internal_ArrayImpl._get(this1.version, 0) != python_internal_ArrayImpl._get(other.version, 0)):
                return (python_internal_ArrayImpl._get(this1.version, 0) > python_internal_ArrayImpl._get(other.version, 0))
            if (python_internal_ArrayImpl._get(this1.version, 1) != python_internal_ArrayImpl._get(other.version, 1)):
                return (python_internal_ArrayImpl._get(this1.version, 1) > python_internal_ArrayImpl._get(other.version, 1))
            if (python_internal_ArrayImpl._get(this1.version, 2) != python_internal_ArrayImpl._get(other.version, 2)):
                return (python_internal_ArrayImpl._get(this1.version, 2) > python_internal_ArrayImpl._get(other.version, 2))
            return thx_semver__Version_Version_Impl_.greaterThanIdentifiers(this1.pre,other.pre)
        else:
            return False

    @staticmethod
    def greaterThanOrEqual(this1,other):
        if (not thx_semver__Version_Version_Impl_.equals(this1,other)):
            return thx_semver__Version_Version_Impl_.greaterThan(this1,other)
        else:
            return True

    @staticmethod
    def lessThan(this1,other):
        return (not thx_semver__Version_Version_Impl_.greaterThanOrEqual(this1,other))

    @staticmethod
    def lessThanOrEqual(this1,other):
        return (not thx_semver__Version_Version_Impl_.greaterThan(this1,other))

    @staticmethod
    def get_major(this1):
        return (this1.version[0] if 0 < len(this1.version) else None)

    @staticmethod
    def get_minor(this1):
        return (this1.version[1] if 1 < len(this1.version) else None)

    @staticmethod
    def get_patch(this1):
        return (this1.version[2] if 2 < len(this1.version) else None)

    @staticmethod
    def get_pre(this1):
        return thx_semver__Version_Version_Impl_.identifiersToString(this1.pre)

    @staticmethod
    def get_hasPre(this1):
        return (len(this1.pre) > 0)

    @staticmethod
    def get_build(this1):
        return thx_semver__Version_Version_Impl_.identifiersToString(this1.build)

    @staticmethod
    def get_hasBuild(this1):
        return (len(this1.pre) > 0)

    @staticmethod
    def identifiersToString(ids):
        def _hx_local_0(id):
            _this = id.index
            if (_this == 0):
                return id.params[0]
            elif (_this == 1):
                return ("" + Std.string(id.params[0]))
            else:
                pass
        _this = list(map(_hx_local_0,ids))
        return ".".join([python_Boot.toString1(x1,'') for x1 in _this])

    @staticmethod
    def parseIdentifiers(s):
        def _hx_local_1():
            def _hx_local_0(s):
                return (s != "")
            return list(map(thx_semver__Version_Version_Impl_.parseIdentifier,list(filter(_hx_local_0,list(map(thx_semver__Version_Version_Impl_.sanitize,("" if ((None == s)) else s).split(".")))))))
        return _hx_local_1()

    @staticmethod
    def parseIdentifier(s):
        i = Std.parseInt(s)
        if (None == i):
            return thx_semver_Identifier.StringId(s)
        else:
            return thx_semver_Identifier.IntId(i)

    @staticmethod
    def equalsIdentifiers(a,b):
        if (len(a) != len(b)):
            return False
        _g = 0
        _g1 = len(a)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            _g2 = (a[i] if i >= 0 and i < len(a) else None)
            _g3 = (b[i] if i >= 0 and i < len(b) else None)
            tmp = _g2.index
            if (tmp == 0):
                if (_g3.index == 0):
                    if (_g2.params[0] != _g3.params[0]):
                        return False
            elif (tmp == 1):
                if (_g3.index == 1):
                    if (_g2.params[0] != _g3.params[0]):
                        return False
            else:
                pass
        return True

    @staticmethod
    def greaterThanIdentifiers(a,b):
        _g = 0
        _g1 = len(a)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            _g2 = (a[i] if i >= 0 and i < len(a) else None)
            _g3 = (b[i] if i >= 0 and i < len(b) else None)
            tmp = _g2.index
            if (tmp == 0):
                _g4 = _g2.params[0]
                tmp1 = _g3.index
                if (tmp1 == 0):
                    _g5 = _g3.params[0]
                    if (_g4 == _g5):
                        continue
                    elif (_g4 > _g5):
                        return True
                    else:
                        return False
                elif (tmp1 == 1):
                    return True
                else:
                    return False
            elif (tmp == 1):
                _g6 = _g2.params[0]
                if (_g3.index == 1):
                    _g7 = _g3.params[0]
                    if (_g6 == _g7):
                        continue
                    elif (_g6 > _g7):
                        return True
                    else:
                        return False
                else:
                    return False
            else:
                return False
        return False

    @staticmethod
    def nextIdentifiers(identifiers):
        identifiers1 = list(identifiers)
        i = len(identifiers1)
        while True:
            i = (i - 1)
            tmp = i
            if (not ((tmp >= 0))):
                break
            _g = (identifiers1[i] if i >= 0 and i < len(identifiers1) else None)
            if (_g.index == 1):
                python_internal_ArrayImpl._set(identifiers1, i, thx_semver_Identifier.IntId((_g.params[0] + 1)))
                break
        if (i < 0):
            raise haxe_Exception.thrown(("no numeric identifier found in " + Std.string(identifiers1)))
        return identifiers1

    @staticmethod
    def sanitize(s):
        return thx_semver__Version_Version_Impl_.SANITIZER.replace(s,"")
thx_semver__Version_Version_Impl_._hx_class = thx_semver__Version_Version_Impl_
_hx_classes["thx.semver._Version.Version_Impl_"] = thx_semver__Version_Version_Impl_

class thx_semver_Identifier(Enum):
    __slots__ = ()
    _hx_class_name = "thx.semver.Identifier"
    _hx_constructs = ["StringId", "IntId"]

    @staticmethod
    def StringId(value):
        return thx_semver_Identifier("StringId", 0, (value,))

    @staticmethod
    def IntId(value):
        return thx_semver_Identifier("IntId", 1, (value,))
thx_semver_Identifier._hx_class = thx_semver_Identifier
_hx_classes["thx.semver.Identifier"] = thx_semver_Identifier


class thx_semver__VersionRule_VersionRule_Impl_:
    _hx_class_name = "thx.semver._VersionRule.VersionRule_Impl_"
    _hx_is_interface = "False"
    __slots__ = ()
    _hx_statics = ["VERSION", "stringToVersionRule", "IS_DIGITS", "versionArray", "versionRuleIsValid", "isSatisfiedBy", "toString"]

    @staticmethod
    def stringToVersionRule(s):
        def _hx_local_1(comp):
            comp = StringTools.trim(comp)
            p = comp.split(" - ")
            if (len(p) == 1):
                comp = StringTools.trim(comp)
                p = EReg("\\s+","").split(comp)
                if (len(p) == 1):
                    if (len(comp) == 0):
                        return thx_semver_VersionComparator.GreaterThanOrEqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion([0, 0, 0]),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                    else:
                        _this = thx_semver__VersionRule_VersionRule_Impl_.VERSION
                        _this.matchObj = python_lib_Re.search(_this.pattern,comp)
                        if (_this.matchObj is None):
                            raise haxe_Exception.thrown((("invalid single pattern \"" + ("null" if comp is None else comp)) + "\""))
                        else:
                            v = thx_semver__VersionRule_VersionRule_Impl_.versionArray(thx_semver__VersionRule_VersionRule_Impl_.VERSION)
                            vf = (v + [0, 0, 0])[0:3]
                            _g = thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(1)
                            _g1 = len(v)
                            if (_g is None):
                                if (_g1 == 0):
                                    return thx_semver_VersionComparator.GreaterThanOrEqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                elif (_g1 == 1):
                                    version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                    return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMajor(version)))
                                elif (_g1 == 2):
                                    version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                    return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMinor(version)))
                                elif (_g1 == 3):
                                    return thx_semver_VersionComparator.EqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                else:
                                    raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                            else:
                                _hx_local_0 = len(_g)
                                if (_hx_local_0 == 1):
                                    if (_g == "<"):
                                        return thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                    elif (_g == ">"):
                                        return thx_semver_VersionComparator.GreaterThanVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                    elif (_g == "^"):
                                        if (_g1 == 1):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMajor(version)))
                                        elif (_g1 == 2):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion((thx_semver__Version_Version_Impl_.nextMinor(version) if ((python_internal_ArrayImpl._get(version.version, 0) == 0)) else thx_semver__Version_Version_Impl_.nextMajor(version))))
                                        elif (_g1 == 3):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(((thx_semver__Version_Version_Impl_.nextPatch(version) if ((python_internal_ArrayImpl._get(version.version, 1) == 0)) else thx_semver__Version_Version_Impl_.nextMinor(version)) if ((python_internal_ArrayImpl._get(version.version, 0) == 0)) else thx_semver__Version_Version_Impl_.nextMajor(version))))
                                        else:
                                            raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                    elif (_g == "="):
                                        if (_g1 == 0):
                                            return thx_semver_VersionComparator.GreaterThanOrEqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                        elif (_g1 == 1):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMajor(version)))
                                        elif (_g1 == 2):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMinor(version)))
                                        elif (_g1 == 3):
                                            return thx_semver_VersionComparator.EqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                        else:
                                            raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                    elif (_g == "v"):
                                        if (_g1 == 0):
                                            return thx_semver_VersionComparator.GreaterThanOrEqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                        elif (_g1 == 1):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMajor(version)))
                                        elif (_g1 == 2):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMinor(version)))
                                        elif (_g1 == 3):
                                            return thx_semver_VersionComparator.EqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                        else:
                                            raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                    elif (_g == "~"):
                                        if (_g1 == 1):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMajor(version)))
                                        elif ((_g1 == 3) or ((_g1 == 2))):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMinor(version)))
                                        else:
                                            raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                    else:
                                        raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                elif (_hx_local_0 == 0):
                                    if (_g == ""):
                                        if (_g1 == 0):
                                            return thx_semver_VersionComparator.GreaterThanOrEqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                        elif (_g1 == 1):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMajor(version)))
                                        elif (_g1 == 2):
                                            version = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                                            return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(version),thx_semver_VersionComparator.LessThanVersion(thx_semver__Version_Version_Impl_.nextMinor(version)))
                                        elif (_g1 == 3):
                                            return thx_semver_VersionComparator.EqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                        else:
                                            raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                    else:
                                        raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                elif (_hx_local_0 == 2):
                                    if (_g == "<="):
                                        return thx_semver_VersionComparator.LessThanOrEqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                    elif (_g == ">="):
                                        return thx_semver_VersionComparator.GreaterThanOrEqualVersion(thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion(vf),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6)))
                                    else:
                                        raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                                else:
                                    raise haxe_Exception.thrown(((("invalid prefix \"" + ("null" if _g is None else _g)) + "\" for rule ") + ("null" if comp is None else comp)))
                elif (len(p) == 2):
                    _this = thx_semver__VersionRule_VersionRule_Impl_.VERSION
                    _this.matchObj = python_lib_Re.search(_this.pattern,(p[0] if 0 < len(p) else None))
                    if (_this.matchObj is None):
                        raise haxe_Exception.thrown((("left hand parameter is not a valid version rule \"" + HxOverrides.stringOrNull((p[0] if 0 < len(p) else None))) + "\""))
                    lp = thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(1)
                    lv = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion((thx_semver__VersionRule_VersionRule_Impl_.versionArray(thx_semver__VersionRule_VersionRule_Impl_.VERSION) + [0, 0, 0])[0:3]),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                    if ((lp != ">") and ((lp != ">="))):
                        raise haxe_Exception.thrown((("invalid left parameter version prefix \"" + HxOverrides.stringOrNull((p[0] if 0 < len(p) else None))) + "\", should be either > or >="))
                    _this = thx_semver__VersionRule_VersionRule_Impl_.VERSION
                    _this.matchObj = python_lib_Re.search(_this.pattern,(p[1] if 1 < len(p) else None))
                    if (_this.matchObj is None):
                        raise haxe_Exception.thrown((("left hand parameter is not a valid version rule \"" + HxOverrides.stringOrNull((p[0] if 0 < len(p) else None))) + "\""))
                    rp = thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(1)
                    rv = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion((thx_semver__VersionRule_VersionRule_Impl_.versionArray(thx_semver__VersionRule_VersionRule_Impl_.VERSION) + [0, 0, 0])[0:3]),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                    if ((rp != "<") and ((rp != "<="))):
                        raise haxe_Exception.thrown((("invalid right parameter version prefix \"" + HxOverrides.stringOrNull((p[1] if 1 < len(p) else None))) + "\", should be either < or <="))
                    return thx_semver_VersionComparator.AndRule((thx_semver_VersionComparator.GreaterThanVersion(lv) if ((lp == ">")) else thx_semver_VersionComparator.GreaterThanOrEqualVersion(lv)),(thx_semver_VersionComparator.LessThanVersion(rv) if ((rp == "<")) else thx_semver_VersionComparator.LessThanOrEqualVersion(rv)))
                else:
                    raise haxe_Exception.thrown(("invalid multi pattern " + ("null" if comp is None else comp)))
            elif (len(p) == 2):
                _this = thx_semver__VersionRule_VersionRule_Impl_.VERSION
                _this.matchObj = python_lib_Re.search(_this.pattern,(p[0] if 0 < len(p) else None))
                if (_this.matchObj is None):
                    raise haxe_Exception.thrown((("left range parameter is not a valid version rule \"" + HxOverrides.stringOrNull((p[0] if 0 < len(p) else None))) + "\""))
                if ((thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(1) is not None) and ((thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(1) != ""))):
                    raise haxe_Exception.thrown((("left range parameter should not be prefixed \"" + HxOverrides.stringOrNull((p[0] if 0 < len(p) else None))) + "\""))
                lv = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion((thx_semver__VersionRule_VersionRule_Impl_.versionArray(thx_semver__VersionRule_VersionRule_Impl_.VERSION) + [0, 0, 0])[0:3]),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                _this = thx_semver__VersionRule_VersionRule_Impl_.VERSION
                _this.matchObj = python_lib_Re.search(_this.pattern,(p[1] if 1 < len(p) else None))
                if (_this.matchObj is None):
                    raise haxe_Exception.thrown((("right range parameter is not a valid version rule \"" + HxOverrides.stringOrNull((p[1] if 1 < len(p) else None))) + "\""))
                if ((thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(1) is not None) and ((thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(1) != ""))):
                    raise haxe_Exception.thrown((("right range parameter should not be prefixed \"" + HxOverrides.stringOrNull((p[1] if 1 < len(p) else None))) + "\""))
                rva = thx_semver__VersionRule_VersionRule_Impl_.versionArray(thx_semver__VersionRule_VersionRule_Impl_.VERSION)
                rv = thx_semver__Version_Version_Impl_.withPre(thx_semver__Version_Version_Impl_.arrayToVersion((rva + [0, 0, 0])[0:3]),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(5),thx_semver__VersionRule_VersionRule_Impl_.VERSION.matchObj.group(6))
                if (len(rva) == 1):
                    rv = thx_semver__Version_Version_Impl_.nextMajor(rv)
                elif (len(rva) == 2):
                    rv = thx_semver__Version_Version_Impl_.nextMinor(rv)
                return thx_semver_VersionComparator.AndRule(thx_semver_VersionComparator.GreaterThanOrEqualVersion(lv),(thx_semver_VersionComparator.LessThanOrEqualVersion(rv) if ((len(rva) == 3)) else thx_semver_VersionComparator.LessThanVersion(rv)))
            else:
                raise haxe_Exception.thrown((("invalid pattern \"" + ("null" if comp is None else comp)) + "\""))
        ors = list(map(_hx_local_1,s.split("||")))
        rule = None
        while (len(ors) > 0):
            r = (None if ((len(ors) == 0)) else ors.pop())
            if (None == rule):
                rule = r
            else:
                rule = thx_semver_VersionComparator.OrRule(r,rule)
        return rule

    @staticmethod
    def versionArray(re):
        arr = []
        t = None
        _g = 2
        while (_g < 5):
            i = _g
            _g = (_g + 1)
            t = re.matchObj.group(i)
            tmp = None
            if (None != t):
                _this = thx_semver__VersionRule_VersionRule_Impl_.IS_DIGITS
                _this.matchObj = python_lib_Re.search(_this.pattern,t)
                tmp = (_this.matchObj is not None)
            else:
                tmp = False
            if tmp:
                x = Std.parseInt(t)
                arr.append(x)
            else:
                break
        return arr

    @staticmethod
    def versionRuleIsValid(rule):
        try:
            return (thx_semver__VersionRule_VersionRule_Impl_.stringToVersionRule(rule) is not None)
        except BaseException as _g:
            None
            return False

    @staticmethod
    def isSatisfiedBy(this1,version):
        tmp = this1.index
        if (tmp == 0):
            return thx_semver__Version_Version_Impl_.equals(version,this1.params[0])
        elif (tmp == 1):
            return thx_semver__Version_Version_Impl_.greaterThan(version,this1.params[0])
        elif (tmp == 2):
            return thx_semver__Version_Version_Impl_.greaterThanOrEqual(version,this1.params[0])
        elif (tmp == 3):
            return thx_semver__Version_Version_Impl_.lessThan(version,this1.params[0])
        elif (tmp == 4):
            return thx_semver__Version_Version_Impl_.lessThanOrEqual(version,this1.params[0])
        elif (tmp == 5):
            if thx_semver__VersionRule_VersionRule_Impl_.isSatisfiedBy(this1.params[0],version):
                return thx_semver__VersionRule_VersionRule_Impl_.isSatisfiedBy(this1.params[1],version)
            else:
                return False
        elif (tmp == 6):
            if (not thx_semver__VersionRule_VersionRule_Impl_.isSatisfiedBy(this1.params[0],version)):
                return thx_semver__VersionRule_VersionRule_Impl_.isSatisfiedBy(this1.params[1],version)
            else:
                return True
        else:
            pass

    @staticmethod
    def toString(this1):
        tmp = this1.index
        if (tmp == 0):
            return thx_semver__Version_Version_Impl_.toString(this1.params[0])
        elif (tmp == 1):
            _g = this1.params[0]
            return (">" + HxOverrides.stringOrNull((("null" if ((_g is None)) else thx_semver__Version_Version_Impl_.toString(_g)))))
        elif (tmp == 2):
            _g = this1.params[0]
            return (">=" + HxOverrides.stringOrNull((("null" if ((_g is None)) else thx_semver__Version_Version_Impl_.toString(_g)))))
        elif (tmp == 3):
            _g = this1.params[0]
            return ("<" + HxOverrides.stringOrNull((("null" if ((_g is None)) else thx_semver__Version_Version_Impl_.toString(_g)))))
        elif (tmp == 4):
            _g = this1.params[0]
            return ("<=" + HxOverrides.stringOrNull((("null" if ((_g is None)) else thx_semver__Version_Version_Impl_.toString(_g)))))
        elif (tmp == 5):
            return ((("" + Std.string(this1.params[0])) + " ") + Std.string(this1.params[1]))
        elif (tmp == 6):
            return ((("" + Std.string(this1.params[0])) + " || ") + Std.string(this1.params[1]))
        else:
            pass
thx_semver__VersionRule_VersionRule_Impl_._hx_class = thx_semver__VersionRule_VersionRule_Impl_
_hx_classes["thx.semver._VersionRule.VersionRule_Impl_"] = thx_semver__VersionRule_VersionRule_Impl_

class thx_semver_VersionComparator(Enum):
    __slots__ = ()
    _hx_class_name = "thx.semver.VersionComparator"
    _hx_constructs = ["EqualVersion", "GreaterThanVersion", "GreaterThanOrEqualVersion", "LessThanVersion", "LessThanOrEqualVersion", "AndRule", "OrRule"]

    @staticmethod
    def EqualVersion(ver):
        return thx_semver_VersionComparator("EqualVersion", 0, (ver,))

    @staticmethod
    def GreaterThanVersion(ver):
        return thx_semver_VersionComparator("GreaterThanVersion", 1, (ver,))

    @staticmethod
    def GreaterThanOrEqualVersion(ver):
        return thx_semver_VersionComparator("GreaterThanOrEqualVersion", 2, (ver,))

    @staticmethod
    def LessThanVersion(ver):
        return thx_semver_VersionComparator("LessThanVersion", 3, (ver,))

    @staticmethod
    def LessThanOrEqualVersion(ver):
        return thx_semver_VersionComparator("LessThanOrEqualVersion", 4, (ver,))

    @staticmethod
    def AndRule(a,b):
        return thx_semver_VersionComparator("AndRule", 5, (a,b))

    @staticmethod
    def OrRule(a,b):
        return thx_semver_VersionComparator("OrRule", 6, (a,b))
thx_semver_VersionComparator._hx_class = thx_semver_VersionComparator
_hx_classes["thx.semver.VersionComparator"] = thx_semver_VersionComparator

Math.NEGATIVE_INFINITY = float("-inf")
Math.POSITIVE_INFINITY = float("inf")
Math.NaN = float("nan")
Math.PI = python_lib_Math.pi

CompileTimeClassList.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'classLists': [["pw.tales.cofdsystem,true,", "pw.tales.cofdsystem.CofDSystem,pw.tales.cofdsystem.LibVersion,pw.tales.cofdsystem.utils.registry.Registry,pw.tales.cofdsystem.TraitTypeRegistry,pw.tales.cofdsystem.action.Action,pw.tales.cofdsystem.action.NoRollAction,pw.tales.cofdsystem.action.RollAction,pw.tales.cofdsystem.action.competition.Competition,pw.tales.cofdsystem.action.competition.Contested,pw.tales.cofdsystem.action.competition.Resisted,pw.tales.cofdsystem.action.competition.builder.CompetitionBuilder,pw.tales.cofdsystem.action.events.ActionEvent,pw.tales.cofdsystem.action.events.ActionGetHandEvent,pw.tales.cofdsystem.action.events.ActionPerformedEvent,pw.tales.cofdsystem.game_object.events.GameObjectEvent,pw.tales.cofdsystem.action.events.OffhandModiferEvent,pw.tales.cofdsystem.action.events.RollActionEvent,pw.tales.cofdsystem.action.events.pool.ActionPoolEvent,pw.tales.cofdsystem.action.events.pool.ActionBuildPoolEvent,pw.tales.cofdsystem.action.events.pool.ActionBuildResistEvent,pw.tales.cofdsystem.action.events.roll.ActionRollEvent,pw.tales.cofdsystem.action.events.roll.ActionPostRollEvent,pw.tales.cofdsystem.action.events.roll.ActionPreRollEvent,pw.tales.cofdsystem.action.modifications.Offhand,pw.tales.cofdsystem.action.modifications.Willpower,pw.tales.cofdsystem.action.pool.ActionPool,pw.tales.cofdsystem.action.pool.builder.ActionPoolBuilder,pw.tales.cofdsystem.exceptions.CofDSystemException,pw.tales.cofdsystem.action.pool.exceptions.PoolNotRolledException,pw.tales.cofdsystem.action_attack.AttackAction,pw.tales.cofdsystem.action_attack.builder.AttackBuilder,pw.tales.cofdsystem.utils.EnumNamed,pw.tales.cofdsystem.action_attack.builder.EnumResistType,pw.tales.cofdsystem.action_attack.targets.Arm,pw.tales.cofdsystem.action_attack.targets.Eye,pw.tales.cofdsystem.action_attack.targets.Hand,pw.tales.cofdsystem.action_attack.targets.Head,pw.tales.cofdsystem.action_attack.targets.Heart,pw.tales.cofdsystem.action_attack.targets.Leg,pw.tales.cofdsystem.action_attack.builder.EnumSpecifiedTarget,pw.tales.cofdsystem.action_attack.builder.exceptions.AttackBuilderException,pw.tales.cofdsystem.action_attack.builder.exceptions.NoWillpowerBuilderException,pw.tales.cofdsystem.action_attack.events.AttackEvent,pw.tales.cofdsystem.action_attack.events.AttackDamageEvent,pw.tales.cofdsystem.action_attack.events.AttackDamageDealtEvent,pw.tales.cofdsystem.action_attack.events.AttackDamageGetEvent,pw.tales.cofdsystem.action_attack.events.AttackDamageGetTypeEvent,pw.tales.cofdsystem.action_attack.events.AttackStatusEvent,pw.tales.cofdsystem.action_attack.events.AttackHitEvent,pw.tales.cofdsystem.action_attack.events.AttackInitiatedEvent,pw.tales.cofdsystem.action_attack.events.AttackMissEvent,pw.tales.cofdsystem.action_attack.events.AttackSuccesesEvent,pw.tales.cofdsystem.action_attack.events.HeartPiercedEvent,pw.tales.cofdsystem.action_attack.modifications.AllOutAttack,pw.tales.cofdsystem.action_attack.modifications.SpecifiedTarget,pw.tales.cofdsystem.game_object.prefabs.Accessor,pw.tales.cofdsystem.equipment.Equipment,pw.tales.cofdsystem.armor.Armor,pw.tales.cofdsystem.armor.actions.DonAction,pw.tales.cofdsystem.game_object.prefabs.Prefab,pw.tales.cofdsystem.equipment.prefabs.EquipmentPrefab,pw.tales.cofdsystem.armor.prefabs.ArmorPrefab,pw.tales.cofdsystem.game_object.traits.Trait,pw.tales.cofdsystem.equipment.traits.EquipmentTrait,pw.tales.cofdsystem.equipment.traits.EquipmentMod,pw.tales.cofdsystem.game_object.traits.TraitType,pw.tales.cofdsystem.game_object.events.AdvantageModEvent,pw.tales.cofdsystem.utils.events.SubEventBus,pw.tales.cofdsystem.armor.traits.DefenceModifer,pw.tales.cofdsystem.armor.traits.SpeedModifer,pw.tales.cofdsystem.armor.traits.armor_rating.ArmorRating,pw.tales.cofdsystem.armor.traits.armor_rating.events.AttackArmorGetEvent,pw.tales.cofdsystem.builder.exceptions.UnknownSideException,pw.tales.cofdsystem.game_object.traits.text.TextTraitType,pw.tales.cofdsystem.character.Character,pw.tales.cofdsystem.character.advancement.experience.ExpAdvancementType,pw.tales.cofdsystem.character.advancement.experience.ExpAdvancement,pw.tales.cofdsystem.character.advancement.generation.GenAdvancementType,pw.tales.cofdsystem.character.advancement.generation.GenAdvancement,pw.tales.cofdsystem.character.advancement.generation.GenAdvancementItem,pw.tales.cofdsystem.game_object.events.CollectEvent,pw.tales.cofdsystem.character.advancement.generation.events.GenMeritCollectEvent,pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenGroupAdvancement,pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenAttributeAdvancement,pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenMeritGroupAdvancement,pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenMeritAdvancement,pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenSkillAdvancement,pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenSpecialityAdvancement,pw.tales.cofdsystem.character.advancement.generation.trait_advancements.GenWealthAdvancement,pw.tales.cofdsystem.scene.initiative.events.InitiativeEvent,pw.tales.cofdsystem.scene.initiative.events.InitiativeModifiersEvent,pw.tales.cofdsystem.utils.events.HandlerPriority,pw.tales.cofdsystem.character.traits.HeldWeapon,pw.tales.cofdsystem.character.traits.WornArmor,pw.tales.cofdsystem.character.traits.position.PositionType,pw.tales.cofdsystem.character.traits.position.PositionTrait,pw.tales.cofdsystem.character.traits.attribute.AttributePurpose,pw.tales.cofdsystem.character.traits.attribute.AttributeGroup,pw.tales.cofdsystem.game_object.traits.value_trait.ValueTraitType,pw.tales.cofdsystem.character.traits.attribute.AttributeType,pw.tales.cofdsystem.character.traits.attribute.Attributes,pw.tales.cofdsystem.character.traits.skill.SkillGroup,pw.tales.cofdsystem.character.traits.skill.SkillType,pw.tales.cofdsystem.character.traits.skill.Skills,pw.tales.cofdsystem.game_object.traits.advantages.Advantage,pw.tales.cofdsystem.game_object.traits.advantages.AdvantageExpression,pw.tales.cofdsystem.dices.pool.builder.PoolBuilder,pw.tales.cofdsystem.dices.pool.builder.PBTrait,pw.tales.cofdsystem.dices.pool.builder.PBBinary,pw.tales.cofdsystem.dices.pool.builder.PBMin,pw.tales.cofdsystem.utils.math.MathBinaryOperation,pw.tales.cofdsystem.utils.math.MathMin,pw.tales.cofdsystem.character.traits.advantages.DefenceAdvantage,pw.tales.cofdsystem.game_object.traits.advantages.AdvantageValue,pw.tales.cofdsystem.game_object.traits.advantages.SizeAdvantage,pw.tales.cofdsystem.game_object.health_helper.GetHealthTraitEvent,pw.tales.cofdsystem.character.traits.advantages.health.HealthAdvantage,pw.tales.cofdsystem.character.traits.advantages.InitiativeAdvantage,pw.tales.cofdsystem.character.traits.advantages.IntegrityAdvantage,pw.tales.cofdsystem.dices.pool.builder.PBValue,pw.tales.cofdsystem.character.traits.advantages.SpeedAdvantage,pw.tales.cofdsystem.character.traits.advantages.willpower.WillpowerAdvantage,pw.tales.cofdsystem.character.traits.advantages.WealthAdvantage,pw.tales.cofdsystem.character.prefabs.HumanPrefab,pw.tales.cofdsystem.character.prefabs.PlayerPrefab,pw.tales.cofdsystem.character.traits.Experience,pw.tales.cofdsystem.character.traits.advantages.health.events.GameObjectDamagedEvent,pw.tales.cofdsystem.character.traits.advantages.health.events.GameObjectDiedEvent,pw.tales.cofdsystem.game_object.exceptions.GameObjectException,pw.tales.cofdsystem.game_object.exceptions.TraitException,pw.tales.cofdsystem.character.traits.advantages.willpower.exceptions.NoWillpowerException,pw.tales.cofdsystem.game_object.traits.text.TextTrait,pw.tales.cofdsystem.character.traits.aspiration.Aspiration,pw.tales.cofdsystem.character.traits.aspiration.AspirationType,pw.tales.cofdsystem.character.traits.aspiration.Aspirations,pw.tales.cofdsystem.character.traits.aspiration.events.AspirationsCollectEvent,pw.tales.cofdsystem.game_object.traits.value_trait.ValueTrait,pw.tales.cofdsystem.character.traits.attribute.Attribute,pw.tales.cofdsystem.character.traits.condition.Condition,pw.tales.cofdsystem.character.traits.condition.Conditions,pw.tales.cofdsystem.character.traits.condition.events.ConditionsCollectEvent,pw.tales.cofdsystem.character.traits.merits.MeritType,pw.tales.cofdsystem.character.traits.merits.Merit,pw.tales.cofdsystem.character.traits.merits.Merits,pw.tales.cofdsystem.character.traits.merits.ambidextrous.AmbidextrousMeritType,pw.tales.cofdsystem.character.traits.merits.ambidextrous.AmbidextrousMerit,pw.tales.cofdsystem.character.traits.merits.events.MeritsCollectEvent,pw.tales.cofdsystem.character.traits.merits.fleet_of_foot.FleetOfFootType,pw.tales.cofdsystem.character.traits.merits.fleet_of_foot.FleetOfFootMerit,pw.tales.cofdsystem.character.traits.merits.giant.GiantMeritType,pw.tales.cofdsystem.character.traits.merits.giant.GiantMerit,pw.tales.cofdsystem.character.traits.merits.small_framed.SmallFramedType,pw.tales.cofdsystem.character.traits.merits.small_framed.SmallFramedMerit,pw.tales.cofdsystem.character.traits.position.Position,pw.tales.cofdsystem.character.traits.position.PositionProvider,pw.tales.cofdsystem.character.traits.skill.Skill,pw.tales.cofdsystem.character.traits.skill.events.SkillCollectEvent,pw.tales.cofdsystem.character.traits.skill.events.SkillGroupCollectEvent,pw.tales.cofdsystem.character.traits.speciality.Specialities,pw.tales.cofdsystem.character.traits.speciality.events.SpecialitiesCollectEvent,pw.tales.cofdsystem.character.traits.speciality.Speciality,pw.tales.cofdsystem.character.traits.tilts.Tilt,pw.tales.cofdsystem.scene.events.SceneEvent,pw.tales.cofdsystem.scene.events.SceneEndEvent,pw.tales.cofdsystem.character.traits.tilts.events.TiltsCollectEvent,pw.tales.cofdsystem.character.traits.tilts.ArmWrackTilt,pw.tales.cofdsystem.character.traits.tilts.BlindedTilt,pw.tales.cofdsystem.character.traits.tilts.LegWrackTilt,pw.tales.cofdsystem.character.traits.tilts.StunnedTilt,pw.tales.cofdsystem.character.traits.tilts.Tilts,pw.tales.cofdsystem.common.EnumHand,pw.tales.cofdsystem.common.EnumRange,pw.tales.cofdsystem.common.EnumSide,pw.tales.cofdsystem.damage.Damage,pw.tales.cofdsystem.damage._DamageType.DamageType_Impl_,pw.tales.cofdsystem.damage.DamageUtil,pw.tales.cofdsystem.dices.DiceRoller,pw.tales.cofdsystem.dices.EnumExplode,pw.tales.cofdsystem.dices.EnumResult,pw.tales.cofdsystem.dices.RollRequest,pw.tales.cofdsystem.dices.RollResponse,pw.tales.cofdsystem.dices.pool.builder.PBSum,pw.tales.cofdsystem.dices.pool.math.PoolTrait,pw.tales.cofdsystem.dices.requests.ABSRollRequest,pw.tales.cofdsystem.dices.requests.RollRequestPool,pw.tales.cofdsystem.dices.requests.RollRequestTrait,pw.tales.cofdsystem.equipment.events.StrengthReqEvent,pw.tales.cofdsystem.equipment.traits.EquipmentBonus,pw.tales.cofdsystem.equipment.traits.Equippable,pw.tales.cofdsystem.equipment.traits.HoldingHand,pw.tales.cofdsystem.equipment.traits.StrengthReq,pw.tales.cofdsystem.game_object.GameObject,pw.tales.cofdsystem.game_object.TraitTracker,pw.tales.cofdsystem.game_object.events.TraitAddEvent,pw.tales.cofdsystem.game_object.events.TraitRemoveEvent,pw.tales.cofdsystem.game_object.events.tracker.TrackerEvent,pw.tales.cofdsystem.game_object.events.tracker.TrackerClearedEvent,pw.tales.cofdsystem.game_object.events.tracker.TrackerTrackEvent,pw.tales.cofdsystem.game_object.events.traits.TraitEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPreEvent,pw.tales.cofdsystem.game_object.events.traits.TraitCancellablePreEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPostEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPostChangeEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPostAttachEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPostDeserializeEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPostRemoveEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPostUpdateEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPreAttachEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPreRemoveEvent,pw.tales.cofdsystem.game_object.events.traits.TraitPreUpdateEvent,pw.tales.cofdsystem.game_object.health_helper.HealthTraitHelper,pw.tales.cofdsystem.game_object.health_helper.NoHealthTraitException,pw.tales.cofdsystem.game_object.prefabs.AccessorException,pw.tales.cofdsystem.game_object.prefabs.exceptions.NoTraitAccessorException,pw.tales.cofdsystem.game_object.trait_manager.TraitManager,pw.tales.cofdsystem.game_object.trait_manager.exceptions.CreationRejectedException,pw.tales.cofdsystem.game_object.trait_manager.exceptions.MITraitAddException,pw.tales.cofdsystem.game_object.trait_manager.exceptions.MITraitFetchException,pw.tales.cofdsystem.game_object.trait_manager.exceptions.RemoveRejectedException,pw.tales.cofdsystem.game_object.trait_manager.exceptions.WrongTypeException,pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownType,pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownTrait,pw.tales.cofdsystem.game_object.traits.unknown_trait.UnknownTraits,pw.tales.cofdsystem.game_object.traits.unknown_trait.events.UnknownTraitsCollectEvent,pw.tales.cofdsystem.game_object.traits.value_trait.events.ValueTraitUpdateEvent,pw.tales.cofdsystem.game_object.traits.value_trait.exceptions.UpdateRejectedException,pw.tales.cofdsystem.parser.ParserHelper,pw.tales.cofdsystem.parser.exception.ParsingException,pw.tales.cofdsystem.parser.nodes.NodeAnd,pw.tales.cofdsystem.parser.nodes.NodeNumber,pw.tales.cofdsystem.parser.nodes.NodeDots,pw.tales.cofdsystem.parser.nodes.NodeDotsOr,pw.tales.cofdsystem.parser.nodes.NodeDotsRange,pw.tales.cofdsystem.parser.nodes.NodeGroup,pw.tales.cofdsystem.parser.nodes.NodeInversion,pw.tales.cofdsystem.parser.nodes.NodeOr,pw.tales.cofdsystem.parser.nodes.NodePoolSum,pw.tales.cofdsystem.parser.nodes.NodeString,pw.tales.cofdsystem.parser.nodes.NodeTrait,pw.tales.cofdsystem.parser.nodes.NodeTraitRequirement,pw.tales.cofdsystem.parser.parsers.DotsLevelsParser,pw.tales.cofdsystem.parser.parsers.ParserPool,pw.tales.cofdsystem.parser.parsers.RequirementsParser,pw.tales.cofdsystem.scene.Scene,pw.tales.cofdsystem.scene.events.SceneStartEvent,pw.tales.cofdsystem.scene.initiative.Initiative,pw.tales.cofdsystem.scene.initiative.events.InitiativeUpdateEvent,pw.tales.cofdsystem.scene.initiative.exceptions.InitiativeException,pw.tales.cofdsystem.scene.initiative.exceptions.AddedAgainException,pw.tales.cofdsystem.scene.initiative.exceptions.ParticipantNotFoundException,pw.tales.cofdsystem.scene.turns.Turns,pw.tales.cofdsystem.scene.turns.events.TurnsEvent,pw.tales.cofdsystem.scene.turns.events.TurnEvent,pw.tales.cofdsystem.scene.turns.events.TurnEndEvent,pw.tales.cofdsystem.scene.turns.events.TurnStartEvent,pw.tales.cofdsystem.synchronization.api.APIStorage,pw.tales.cofdsystem.synchronization.api.GameObjectStorage,pw.tales.cofdsystem.synchronization.api.SystemStorage,pw.tales.cofdsystem.synchronization.serialization.Serialization,pw.tales.cofdsystem.synchronization.serialization.game_object.GameObjectSerialization,pw.tales.cofdsystem.synchronization.serialization.system.parts.AbilitySerialization,pw.tales.cofdsystem.synchronization.serialization.system.parts.ConditionSerialization,pw.tales.cofdsystem.synchronization.serialization.system.parts.TiltSerialization,pw.tales.cofdsystem.synchronization.serialization.system.parts.ArmorSerialization,pw.tales.cofdsystem.synchronization.serialization.system.parts.MeleeSerialization,pw.tales.cofdsystem.synchronization.serialization.system.parts.RangedSerialization,pw.tales.cofdsystem.synchronization.serialization.system.parts.TagSerialization,pw.tales.cofdsystem.synchronization.serialization.system.SystemSerialization,pw.tales.cofdsystem.synchronization.serialization.system.exceptions.VersionMissmatchException,pw.tales.cofdsystem.utils.Utility,pw.tales.cofdsystem.utils.events.EventBus,pw.tales.cofdsystem.utils.events.EventHandlerRecord,pw.tales.cofdsystem.utils.logger.ABCLogger,pw.tales.cofdsystem.utils.logger.TraceLogger,pw.tales.cofdsystem.utils.logger.LoggerManager,pw.tales.cofdsystem.utils.math.MathAnd,pw.tales.cofdsystem.utils.math.MathMax,pw.tales.cofdsystem.utils.math.MathMore,pw.tales.cofdsystem.utils.math.MathUnaryOperation,pw.tales.cofdsystem.utils.math.MathNegation,pw.tales.cofdsystem.utils.math.MathOr,pw.tales.cofdsystem.utils.math.MathSubtraction,pw.tales.cofdsystem.utils.math.MathSum,pw.tales.cofdsystem.utils.math.MathValue,pw.tales.cofdsystem.utils.registry.exceptions.OverwriteForbiddenException,pw.tales.cofdsystem.utils.serialization.AnnotationSerialization,pw.tales.cofdsystem.utils.serialization.DeserializationException,pw.tales.cofdsystem.weapon.Weapon,pw.tales.cofdsystem.weapon.actions.PickAction,pw.tales.cofdsystem.weapon.prefabs.WeaponPrefab,pw.tales.cofdsystem.weapon.traits.WeaponTrait,pw.tales.cofdsystem.weapon.traits.WeaponMod,pw.tales.cofdsystem.weapon.traits.DamageMod,pw.tales.cofdsystem.weapon.traits.InitiativeMod,pw.tales.cofdsystem.weapon.traits.LethalDamage,pw.tales.cofdsystem.weapon.traits.weapon_tags.WeaponTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.events.WeaponTagsCollectEvent,pw.tales.cofdsystem.weapon.traits.weapon_tags.AccurateTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.BrawlTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.ConcealedTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.ExplodeTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.EightAgainTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.FinesseTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.GrappleTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.GuardTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.MercyTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.NineAgainTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.ReachTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.StunTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.TwoHandedTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.WeaponTags,pw.tales.cofdsystem.weapon.traits.weapon_tags.piercing.PiercingTag,pw.tales.cofdsystem.weapon.traits.weapon_tags.piercing.PiercingTagType,pw.tales.cofdsystem.weapon_melee.prefabs.MeleeWeaponPrefab,pw.tales.cofdsystem.weapon_melee.traits.MeleeWeapon,pw.tales.cofdsystem.weapon_ranged.events.RangedWeaponDefenceEvent,pw.tales.cofdsystem.weapon_ranged.prefabs.RangedWeaponPrefab,pw.tales.cofdsystem.weapon_ranged.traits.RangedWeapon"]]})})
CompileTimeClassList.lists = None
pw_tales_cofdsystem_CofDSystem.VERSION = "0.0.0-dev"
pw_tales_cofdsystem_CofDSystem.VERSION_CHECK = False
pw_tales_cofdsystem_TraitTypeRegistry.AUTOREGISTER_ANNOTATION = "RegisterTraitTypes"
pw_tales_cofdsystem_action_modifications_Offhand.DN = "offhand"
pw_tales_cofdsystem_action_pool_builder_ActionPoolBuilder.CUSTOM_MODIFIER = "Модификатор"
pw_tales_cofdsystem_action_attack_builder_EnumResistType.VALUES = haxe_ds_StringMap()
pw_tales_cofdsystem_action_attack_builder_EnumResistType.DEFAULT = pw_tales_cofdsystem_action_attack_builder_EnumResistType("default")
pw_tales_cofdsystem_action_attack_builder_EnumResistType.DODGE = pw_tales_cofdsystem_action_attack_builder_EnumResistType("dodge")
pw_tales_cofdsystem_action_attack_builder_EnumResistType.NO_DEFENCE = pw_tales_cofdsystem_action_attack_builder_EnumResistType("no_defence")
pw_tales_cofdsystem_action_attack_targets_Arm.INSTANCE = pw_tales_cofdsystem_action_attack_targets_Arm()
pw_tales_cofdsystem_action_attack_targets_Eye.INSTANCE = pw_tales_cofdsystem_action_attack_targets_Eye()
pw_tales_cofdsystem_action_attack_targets_Hand.INSTANCE = pw_tales_cofdsystem_action_attack_targets_Hand()
pw_tales_cofdsystem_action_attack_targets_Head.INSTANCE = pw_tales_cofdsystem_action_attack_targets_Head()
pw_tales_cofdsystem_action_attack_targets_Heart.INSTANCE = pw_tales_cofdsystem_action_attack_targets_Heart()
pw_tales_cofdsystem_action_attack_targets_Leg.INSTANCE = pw_tales_cofdsystem_action_attack_targets_Leg()
pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.VALUES = haxe_ds_StringMap()
pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.ARM = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget(pw_tales_cofdsystem_action_attack_targets_Arm.INSTANCE)
pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.LEG = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget(pw_tales_cofdsystem_action_attack_targets_Leg.INSTANCE)
pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.HEAD = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget(pw_tales_cofdsystem_action_attack_targets_Head.INSTANCE)
pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.HEART = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget(pw_tales_cofdsystem_action_attack_targets_Heart.INSTANCE)
pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.HAND = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget(pw_tales_cofdsystem_action_attack_targets_Hand.INSTANCE)
pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget.EYE = pw_tales_cofdsystem_action_attack_builder_EnumSpecifiedTarget(pw_tales_cofdsystem_action_attack_targets_Eye.INSTANCE)
pw_tales_cofdsystem_action_attack_modifications_AllOutAttack.DN = "all_out"
pw_tales_cofdsystem_action_attack_modifications_SpecifiedTarget.DN = "specified_attack"
pw_tales_cofdsystem_game_object_traits_Trait.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'dn': _hx_AnonObject({'Serialize': ["dn"]})})})
pw_tales_cofdsystem_equipment_traits_EquipmentMod.__meta__ = _hx_AnonObject({'fields': _hx_AnonObject({'value': _hx_AnonObject({'Serialize': ["value"]})})})
def _hx_init_pw_tales_cofdsystem_utils_events_SubEventBus_NO_FILTER():
    def _hx_local_0(event):
        return True
    return _hx_local_0
pw_tales_cofdsystem_utils_events_SubEventBus.NO_FILTER = _hx_init_pw_tales_cofdsystem_utils_events_SubEventBus_NO_FILTER()
pw_tales_cofdsystem_armor_traits_DefenceModifer.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_armor_traits_DefenceModifer.DN = "Свойство:Defense"
def _hx_init_pw_tales_cofdsystem_armor_traits_DefenceModifer_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_armor_traits_DefenceModifer(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_armor_traits_DefenceModifer.DN,_hx_local_0)
pw_tales_cofdsystem_armor_traits_DefenceModifer.TYPE = _hx_init_pw_tales_cofdsystem_armor_traits_DefenceModifer_TYPE()
pw_tales_cofdsystem_armor_traits_SpeedModifer.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_armor_traits_SpeedModifer.DN = "Свойство:Speed"
def _hx_init_pw_tales_cofdsystem_armor_traits_SpeedModifer_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_armor_traits_SpeedModifer(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_armor_traits_SpeedModifer.DN,_hx_local_0)
pw_tales_cofdsystem_armor_traits_SpeedModifer.TYPE = _hx_init_pw_tales_cofdsystem_armor_traits_SpeedModifer_TYPE()
pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'general': _hx_AnonObject({'Serialize': ["general"]}), 'ballistic': _hx_AnonObject({'Serialize': ["ballistic"]})})})
pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating.DN = "Свойство:Rating"
def _hx_init_pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating.DN,_hx_local_0)
pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating.TYPE = _hx_init_pw_tales_cofdsystem_armor_traits_armor_rating_ArmorRating_TYPE()
pw_tales_cofdsystem_character_Character.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_Character.NAME = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Name")
pw_tales_cofdsystem_character_Character.AGE = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Age")
pw_tales_cofdsystem_character_Character.PLAYER = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Player")
pw_tales_cofdsystem_character_Character.RACE = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Race")
pw_tales_cofdsystem_character_Character.NATION = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Nation")
pw_tales_cofdsystem_character_Character.LANGUAGE = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Language")
pw_tales_cofdsystem_character_Character.VIRTUE = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Добродетель")
pw_tales_cofdsystem_character_Character.VICE = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Порок")
pw_tales_cofdsystem_character_Character.CONCEPT = pw_tales_cofdsystem_game_object_traits_text_TextTraitType("Концепт")
pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement.DN = "experience_advancement"
pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement.TYPE = pw_tales_cofdsystem_character_advancement_experience_ExpAdvancementType(pw_tales_cofdsystem_character_advancement_experience_ExpAdvancement.DN)
pw_tales_cofdsystem_character_advancement_generation_GenAdvancement.DN = "generation_advancement"
pw_tales_cofdsystem_character_advancement_generation_GenAdvancement.TYPE = pw_tales_cofdsystem_character_advancement_generation_GenAdvancementType(pw_tales_cofdsystem_character_advancement_generation_GenAdvancement.DN)
pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenAttributeAdvancement.FREEBUYS = [5, 4, 3]
pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenMeritGroupAdvancement.MERIT_GENERATION_LIMIT = 10
pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSkillAdvancement.FREEBUYS = [11, 7, 4]
pw_tales_cofdsystem_character_advancement_generation_trait_advancements_GenSpecialityAdvancement.SPECIALITY_GENERATION_LIMIT = 3
pw_tales_cofdsystem_utils_events_HandlerPriority.LOWEST = 0
pw_tales_cofdsystem_utils_events_HandlerPriority.LOW = 25
pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL = 50
pw_tales_cofdsystem_utils_events_HandlerPriority.HIGH = 75
pw_tales_cofdsystem_utils_events_HandlerPriority.HIGHEST = 100
pw_tales_cofdsystem_character_traits_HeldWeapon.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_HeldWeapon.DN = "weapon"
def _hx_init_pw_tales_cofdsystem_character_traits_HeldWeapon_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_HeldWeapon(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_HeldWeapon.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_HeldWeapon.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_HeldWeapon_TYPE()
pw_tales_cofdsystem_character_traits_WornArmor.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_WornArmor.DN = "worn_armor"
def _hx_init_pw_tales_cofdsystem_character_traits_WornArmor_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_WornArmor(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_WornArmor.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_WornArmor.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_WornArmor_TYPE()
pw_tales_cofdsystem_character_traits_position_PositionTrait.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_position_PositionTrait.DN = "position"
pw_tales_cofdsystem_character_traits_position_PositionTrait.TYPE = pw_tales_cofdsystem_character_traits_position_PositionType(pw_tales_cofdsystem_character_traits_position_PositionTrait.DN)
pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.VALUES = haxe_ds_StringMap()
pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.POWER = pw_tales_cofdsystem_character_traits_attribute_AttributePurpose("power")
pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.FINESSE = pw_tales_cofdsystem_character_traits_attribute_AttributePurpose("finesse")
pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.RESISTANCE = pw_tales_cofdsystem_character_traits_attribute_AttributePurpose("resistance")
pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.VALUES = haxe_ds_StringMap()
pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.MENTAL = pw_tales_cofdsystem_character_traits_attribute_AttributeGroup("mental")
pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.PHYSICAL = pw_tales_cofdsystem_character_traits_attribute_AttributeGroup("physical")
pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.SOCIAL = pw_tales_cofdsystem_character_traits_attribute_AttributeGroup("social")
pw_tales_cofdsystem_character_traits_attribute_AttributeType.STARTING_VALUE = 1
pw_tales_cofdsystem_character_traits_attribute_Attributes.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_attribute_Attributes.INTELLIGENCE = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Интеллект",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.POWER,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.MENTAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.WITS = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Смекалка",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.FINESSE,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.MENTAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.RESOLVE = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Концентрация",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.RESISTANCE,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.MENTAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.STRENGTH = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Сила",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.POWER,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.DEXTERITY = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Ловкость",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.FINESSE,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.STAMINA = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Выносливость",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.RESISTANCE,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.PRESENCE = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Харизма",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.POWER,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.MANIPULATION = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Манипулирование",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.FINESSE,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_attribute_Attributes.COMPOSURE = pw_tales_cofdsystem_character_traits_attribute_AttributeType("Хладнокровие",pw_tales_cofdsystem_character_traits_attribute_AttributePurpose.RESISTANCE,pw_tales_cofdsystem_character_traits_attribute_AttributeGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_SkillGroup.VALUES = haxe_ds_StringMap()
pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL = pw_tales_cofdsystem_character_traits_skill_SkillGroup("mental",-3)
pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL = pw_tales_cofdsystem_character_traits_skill_SkillGroup("physical",-1)
pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL = pw_tales_cofdsystem_character_traits_skill_SkillGroup("social",-1)
pw_tales_cofdsystem_character_traits_skill_Skills.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_skill_Skills.ACADEMICS = pw_tales_cofdsystem_character_traits_skill_SkillType("Эрудиция",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.ENIGMAS = pw_tales_cofdsystem_character_traits_skill_SkillType("Загадки",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.CRAFTS = pw_tales_cofdsystem_character_traits_skill_SkillType("Ремесло",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.INVESTIGATION = pw_tales_cofdsystem_character_traits_skill_SkillType("Расследование",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.MEDICINE = pw_tales_cofdsystem_character_traits_skill_SkillType("Медицина",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.OCCULT = pw_tales_cofdsystem_character_traits_skill_SkillType("Оккультизм",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.POLITICS = pw_tales_cofdsystem_character_traits_skill_SkillType("Политика",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.SCIENCE = pw_tales_cofdsystem_character_traits_skill_SkillType("Наука",pw_tales_cofdsystem_character_traits_skill_SkillGroup.MENTAL)
pw_tales_cofdsystem_character_traits_skill_Skills.ATHLETICS = pw_tales_cofdsystem_character_traits_skill_SkillType("Атлетика",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.BRAWL = pw_tales_cofdsystem_character_traits_skill_SkillType("Борьба",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.RIDE = pw_tales_cofdsystem_character_traits_skill_SkillType("Верховая езда",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.SHOOTING = pw_tales_cofdsystem_character_traits_skill_SkillType("Стрельба",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.LARCENY = pw_tales_cofdsystem_character_traits_skill_SkillType("Кража",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.STEALTH = pw_tales_cofdsystem_character_traits_skill_SkillType("Скрытность",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.SURVIVAL = pw_tales_cofdsystem_character_traits_skill_SkillType("Выживание",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.WEAPONRY = pw_tales_cofdsystem_character_traits_skill_SkillType("Холодное оружие",pw_tales_cofdsystem_character_traits_skill_SkillGroup.PHYSICAL)
pw_tales_cofdsystem_character_traits_skill_Skills.ANIMAL_KEN = pw_tales_cofdsystem_character_traits_skill_SkillType("Знание_животных",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_Skills.EMPATHY = pw_tales_cofdsystem_character_traits_skill_SkillType("Эмпатия",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_Skills.EXPRESSION = pw_tales_cofdsystem_character_traits_skill_SkillType("Самовыражение",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_Skills.INTIMIDATION = pw_tales_cofdsystem_character_traits_skill_SkillType("Запугивание",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_Skills.PERSUASION = pw_tales_cofdsystem_character_traits_skill_SkillType("Убеждение",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_Skills.SOCIALIZE = pw_tales_cofdsystem_character_traits_skill_SkillType("Социализация",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_Skills.STREETWISE = pw_tales_cofdsystem_character_traits_skill_SkillType("Знание улиц",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_skill_Skills.SUBTERFUGE = pw_tales_cofdsystem_character_traits_skill_SkillType("Обман",pw_tales_cofdsystem_character_traits_skill_SkillGroup.SOCIAL)
pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.DN = "Защита"
def _hx_init_pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage_TYPE()
pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.EXPR = pw_tales_cofdsystem_dices_pool_builder_PBMin(pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.DEXTERITY.getDN()),pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.WITS.getDN())).plus(pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_skill_Skills.ATHLETICS.getDN()))
pw_tales_cofdsystem_game_object_traits_advantages_AdvantageValue.__meta__ = _hx_AnonObject({'fields': _hx_AnonObject({'value': _hx_AnonObject({'Optional': None, 'Serialize': ["value"]})})})
pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.DN = "Размер"
def _hx_init_pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage_TYPE()
pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'bashing': _hx_AnonObject({'Serialize': ["bashing"]}), 'lethal': _hx_AnonObject({'Serialize': ["lethal"]}), 'aggravated': _hx_AnonObject({'Serialize': ["aggravated"]})})})
pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.DN = "Здоровье"
def _hx_init_pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage_TYPE()
pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.EXPR = pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.DN).plus(pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.STAMINA.getDN()))
pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage.DN = "Модификатор_Инициативы"
def _hx_init_pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage_TYPE()
pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage.EXPR = pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.DEXTERITY.getDN()).plus(pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.COMPOSURE.getDN()))
pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'points': _hx_AnonObject({'Serialize': ["points"]})})})
pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage.DN = "Целостность"
def _hx_init_pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage_TYPE()
pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.DN = "Скорость"
def _hx_init_pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage_TYPE()
pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.EXPR = pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.STRENGTH.getDN()).plus(pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.DEXTERITY.getDN())).plus(pw_tales_cofdsystem_dices_pool_builder_PBValue(5))
pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'points': _hx_AnonObject({'Serialize': ["points"]})})})
pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.DN = "Сила_воли"
def _hx_init_pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage_TYPE()
pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.EXPR = pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.RESOLVE.getDN()).plus(pw_tales_cofdsystem_dices_pool_builder_PBTrait(pw_tales_cofdsystem_character_traits_attribute_Attributes.COMPOSURE.getDN()))
pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'points': _hx_AnonObject({'Serialize': ["points"]})})})
pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage.DN = "Богатство"
def _hx_init_pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage_TYPE()
pw_tales_cofdsystem_character_prefabs_HumanPrefab.INSTANCE = pw_tales_cofdsystem_character_prefabs_HumanPrefab("human")
pw_tales_cofdsystem_character_prefabs_HumanPrefab.TRAITS = [pw_tales_cofdsystem_character_traits_HeldWeapon.TYPE, pw_tales_cofdsystem_character_traits_WornArmor.TYPE, pw_tales_cofdsystem_character_traits_position_PositionTrait.TYPE, pw_tales_cofdsystem_character_Character.NAME, pw_tales_cofdsystem_character_Character.AGE, pw_tales_cofdsystem_character_Character.PLAYER, pw_tales_cofdsystem_character_Character.RACE, pw_tales_cofdsystem_character_Character.NATION, pw_tales_cofdsystem_character_Character.LANGUAGE, pw_tales_cofdsystem_character_Character.VIRTUE, pw_tales_cofdsystem_character_Character.VICE, pw_tales_cofdsystem_character_Character.CONCEPT, pw_tales_cofdsystem_character_traits_attribute_Attributes.INTELLIGENCE, pw_tales_cofdsystem_character_traits_attribute_Attributes.WITS, pw_tales_cofdsystem_character_traits_attribute_Attributes.RESOLVE, pw_tales_cofdsystem_character_traits_attribute_Attributes.STRENGTH, pw_tales_cofdsystem_character_traits_attribute_Attributes.DEXTERITY, pw_tales_cofdsystem_character_traits_attribute_Attributes.STAMINA, pw_tales_cofdsystem_character_traits_attribute_Attributes.PRESENCE, pw_tales_cofdsystem_character_traits_attribute_Attributes.MANIPULATION, pw_tales_cofdsystem_character_traits_attribute_Attributes.COMPOSURE, pw_tales_cofdsystem_character_traits_skill_Skills.ACADEMICS, pw_tales_cofdsystem_character_traits_skill_Skills.ENIGMAS, pw_tales_cofdsystem_character_traits_skill_Skills.CRAFTS, pw_tales_cofdsystem_character_traits_skill_Skills.INVESTIGATION, pw_tales_cofdsystem_character_traits_skill_Skills.MEDICINE, pw_tales_cofdsystem_character_traits_skill_Skills.OCCULT, pw_tales_cofdsystem_character_traits_skill_Skills.POLITICS, pw_tales_cofdsystem_character_traits_skill_Skills.SCIENCE, pw_tales_cofdsystem_character_traits_skill_Skills.ATHLETICS, pw_tales_cofdsystem_character_traits_skill_Skills.BRAWL, pw_tales_cofdsystem_character_traits_skill_Skills.RIDE, pw_tales_cofdsystem_character_traits_skill_Skills.SHOOTING, pw_tales_cofdsystem_character_traits_skill_Skills.LARCENY, pw_tales_cofdsystem_character_traits_skill_Skills.STEALTH, pw_tales_cofdsystem_character_traits_skill_Skills.SURVIVAL, pw_tales_cofdsystem_character_traits_skill_Skills.WEAPONRY, pw_tales_cofdsystem_character_traits_skill_Skills.ANIMAL_KEN, pw_tales_cofdsystem_character_traits_skill_Skills.EMPATHY, pw_tales_cofdsystem_character_traits_skill_Skills.EXPRESSION, pw_tales_cofdsystem_character_traits_skill_Skills.INTIMIDATION, pw_tales_cofdsystem_character_traits_skill_Skills.PERSUASION, pw_tales_cofdsystem_character_traits_skill_Skills.SOCIALIZE, pw_tales_cofdsystem_character_traits_skill_Skills.STREETWISE, pw_tales_cofdsystem_character_traits_skill_Skills.SUBTERFUGE, pw_tales_cofdsystem_character_traits_advantages_DefenceAdvantage.TYPE, pw_tales_cofdsystem_character_traits_advantages_health_HealthAdvantage.TYPE, pw_tales_cofdsystem_character_traits_advantages_InitiativeAdvantage.TYPE, pw_tales_cofdsystem_character_traits_advantages_IntegrityAdvantage.TYPE, pw_tales_cofdsystem_game_object_traits_advantages_SizeAdvantage.TYPE, pw_tales_cofdsystem_character_traits_advantages_SpeedAdvantage.TYPE, pw_tales_cofdsystem_character_traits_advantages_willpower_WillpowerAdvantage.TYPE, pw_tales_cofdsystem_character_traits_advantages_WealthAdvantage.TYPE]
pw_tales_cofdsystem_character_prefabs_PlayerPrefab.INSTANCE = pw_tales_cofdsystem_character_prefabs_PlayerPrefab("player")
pw_tales_cofdsystem_character_traits_Experience.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'beats': _hx_AnonObject({'Serialize': ["beats"]}), 'spent': _hx_AnonObject({'Serialize': ["spent"]})})})
pw_tales_cofdsystem_character_traits_Experience.DN = "Опыт"
def _hx_init_pw_tales_cofdsystem_character_traits_Experience_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_Experience(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_Experience.DN,_hx_local_0)
pw_tales_cofdsystem_character_traits_Experience.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_Experience_TYPE()
pw_tales_cofdsystem_character_traits_Experience.BEAT_AMOUNT = 5
pw_tales_cofdsystem_game_object_traits_text_TextTrait.__meta__ = _hx_AnonObject({'fields': _hx_AnonObject({'value': _hx_AnonObject({'Serialize': ["value"]})})})
pw_tales_cofdsystem_character_traits_aspiration_Aspiration.__meta__ = _hx_AnonObject({'fields': _hx_AnonObject({'description': _hx_AnonObject({'Optional': None, 'Serialize': ["description"]})})})
pw_tales_cofdsystem_character_traits_aspiration_Aspirations.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_aspiration_Aspirations.TYPE = pw_tales_cofdsystem_character_traits_aspiration_AspirationType("Стремление")
pw_tales_cofdsystem_character_traits_aspiration_Aspirations.SHORT_TERM_TYPE = pw_tales_cofdsystem_character_traits_aspiration_AspirationType("Краткосрочное_Стремление")
pw_tales_cofdsystem_character_traits_aspiration_Aspirations.LONG_TERM_TYPE = pw_tales_cofdsystem_character_traits_aspiration_AspirationType("Долгосрочное_Стремление")
pw_tales_cofdsystem_game_object_traits_value_trait_ValueTrait.__meta__ = _hx_AnonObject({'fields': _hx_AnonObject({'value': _hx_AnonObject({'Serialize': ["value"]})})})
pw_tales_cofdsystem_character_traits_attribute_Attribute.STARTING_VALUE = 1
pw_tales_cofdsystem_character_traits_condition_Condition.__meta__ = _hx_AnonObject({'fields': _hx_AnonObject({'customName': _hx_AnonObject({'Optional': None, 'Serialize': ["customName"]}), 'description': _hx_AnonObject({'Optional': None, 'Serialize': ["description"]})})})
pw_tales_cofdsystem_character_traits_merits_Merit.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'customName': _hx_AnonObject({'Optional': None, 'Serialize': ["customName"]}), 'description': _hx_AnonObject({'Optional': None, 'Serialize': ["description"]})})})
pw_tales_cofdsystem_character_traits_merits_Merit.CUSTOM_MERIT_TYPE = pw_tales_cofdsystem_character_traits_merits_MeritType("Custom_Merit")
pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMerit.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMerit.TYPE = pw_tales_cofdsystem_character_traits_merits_ambidextrous_AmbidextrousMeritType("Ambidextrous")
pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootMerit.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootMerit.TYPE = pw_tales_cofdsystem_character_traits_merits_fleet_of_foot_FleetOfFootType("Fleet_of_Foot")
pw_tales_cofdsystem_character_traits_merits_giant_GiantMerit.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_merits_giant_GiantMerit.TYPE = pw_tales_cofdsystem_character_traits_merits_giant_GiantMeritType("Giant")
pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedMerit.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedMerit.TYPE = pw_tales_cofdsystem_character_traits_merits_small_framed_SmallFramedType("Small_Framed")
pw_tales_cofdsystem_character_traits_speciality_Speciality.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None}), 'fields': _hx_AnonObject({'name': _hx_AnonObject({'Serialize': ["name"]}), 'skillDn': _hx_AnonObject({'Serialize': ["skill"]})})})
pw_tales_cofdsystem_character_traits_speciality_Speciality.DN = "Специализация"
def _hx_init_pw_tales_cofdsystem_character_traits_speciality_Speciality_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_speciality_Speciality(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_speciality_Speciality.DN,_hx_local_0).setMultiInstanced(True)
pw_tales_cofdsystem_character_traits_speciality_Speciality.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_speciality_Speciality_TYPE()
pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt.DN = "Arm_Wrack"
def _hx_init_pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt.DN,_hx_local_0).setMultiInstanced(True)
pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_tilts_ArmWrackTilt_TYPE()
pw_tales_cofdsystem_character_traits_tilts_BlindedTilt.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_tilts_BlindedTilt.DN = "Blinded"
def _hx_init_pw_tales_cofdsystem_character_traits_tilts_BlindedTilt_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_tilts_BlindedTilt(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_tilts_BlindedTilt.DN,_hx_local_0).setMultiInstanced(True)
pw_tales_cofdsystem_character_traits_tilts_BlindedTilt.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_tilts_BlindedTilt_TYPE()
pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt.DN = "Leg_Wrack"
def _hx_init_pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt.DN,_hx_local_0).setMultiInstanced(True)
pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_tilts_LegWrackTilt_TYPE()
pw_tales_cofdsystem_character_traits_tilts_StunnedTilt.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_character_traits_tilts_StunnedTilt.DN = "Stunned"
def _hx_init_pw_tales_cofdsystem_character_traits_tilts_StunnedTilt_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_character_traits_tilts_StunnedTilt(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_character_traits_tilts_StunnedTilt.DN,_hx_local_0).setMultiInstanced(True)
pw_tales_cofdsystem_character_traits_tilts_StunnedTilt.TYPE = _hx_init_pw_tales_cofdsystem_character_traits_tilts_StunnedTilt_TYPE()
pw_tales_cofdsystem_common_EnumHand.VALUES = haxe_ds_StringMap()
pw_tales_cofdsystem_common_EnumHand.HAND = pw_tales_cofdsystem_common_EnumHand("hand")
pw_tales_cofdsystem_common_EnumHand.OFFHAND = pw_tales_cofdsystem_common_EnumHand("offhand")
pw_tales_cofdsystem_common_EnumRange.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'SuppressWarnings': ["checkstyle:Type"]})})
pw_tales_cofdsystem_common_EnumRange.VALUES = []
pw_tales_cofdsystem_common_EnumRange.CLOSE = pw_tales_cofdsystem_common_EnumRange("close",5.0)
pw_tales_cofdsystem_common_EnumRange.SHORT = pw_tales_cofdsystem_common_EnumRange("short",30.0)
pw_tales_cofdsystem_common_EnumRange.MEDIUM = pw_tales_cofdsystem_common_EnumRange("medium",100.0)
pw_tales_cofdsystem_common_EnumRange.LONG = pw_tales_cofdsystem_common_EnumRange("long",300.0)
pw_tales_cofdsystem_common_EnumRange.EXTREME = pw_tales_cofdsystem_common_EnumRange("extreme",Math.POSITIVE_INFINITY)
pw_tales_cofdsystem_common_EnumSide.VALUES = haxe_ds_StringMap()
pw_tales_cofdsystem_common_EnumSide.ACTOR = pw_tales_cofdsystem_common_EnumSide("actor")
pw_tales_cofdsystem_common_EnumSide.TARGET = pw_tales_cofdsystem_common_EnumSide("target")
pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_.BASHING = "BASHING"
pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_.LETHAL = "LETHAL"
pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_.AGGRAVATED = "AGGRAVATED"
pw_tales_cofdsystem_damage__DamageType_DamageType_Impl_.ORDER = ["BASHING", "LETHAL", "AGGRAVATED"]
pw_tales_cofdsystem_damage_DamageUtil.INSTANCE = pw_tales_cofdsystem_damage_DamageUtil()
pw_tales_cofdsystem_dices_EnumExplode.KEY_VALUE = haxe_ds_StringMap()
pw_tales_cofdsystem_dices_EnumExplode.VALUES = list()
pw_tales_cofdsystem_dices_EnumExplode.NONE = pw_tales_cofdsystem_dices_EnumExplode("none")
pw_tales_cofdsystem_dices_EnumExplode.DEFAULT = pw_tales_cofdsystem_dices_EnumExplode("default",10)
pw_tales_cofdsystem_dices_EnumExplode.NINE_AGAIN = pw_tales_cofdsystem_dices_EnumExplode("nine_again",9)
pw_tales_cofdsystem_dices_EnumExplode.EIGHT_AGAIN = pw_tales_cofdsystem_dices_EnumExplode("eight_again",8)
pw_tales_cofdsystem_dices_EnumExplode.ROTE_ACTION = pw_tales_cofdsystem_dices_EnumExplode("rote_action")
pw_tales_cofdsystem_dices_EnumResult.FAILURE = pw_tales_cofdsystem_dices_EnumResult("failure")
pw_tales_cofdsystem_dices_EnumResult.DRAMATIC_FAILURE = pw_tales_cofdsystem_dices_EnumResult("dramatic_failure")
pw_tales_cofdsystem_dices_EnumResult.SUCCESS = pw_tales_cofdsystem_dices_EnumResult("success")
pw_tales_cofdsystem_dices_EnumResult.EXCEPTIONAL_SUCCESS = pw_tales_cofdsystem_dices_EnumResult("exceptional_success")
pw_tales_cofdsystem_equipment_traits_EquipmentBonus.DN = "Equipment_Bonus"
def _hx_init_pw_tales_cofdsystem_equipment_traits_EquipmentBonus_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_equipment_traits_EquipmentBonus(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_equipment_traits_EquipmentBonus.DN,_hx_local_0)
pw_tales_cofdsystem_equipment_traits_EquipmentBonus.TYPE = _hx_init_pw_tales_cofdsystem_equipment_traits_EquipmentBonus_TYPE()
pw_tales_cofdsystem_equipment_traits_Equippable.DN = "Equippable"
def _hx_init_pw_tales_cofdsystem_equipment_traits_Equippable_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_equipment_traits_Equippable(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_equipment_traits_Equippable.DN,_hx_local_0)
pw_tales_cofdsystem_equipment_traits_Equippable.TYPE = _hx_init_pw_tales_cofdsystem_equipment_traits_Equippable_TYPE()
pw_tales_cofdsystem_equipment_traits_HoldingHand.DN = "holding_hand"
def _hx_init_pw_tales_cofdsystem_equipment_traits_HoldingHand_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_equipment_traits_HoldingHand(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_equipment_traits_HoldingHand.DN,_hx_local_0)
pw_tales_cofdsystem_equipment_traits_HoldingHand.TYPE = _hx_init_pw_tales_cofdsystem_equipment_traits_HoldingHand_TYPE()
pw_tales_cofdsystem_equipment_traits_StrengthReq.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_equipment_traits_StrengthReq.DN = "Свойство:Strength_Requirements"
def _hx_init_pw_tales_cofdsystem_equipment_traits_StrengthReq_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_equipment_traits_StrengthReq(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_equipment_traits_StrengthReq.DN,_hx_local_0)
pw_tales_cofdsystem_equipment_traits_StrengthReq.TYPE = _hx_init_pw_tales_cofdsystem_equipment_traits_StrengthReq_TYPE()
pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait.DN = "unknown_trait"
pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait.TYPE = pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownType(pw_tales_cofdsystem_game_object_traits_unknown_trait_UnknownTrait.DN)
python_Boot.keywords = set(["and", "del", "from", "not", "with", "as", "elif", "global", "or", "yield", "assert", "else", "if", "pass", "None", "break", "except", "import", "raise", "True", "class", "exec", "in", "return", "False", "continue", "finally", "is", "try", "def", "for", "lambda", "while"])
python_Boot.prefixLength = len("_hx_")
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'SuppressWarnings': ["checkstyle:Type"]})})
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.OR_LITERAL = parsihax_Parser.string(" или ")
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.FROM_LITER = parsihax_Parser.string("от ")
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.TO_LITERAL = parsihax_Parser.string(" до ")
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.NUMBER_LITERAL = parsihax_Parser.regexp(EReg("-?(0|[1-9][0-9]*)",""))
def _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_FULL_PARSER():
    def _hx_local_0():
        return parsihax_Parser.alt([pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS_RANGES, pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS_OR, pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS])
    return parsihax_Parser.lazy(_hx_local_0)
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.FULL_PARSER = _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_FULL_PARSER()
def _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_DOTS():
    def _hx_local_0(result):
        value = Std.parseInt(result)
        if (value is None):
            raise haxe_Exception.thrown("Cannot parse int")
        return pw_tales_cofdsystem_parser_nodes_NodeDots(value)
    return parsihax_Parser.map(pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.NUMBER_LITERAL,_hx_local_0)
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS = _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_DOTS()
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.ARRAY1 = [pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.FROM_LITER, pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS, pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.TO_LITERAL, pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS]
def _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_DOTS_RANGES():
    def _hx_local_0(values):
        return pw_tales_cofdsystem_parser_nodes_NodeDotsRange((values[1] if 1 < len(values) else None),(values[3] if 3 < len(values) else None))
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.ARRAY1),_hx_local_0)
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS_RANGES = _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_DOTS_RANGES()
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.ARRAY2 = [parsihax_Parser.skip(pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS,pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.OR_LITERAL), pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.FULL_PARSER]
def _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_DOTS_OR():
    def _hx_local_0(values):
        return pw_tales_cofdsystem_parser_nodes_NodeDotsOr((values[0] if 0 < len(values) else None),(values[1] if 1 < len(values) else None))
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.ARRAY2),_hx_local_0)
pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS_OR = _hx_init_pw_tales_cofdsystem_parser_parsers_DotsLevelsParser_DOTS_OR()
def _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_FULL_PARSER():
    def _hx_local_0():
        return parsihax_Parser.alt([pw_tales_cofdsystem_parser_parsers_ParserPool.PLUS, pw_tales_cofdsystem_parser_parsers_ParserPool.MINUS, pw_tales_cofdsystem_parser_parsers_ParserPool.TRAIT])
    return parsihax_Parser.lazy(_hx_local_0)
pw_tales_cofdsystem_parser_parsers_ParserPool.FULL_PARSER = _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_FULL_PARSER()
pw_tales_cofdsystem_parser_parsers_ParserPool.PLUS_LITERAL = parsihax_Parser._hx_as(parsihax_Parser.string("+"),"plus")
pw_tales_cofdsystem_parser_parsers_ParserPool.MINUS_LITERAL = parsihax_Parser._hx_as(parsihax_Parser.string("-"),"minus")
def _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_TRAIT():
    def _hx_local_0(value):
        return pw_tales_cofdsystem_parser_nodes_NodeTrait(value)
    return parsihax_Parser.map(pw_tales_cofdsystem_parser_ParserHelper.takeWhileNo(parsihax_Parser.alt([pw_tales_cofdsystem_parser_parsers_ParserPool.PLUS_LITERAL, pw_tales_cofdsystem_parser_parsers_ParserPool.MINUS_LITERAL, parsihax_Parser.eof()])),_hx_local_0)
pw_tales_cofdsystem_parser_parsers_ParserPool.TRAIT = _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_TRAIT()
def _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_NUMBER():
    def _hx_local_0(result):
        parsedInt = Std.parseInt(result)
        if (parsedInt is None):
            parsedInt = 0
        return pw_tales_cofdsystem_parser_nodes_NodeNumber(parsedInt)
    return parsihax_Parser._hx_as(parsihax_Parser.map(parsihax_Parser.regexp(EReg("[0-9]*","")),_hx_local_0),"number")
pw_tales_cofdsystem_parser_parsers_ParserPool.NUMBER = _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_NUMBER()
pw_tales_cofdsystem_parser_parsers_ParserPool.ARRAY2 = [parsihax_Parser.skip(pw_tales_cofdsystem_parser_parsers_ParserPool.TRAIT,pw_tales_cofdsystem_parser_parsers_ParserPool.PLUS_LITERAL), pw_tales_cofdsystem_parser_parsers_ParserPool.FULL_PARSER]
def _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_PLUS():
    def _hx_local_0(values):
        return pw_tales_cofdsystem_parser_nodes_NodePoolSum((values[0] if 0 < len(values) else None),(values[1] if 1 < len(values) else None))
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_ParserPool.ARRAY2),_hx_local_0)
pw_tales_cofdsystem_parser_parsers_ParserPool.PLUS = _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_PLUS()
pw_tales_cofdsystem_parser_parsers_ParserPool.ARRAY3 = [parsihax_Parser.skip(pw_tales_cofdsystem_parser_parsers_ParserPool.TRAIT,pw_tales_cofdsystem_parser_parsers_ParserPool.MINUS_LITERAL), pw_tales_cofdsystem_parser_parsers_ParserPool.FULL_PARSER]
def _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_MINUS():
    def _hx_local_0(values):
        return pw_tales_cofdsystem_parser_nodes_NodePoolSum((values[0] if 0 < len(values) else None),pw_tales_cofdsystem_parser_nodes_NodeInversion((values[1] if 1 < len(values) else None)))
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_ParserPool.ARRAY3),_hx_local_0)
pw_tales_cofdsystem_parser_parsers_ParserPool.MINUS = _hx_init_pw_tales_cofdsystem_parser_parsers_ParserPool_MINUS()
pw_tales_cofdsystem_parser_parsers_RequirementsParser.AND_LITERAL = parsihax_Parser._hx_as(parsihax_Parser.alt([parsihax_Parser.string(" и "), parsihax_Parser.string(", ")]),"separator")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.OR_LITERAL = parsihax_Parser._hx_as(parsihax_Parser.string(" или "),"separator")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.LB_GROUP = parsihax_Parser.string("(")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.RB_GROUP = parsihax_Parser.string(")")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.LB_STRING = parsihax_Parser.string("{")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.RB_STRING = parsihax_Parser.string("}")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.STATEMENT_END = parsihax_Parser.alt([pw_tales_cofdsystem_parser_parsers_RequirementsParser.OR_LITERAL, pw_tales_cofdsystem_parser_parsers_RequirementsParser.AND_LITERAL, parsihax_Parser.eof()])
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_FULL_PARSER():
    def _hx_local_0():
        return parsihax_Parser.alt([pw_tales_cofdsystem_parser_parsers_RequirementsParser.GROUP, parsihax_Parser._hx_or(pw_tales_cofdsystem_parser_parsers_RequirementsParser.AND,pw_tales_cofdsystem_parser_parsers_RequirementsParser.OR), pw_tales_cofdsystem_parser_parsers_RequirementsParser.STATEMENT])
    return parsihax_Parser.lazy(_hx_local_0)
pw_tales_cofdsystem_parser_parsers_RequirementsParser.FULL_PARSER = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_FULL_PARSER()
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_STATEMENT():
    def _hx_local_0():
        return pw_tales_cofdsystem_parser_ParserHelper.inBondaries(parsihax_Parser.alt([pw_tales_cofdsystem_parser_parsers_RequirementsParser.TRAIT_STATEMENT, pw_tales_cofdsystem_parser_parsers_RequirementsParser.STRING_STATEMENT]),pw_tales_cofdsystem_parser_parsers_RequirementsParser.STATEMENT_END)
    return parsihax_Parser.lazy(_hx_local_0)
pw_tales_cofdsystem_parser_parsers_RequirementsParser.STATEMENT = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_STATEMENT()
pw_tales_cofdsystem_parser_parsers_RequirementsParser.TRAIT_VALUE = parsihax_Parser._hx_as(pw_tales_cofdsystem_parser_parsers_DotsLevelsParser.DOTS,"trait value")
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_TRAIT_DN():
    def _hx_local_0(v):
        return pw_tales_cofdsystem_parser_nodes_NodeTrait(v)
    return parsihax_Parser._hx_as(parsihax_Parser.map(pw_tales_cofdsystem_parser_ParserHelper.takeWhileNo(parsihax_Parser.then(parsihax_Parser._hx_as(parsihax_Parser.regexp(EReg("\\s+","")),"whitespace"),pw_tales_cofdsystem_parser_parsers_RequirementsParser.TRAIT_VALUE)),_hx_local_0),"trait dn")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.TRAIT_DN = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_TRAIT_DN()
pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY1 = [parsihax_Parser.skip(pw_tales_cofdsystem_parser_parsers_RequirementsParser.TRAIT_DN,parsihax_Parser._hx_as(parsihax_Parser.regexp(EReg("\\s+","")),"whitespace")), pw_tales_cofdsystem_parser_parsers_RequirementsParser.TRAIT_VALUE]
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_TRAIT_STATEMENT():
    def _hx_local_0(values):
        return pw_tales_cofdsystem_parser_nodes_NodeTraitRequirement((values[0] if 0 < len(values) else None),(values[1] if 1 < len(values) else None))
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY1),_hx_local_0)
pw_tales_cofdsystem_parser_parsers_RequirementsParser.TRAIT_STATEMENT = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_TRAIT_STATEMENT()
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_STRING_STATEMENT():
    def _hx_local_0(value):
        return pw_tales_cofdsystem_parser_nodes_NodeString(value)
    return parsihax_Parser._hx_as(parsihax_Parser.map(pw_tales_cofdsystem_parser_ParserHelper.inBondaries(parsihax_Parser.all(),pw_tales_cofdsystem_parser_parsers_RequirementsParser.STATEMENT_END),_hx_local_0),"string")
pw_tales_cofdsystem_parser_parsers_RequirementsParser.STRING_STATEMENT = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_STRING_STATEMENT()
pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY2 = [pw_tales_cofdsystem_parser_parsers_RequirementsParser.STATEMENT, pw_tales_cofdsystem_parser_parsers_RequirementsParser.AND_LITERAL, pw_tales_cofdsystem_parser_parsers_RequirementsParser.FULL_PARSER]
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_AND():
    def _hx_local_7(values):
        def _hx_local_1():
            _hx_local_0 = values
            if (Std.isOfType(_hx_local_0,list) or ((_hx_local_0 is None))):
                _hx_local_0
            else:
                raise "Class cast error"
            return _hx_local_0
        castedResult = _hx_local_1()
        def _hx_local_6():
            def _hx_local_3():
                _hx_local_2 = (castedResult[0] if 0 < len(castedResult) else None)
                if (Std.isOfType(_hx_local_2,pw_tales_cofdsystem_parser_nodes_INodeCheck) or ((_hx_local_2 is None))):
                    _hx_local_2
                else:
                    raise "Class cast error"
                return _hx_local_2
            def _hx_local_5():
                _hx_local_4 = (castedResult[2] if 2 < len(castedResult) else None)
                if (Std.isOfType(_hx_local_4,pw_tales_cofdsystem_parser_nodes_INodeCheck) or ((_hx_local_4 is None))):
                    _hx_local_4
                else:
                    raise "Class cast error"
                return _hx_local_4
            return pw_tales_cofdsystem_parser_nodes_NodeAnd(_hx_local_3(),_hx_local_5(),(values[1] if 1 < len(values) else None))
        return _hx_local_6()
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY2),_hx_local_7)
pw_tales_cofdsystem_parser_parsers_RequirementsParser.AND = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_AND()
pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY3 = [pw_tales_cofdsystem_parser_parsers_RequirementsParser.STATEMENT, pw_tales_cofdsystem_parser_parsers_RequirementsParser.OR_LITERAL, pw_tales_cofdsystem_parser_parsers_RequirementsParser.FULL_PARSER]
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_OR():
    def _hx_local_7(values):
        def _hx_local_1():
            _hx_local_0 = values
            if (Std.isOfType(_hx_local_0,list) or ((_hx_local_0 is None))):
                _hx_local_0
            else:
                raise "Class cast error"
            return _hx_local_0
        castedResult = _hx_local_1()
        def _hx_local_6():
            def _hx_local_3():
                _hx_local_2 = (castedResult[0] if 0 < len(castedResult) else None)
                if (Std.isOfType(_hx_local_2,pw_tales_cofdsystem_parser_nodes_INodeCheck) or ((_hx_local_2 is None))):
                    _hx_local_2
                else:
                    raise "Class cast error"
                return _hx_local_2
            def _hx_local_5():
                _hx_local_4 = (castedResult[2] if 2 < len(castedResult) else None)
                if (Std.isOfType(_hx_local_4,pw_tales_cofdsystem_parser_nodes_INodeCheck) or ((_hx_local_4 is None))):
                    _hx_local_4
                else:
                    raise "Class cast error"
                return _hx_local_4
            return pw_tales_cofdsystem_parser_nodes_NodeOr(_hx_local_3(),_hx_local_5(),(values[1] if 1 < len(values) else None))
        return _hx_local_6()
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY3),_hx_local_7)
pw_tales_cofdsystem_parser_parsers_RequirementsParser.OR = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_OR()
pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY4 = [pw_tales_cofdsystem_parser_parsers_RequirementsParser.LB_GROUP, pw_tales_cofdsystem_parser_parsers_RequirementsParser.FULL_PARSER, pw_tales_cofdsystem_parser_parsers_RequirementsParser.RB_GROUP]
def _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_GROUP():
    def _hx_local_0(values):
        return pw_tales_cofdsystem_parser_nodes_NodeGroup((values[1] if 1 < len(values) else None))
    return parsihax_Parser.map(parsihax_Parser.seq(pw_tales_cofdsystem_parser_parsers_RequirementsParser.ARRAY4),_hx_local_0)
pw_tales_cofdsystem_parser_parsers_RequirementsParser.GROUP = _hx_init_pw_tales_cofdsystem_parser_parsers_RequirementsParser_GROUP()
pw_tales_cofdsystem_synchronization_api_GameObjectStorage.GAME_OBJECT = "game_object"
pw_tales_cofdsystem_synchronization_api_GameObjectStorage.UPDATED = "updated"
pw_tales_cofdsystem_synchronization_api_GameObjectStorage.ERROR = "error"
pw_tales_cofdsystem_synchronization_api_SystemStorage.ROUTE = "system"
pw_tales_cofdsystem_synchronization_serialization_system_parts_AbilitySerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_parts_AbilitySerialization()
pw_tales_cofdsystem_synchronization_serialization_system_parts_ConditionSerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_parts_ConditionSerialization()
pw_tales_cofdsystem_synchronization_serialization_system_parts_TiltSerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_parts_TiltSerialization()
pw_tales_cofdsystem_synchronization_serialization_system_parts_ArmorSerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_parts_ArmorSerialization()
pw_tales_cofdsystem_synchronization_serialization_system_parts_MeleeSerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_parts_MeleeSerialization()
pw_tales_cofdsystem_synchronization_serialization_system_parts_RangedSerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_parts_RangedSerialization()
pw_tales_cofdsystem_synchronization_serialization_system_parts_TagSerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_parts_TagSerialization()
pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization.INSTANCE = pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization()
pw_tales_cofdsystem_synchronization_serialization_system_SystemSerialization.HANDLERS = [pw_tales_cofdsystem_synchronization_serialization_system_parts_AbilitySerialization.INSTANCE, pw_tales_cofdsystem_synchronization_serialization_system_parts_ConditionSerialization.INSTANCE, pw_tales_cofdsystem_synchronization_serialization_system_parts_TiltSerialization.INSTANCE, pw_tales_cofdsystem_synchronization_serialization_system_parts_ArmorSerialization.INSTANCE, pw_tales_cofdsystem_synchronization_serialization_system_parts_MeleeSerialization.INSTANCE, pw_tales_cofdsystem_synchronization_serialization_system_parts_RangedSerialization.INSTANCE, pw_tales_cofdsystem_synchronization_serialization_system_parts_TagSerialization.INSTANCE]
pw_tales_cofdsystem_utils_logger_TraceLogger.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'SuppressWarnings': ["checkstyle:Trace"]})})
pw_tales_cofdsystem_utils_logger_LoggerManager.LOGGER = pw_tales_cofdsystem_utils_logger_TraceLogger()
pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.SERIALIZE_ANNOTATION = "Serialize"
pw_tales_cofdsystem_utils_serialization_AnnotationSerialization.OPTIONAL_ANNOTATION = "Optional"
pw_tales_cofdsystem_weapon_traits_WeaponTrait.PRIORITY = pw_tales_cofdsystem_utils_events_HandlerPriority.NORMAL
pw_tales_cofdsystem_weapon_traits_WeaponMod.__meta__ = _hx_AnonObject({'fields': _hx_AnonObject({'value': _hx_AnonObject({'Serialize': ["value"]})})})
pw_tales_cofdsystem_weapon_traits_DamageMod.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_DamageMod.DN = "Свойство:Damage"
def _hx_init_pw_tales_cofdsystem_weapon_traits_DamageMod_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_DamageMod(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_DamageMod.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_DamageMod.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_DamageMod_TYPE()
pw_tales_cofdsystem_weapon_traits_InitiativeMod.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_InitiativeMod.DN = "Свойство:Initiative"
def _hx_init_pw_tales_cofdsystem_weapon_traits_InitiativeMod_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_InitiativeMod(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_InitiativeMod.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_InitiativeMod.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_InitiativeMod_TYPE()
pw_tales_cofdsystem_weapon_traits_LethalDamage.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_LethalDamage.DN = "lethal_damage"
def _hx_init_pw_tales_cofdsystem_weapon_traits_LethalDamage_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_LethalDamage(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_LethalDamage.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_LethalDamage.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_LethalDamage_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag.DN = "accurate_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_AccurateTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag.DN = "brawl_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_BrawlTag.PRIORITY = pw_tales_cofdsystem_utils_events_HandlerPriority.lower([pw_tales_cofdsystem_weapon_traits_WeaponTrait.PRIORITY])
pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag.DN = "concealed_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_ConcealedTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag.DN = "8-again_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_EightAgainTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag.DN = "finesse_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_FinesseTag.PRIORITY = pw_tales_cofdsystem_utils_events_HandlerPriority.lower([pw_tales_cofdsystem_weapon_traits_WeaponTrait.PRIORITY])
pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag.DN = "grapple_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_GrappleTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag.DN = "guard_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_GuardTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag.DN = "mercy_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_MercyTag.PRIORITY = pw_tales_cofdsystem_utils_events_HandlerPriority.lower([pw_tales_cofdsystem_weapon_traits_WeaponTrait.PRIORITY])
pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag.DN = "9-again_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_NineAgainTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag.DN = "reach_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_ReachTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag.DN = "stun_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_StunTag_TYPE()
pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag.DN = "two-handed_(weapon_tag)"
def _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag.TYPE = _hx_init_pw_tales_cofdsystem_weapon_traits_weapon_tags_TwoHandedTag_TYPE()
pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon.DN = "melee_weapon"
def _hx_init_pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon.TYPE = _hx_init_pw_tales_cofdsystem_weapon_melee_traits_MeleeWeapon_TYPE()
pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon.__meta__ = _hx_AnonObject({'obj': _hx_AnonObject({'RegisterTraitTypes': None})})
pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon.DN = "ranged_weapon"
def _hx_init_pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon_TYPE():
    def _hx_local_0(dn,gameObject,_hx_type):
        return pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon(dn,gameObject,_hx_type)
    return pw_tales_cofdsystem_game_object_traits_TraitType.createType(pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon.DN,_hx_local_0)
pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon.TYPE = _hx_init_pw_tales_cofdsystem_weapon_ranged_traits_RangedWeapon_TYPE()
sys_Http.PROXY = None
thx_semver__Version_Version_Impl_.VERSION = EReg("^(\\d+)\\.(\\d+)\\.(\\d+)(?:[-]([a-z0-9.-]+))?(?:[+]([a-z0-9.-]+))?$","i")
thx_semver__Version_Version_Impl_.SANITIZER = EReg("[^0-9A-Za-z-]","g")
thx_semver__VersionRule_VersionRule_Impl_.VERSION = EReg("^(>=|<=|[v=><~^])?(\\d+|[x*])(?:\\.(\\d+|[x*]))?(?:\\.(\\d+|[x*]))?(?:[-]([a-z0-9.-]+))?(?:[+]([a-z0-9.-]+))?$","i")
thx_semver__VersionRule_VersionRule_Impl_.IS_DIGITS = EReg("^\\d+$","")