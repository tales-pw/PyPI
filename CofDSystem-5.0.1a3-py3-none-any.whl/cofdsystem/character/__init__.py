import cofdsystem.haxe_build as haxe_build

Character = haxe_build.pw_tales_cofdsystem_character_Character
